(function(){HomeController = AppController.extend({
  
});

})();
