(function(){matchInteractions = new Meteor.RedisCollection("redis");

})();
