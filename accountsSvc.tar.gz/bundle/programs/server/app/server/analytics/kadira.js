(function(){Kadira.connect('eQgsTyttqyfxXSQHF', '9283fdcb-52ef-45b2-a927-55e9e3741653');

})();
