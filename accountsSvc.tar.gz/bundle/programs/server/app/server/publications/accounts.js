(function(){// ensure 2d sphere index
db.accounts._ensureIndex({"location": "2dsphere"});

Meteor.publishComposite("accounts", function() {
  return {
    find: function() {
      return db.accounts.find({});
    }
    // ,
    // children: [
    //   {
    //     find: function(item) {
    //       return [];
    //     }
    //   }
    // ]
  }
});

})();
