(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var IdMap = Package['id-map'].IdMap;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var _ = Package.underscore._;
var Random = Package.random.Random;
var EJSON = Package.ejson.EJSON;

/* Package-scope variables */
var Miniredis, CowIdMap;

(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// packages/slava:miniredis/cow.js                                                                       //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
// A copy-on-write IdMap                                                                                 // 1
// Avoids deep-copying all the objects in a collection; we instead keep                                  // 2
// a separate map just of the objects we've changed.                                                     // 3
// This does rely on the caller not changing objects return from get.                                    // 4
CowIdMap = function (original) {                                                                         // 5
  var self = this;                                                                                       // 6
                                                                                                         // 7
  self._original = original;                                                                             // 8
  self._changes = new IdMap(original._idStringify, original._idParse);                                   // 9
                                                                                                         // 10
  // XXX Should we maintain a combined list (of references, not deep-copies),                            // 11
  // to avoid double-lookup?  Probably, because we always call flatten...                                // 12
  //self._combined = new IdMap(original._idStringify, original._idParse);                                // 13
};                                                                                                       // 14
                                                                                                         // 15
var TOMBSTONE = {};                                                                                      // 16
                                                                                                         // 17
CowIdMap.prototype.remove = function (key) {                                                             // 18
  var self = this;                                                                                       // 19
                                                                                                         // 20
  self._changes.set(key, TOMBSTONE);                                                                     // 21
};                                                                                                       // 22
                                                                                                         // 23
CowIdMap.prototype.has = function (key) {                                                                // 24
  var self = this;                                                                                       // 25
                                                                                                         // 26
  var v = self._changes.get(key);                                                                        // 27
  if (v === undefined) {                                                                                 // 28
    return self._original.has(key);                                                                      // 29
  } else if (v === TOMBSTONE) {                                                                          // 30
    return false;                                                                                        // 31
  } else {                                                                                               // 32
    return true;                                                                                         // 33
  }                                                                                                      // 34
};                                                                                                       // 35
                                                                                                         // 36
// Do not change the returned value.                                                                     // 37
// Instead, copy and set.                                                                                // 38
CowIdMap.prototype.get = function (key) {                                                                // 39
  var self = this;                                                                                       // 40
                                                                                                         // 41
  var v = self._changes.get(key);                                                                        // 42
  if (v === undefined) {                                                                                 // 43
    return self._original.get(key);                                                                      // 44
  } else if (v === TOMBSTONE) {                                                                          // 45
    return undefined;                                                                                    // 46
  } else {                                                                                               // 47
    return v;                                                                                            // 48
  }                                                                                                      // 49
};                                                                                                       // 50
                                                                                                         // 51
CowIdMap.prototype.set = function (key, value) {                                                         // 52
  var self = this;                                                                                       // 53
                                                                                                         // 54
  self._changes.set(key, value);                                                                         // 55
};                                                                                                       // 56
                                                                                                         // 57
                                                                                                         // 58
CowIdMap.prototype.forEach = function (iterator) {                                                       // 59
  var self = this;                                                                                       // 60
                                                                                                         // 61
  var breakIfFalse = undefined;                                                                          // 62
                                                                                                         // 63
  self._changes.forEach(function (value, id) {                                                           // 64
    if (value === TOMBSTONE) {                                                                           // 65
      return true;                                                                                       // 66
    }                                                                                                    // 67
    breakIfFalse = iterator.call(null, value, id);                                                       // 68
    return breakIfFalse;                                                                                 // 69
  });                                                                                                    // 70
                                                                                                         // 71
  if (breakIfFalse === false) {                                                                          // 72
    return;                                                                                              // 73
  }                                                                                                      // 74
                                                                                                         // 75
  self._original.forEach(function (value, id) {                                                          // 76
    if (self._changes.has(id)) {                                                                         // 77
      return true;                                                                                       // 78
    }                                                                                                    // 79
    return iterator.call(null, value, id);                                                               // 80
  });                                                                                                    // 81
};                                                                                                       // 82
                                                                                                         // 83
CowIdMap.prototype._diffQueryChanges = function (callback) {                                             // 84
  var self = this;                                                                                       // 85
                                                                                                         // 86
  self._changes.forEach(function (value, id) {                                                           // 87
    var oldValue = self._original.get(id);                                                               // 88
                                                                                                         // 89
    if (value === TOMBSTONE) {                                                                           // 90
      // Deleted                                                                                         // 91
      if (oldValue !== undefined) {                                                                      // 92
        callback(id, 'removed', value);                                                                  // 93
      }                                                                                                  // 94
    } else if (oldValue === undefined) {                                                                 // 95
      // Added                                                                                           // 96
      callback(id, 'added', value);                                                                      // 97
    } else {                                                                                             // 98
      // Changed                                                                                         // 99
      if (!EJSON.equals(oldValue, value)) {                                                              // 100
        callback(id, 'changed', value, oldValue);                                                        // 101
      }                                                                                                  // 102
    }                                                                                                    // 103
                                                                                                         // 104
    return true;                                                                                         // 105
  });                                                                                                    // 106
};                                                                                                       // 107
                                                                                                         // 108
CowIdMap.prototype.flatten = function () {                                                               // 109
  var self = this;                                                                                       // 110
  var original = self._original;                                                                         // 111
                                                                                                         // 112
  var flat = new IdMap(original._idStringify, original._idParse);                                        // 113
                                                                                                         // 114
  self._original.forEach(function (value, id) {                                                          // 115
    flat.set(id, value);                                                                                 // 116
  });                                                                                                    // 117
                                                                                                         // 118
  self._changes.forEach(function (value, id) {                                                           // 119
    if (value === TOMBSTONE) {                                                                           // 120
      flat.remove(id);                                                                                   // 121
    } else {                                                                                             // 122
      flat.set(id, value);                                                                               // 123
    }                                                                                                    // 124
  });                                                                                                    // 125
                                                                                                         // 126
  return flat;                                                                                           // 127
};                                                                                                       // 128
                                                                                                         // 129
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// packages/slava:miniredis/miniredis.js                                                                 //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
// exported symbol                                                                                       // 1
Miniredis = {};                                                                                          // 2
                                                                                                         // 3
var throwNotImplementedError = function (cb) {                                                           // 4
  var err =                                                                                              // 5
    new Error("The called method is not available in miniredis implementation");                         // 6
  callInCallbackOrThrow(err, cb);                                                                        // 7
};                                                                                                       // 8
                                                                                                         // 9
var throwIncorrectKindOfValueError = function (cb) {                                                     // 10
  // XXX should be a special type of error "WRONGTYPE"                                                   // 11
  var err =                                                                                              // 12
    new Error("Operation against a key holding the wrong kind of value");                                // 13
  callInCallbackOrThrow(err, cb);                                                                        // 14
};                                                                                                       // 15
                                                                                                         // 16
// An abstract represtation of a set of keys matching PATTERN                                            // 17
Miniredis.Cursor = function (redisStore, pattern) {                                                      // 18
  var self = this;                                                                                       // 19
  self.redisStore = redisStore;                                                                          // 20
  self.pattern = pattern;                                                                                // 21
};                                                                                                       // 22
                                                                                                         // 23
// returns the position where x should be inserted in a sorted array                                     // 24
var insPos = function (arr, x) {                                                                         // 25
  var l = 0, r = arr.length - 1;                                                                         // 26
  while (l <= r) {                                                                                       // 27
    var m = (l + r) >> 1;                                                                                // 28
    if (arr[m] <= x)                                                                                     // 29
      l = m + 1;                                                                                         // 30
    else                                                                                                 // 31
      r = m - 1;                                                                                         // 32
  }                                                                                                      // 33
                                                                                                         // 34
  return l;                                                                                              // 35
};                                                                                                       // 36
                                                                                                         // 37
// returns added/changed/removed callbacks which call the passed ordered                                 // 38
// callbacks addedAt/changedAt/removedAt/movedTo                                                         // 39
var translateToOrderedCallbacks = function (orderedCallbacks) {                                          // 40
  var queryResult = [];                                                                                  // 41
  return {                                                                                               // 42
    added: function (doc) {                                                                              // 43
      var pos = insPos(queryResult, doc._id);                                                            // 44
      var before = pos === queryResult.length ? null : queryResult[pos];                                 // 45
      queryResult.splice(pos, 0, doc._id);                                                               // 46
      orderedCallbacks.addedAt && orderedCallbacks.addedAt(doc, pos, before);                            // 47
    },                                                                                                   // 48
    changed: function (newDoc, oldDoc) {                                                                 // 49
      var pos = insPos(queryResult, newDoc._id) - 1;                                                     // 50
      orderedCallbacks.changedAt && orderedCallbacks.changedAt(newDoc, oldDoc, pos);                     // 51
    },                                                                                                   // 52
    removed: function (doc) {                                                                            // 53
      var pos = insPos(queryResult, doc._id) - 1;                                                        // 54
      queryResult.splice(pos, 1);                                                                        // 55
      orderedCallbacks.removedAt && orderedCallbacks.removedAt(doc, pos);                                // 56
    }                                                                                                    // 57
  };                                                                                                     // 58
};                                                                                                       // 59
                                                                                                         // 60
// returns added/changed/removed/addedAt callbacks which call the passed                                 // 61
// added/changed/removed/addedAt/changedAt/removedAt callbacks within                                    // 62
// observeChanges API                                                                                    // 63
var translateToChangesCallbacks = function (changesCallbacks) {                                          // 64
  var newCallbacks = {};                                                                                 // 65
                                                                                                         // 66
  if (changesCallbacks.added)                                                                            // 67
    newCallbacks.added = function (doc) {                                                                // 68
      var id = doc._id;                                                                                  // 69
      delete doc._id;                                                                                    // 70
      changesCallbacks.added(id, doc);                                                                   // 71
    };                                                                                                   // 72
  if (changesCallbacks.addedAt)                                                                          // 73
    newCallbacks.addedAt = function (doc, atIndex, before) {                                             // 74
      var id = doc._id;                                                                                  // 75
      delete doc._id;                                                                                    // 76
      changesCallbacks.addedBefore(id, doc, before);                                                     // 77
    };                                                                                                   // 78
                                                                                                         // 79
  var changedCallback = function (newDoc, oldDoc) {                                                      // 80
    var id = newDoc._id;                                                                                 // 81
    delete newDoc._id;                                                                                   // 82
    // effectively the diff document is just {value} doc, as there is always                             // 83
    // a single top-level field with the value                                                           // 84
    changesCallbacks.changed(id, newDoc);                                                                // 85
  };                                                                                                     // 86
  if (changesCallbacks.changed)                                                                          // 87
    newCallbacks.changed = changedCallback;                                                              // 88
  if (changesCallbacks.changedAt)                                                                        // 89
    newCallbacks.changedAt = changedCallback;                                                            // 90
                                                                                                         // 91
  var removedCallback = function (doc) {                                                                 // 92
    changesCallbacks.removed(doc._id);                                                                   // 93
  };                                                                                                     // 94
  if (changesCallbacks.removed)                                                                          // 95
    newCallbacks.removed = removedCallback;                                                              // 96
  if (changesCallbacks.removedAt)                                                                        // 97
    newCallbacks.removedAt = removedCallback;                                                            // 98
                                                                                                         // 99
  return newCallbacks;                                                                                   // 100
};                                                                                                       // 101
                                                                                                         // 102
_.extend(Miniredis.Cursor.prototype, {                                                                   // 103
  fetch: function () {                                                                                   // 104
    var self = this;                                                                                     // 105
    return self.redisStore.patternFetch(self.pattern);                                                   // 106
  },                                                                                                     // 107
  count: function () {                                                                                   // 108
    var self = this;                                                                                     // 109
    // XXX Inefficient                                                                                   // 110
    return self.fetch().length;                                                                          // 111
  },                                                                                                     // 112
  observe: function (callbacks) {                                                                        // 113
    var self = this;                                                                                     // 114
                                                                                                         // 115
    if (callbacks.addedAt || callbacks.changedAt || callbacks.removedAt || callbacks.movedTo) {          // 116
      return self.observe(translateToOrderedCallbacks(callbacks));                                       // 117
    }                                                                                                    // 118
                                                                                                         // 119
    var observeRecord = _.extend({ pattern: self.pattern }, callbacks);                                  // 120
    var redisStore = self.redisStore;                                                                    // 121
    redisStore.observes.push(observeRecord);                                                             // 122
                                                                                                         // 123
    // XXX it is very important here to sort things in the same order they would                         // 124
    // be sorted by the query definition (right now there is only one default                            // 125
    // order).                                                                                           // 126
    var docsInOrder = redisStore.patternFetch(self.pattern).sort(function (a, b) {                       // 127
      return a.key.localeCompare(b.key);                                                                 // 128
    });                                                                                                  // 129
    _.each(docsInOrder, function (kv) {                                                                  // 130
      callbacks.added && callbacks.added({ _id: kv.key, value: kv.value  });                             // 131
    });                                                                                                  // 132
                                                                                                         // 133
    return {                                                                                             // 134
      stop: function () {                                                                                // 135
        redisStore.observes = _.filter(redisStore.observes, function (obs) {                             // 136
          return obs !== observeRecord;                                                                  // 137
        });                                                                                              // 138
      }                                                                                                  // 139
    };                                                                                                   // 140
  },                                                                                                     // 141
  observeChanges: function (callbacks) {                                                                 // 142
    var self = this;                                                                                     // 143
                                                                                                         // 144
    if (callbacks.addedBefore || callbacks.movedBefore) {                                                // 145
      return self.observe(translateToChangesCallbacks(translateToOrderedCallbacks(callbacks)));          // 146
    }                                                                                                    // 147
                                                                                                         // 148
    return self.observe(translateToChangesCallbacks(callbacks));                                         // 149
  },                                                                                                     // 150
  _getCollectionName: function () {                                                                      // 151
    var self = this;                                                                                     // 152
    return self.redisStore.name;                                                                         // 153
  }                                                                                                      // 154
});                                                                                                      // 155
                                                                                                         // 156
// A main store class                                                                                    // 157
Miniredis.RedisStore = function (name) {                                                                 // 158
  var self = this;                                                                                       // 159
                                                                                                         // 160
  self.name = name;                                                                                      // 161
  // main key-value storage                                                                              // 162
  self._kv = new IdMap(EJSON.stringify, EJSON.parse);                                                    // 163
  // fine-grained reactivity per key                                                                     // 164
  self._keyDependencies = {};                                                                            // 165
  // fine-grained reactivity per non-trivial pattern                                                     // 166
  self._patternDependencies = {};                                                                        // 167
  // originals saved in-between calls to saveOriginals and                                               // 168
  // retrieveOriginals                                                                                   // 169
  self._savedOriginals = null;                                                                           // 170
  // list of observes on cursors                                                                         // 171
  self.observes = [];                                                                                    // 172
                                                                                                         // 173
  // True when observers are paused and we should not send callbacks.                                    // 174
  self.paused = false;                                                                                   // 175
};                                                                                                       // 176
                                                                                                         // 177
// Pause the observers. No callbacks from observers will fire until                                      // 178
// 'resumeObservers' is called.                                                                          // 179
Miniredis.RedisStore.prototype.pauseObservers = function () {                                            // 180
  var self = this;                                                                                       // 181
  // XXX pauseObservers fails silenty if nested?                                                         // 182
  // No-op if already paused.                                                                            // 183
  if (self.paused)                                                                                       // 184
   return;                                                                                               // 185
                                                                                                         // 186
  // Set the 'paused' flag such that new observer messages don't fire.                                   // 187
  self.paused = true;                                                                                    // 188
                                                                                                         // 189
  // Take a snapshot of the query results                                                                // 190
  self._kv = new CowIdMap(self._kv);                                                                     // 191
};                                                                                                       // 192
                                                                                                         // 193
// Resume the observers. Observers immediately receive change                                            // 194
// notifications to bring them to the current state of the                                               // 195
// database. Note that this is not just replaying all the changes that                                   // 196
// happened during the pause, it is a smarter 'coalesced' diff.                                          // 197
Miniredis.RedisStore.prototype.resumeObservers = function () {                                           // 198
  var self = this;                                                                                       // 199
  // No-op if not paused.                                                                                // 200
  if (! self.paused)                                                                                     // 201
   return;                                                                                               // 202
                                                                                                         // 203
  // Unset the 'paused' flag. Make sure to do this first, otherwise                                      // 204
  // observer methods won't actually fire when we trigger them.                                          // 205
  self.paused = false;                                                                                   // 206
                                                                                                         // 207
  // Diff the current results against the snapshot and send to observers.                                // 208
  self._kv._diffQueryChanges(_.bind(self._notifyObserves, self));                                        // 209
                                                                                                         // 210
  // XXX Should we just always use a CowIdMap?                                                           // 211
  self._kv = self._kv.flatten();                                                                         // 212
                                                                                                         // 213
  // XXX Do we need observeQueue (should we put it into a common class)                                  // 214
  //self._observeQueue.drain();                                                                          // 215
};                                                                                                       // 216
                                                                                                         // 217
var callInCallbackAndReturn = function (res, cb) {                                                       // 218
  cb && Meteor.defer(function () { cb(undefined, res); });                                               // 219
  return res;                                                                                            // 220
};                                                                                                       // 221
                                                                                                         // 222
var callInCallbackOrThrow = function (err, cb) {                                                         // 223
  if (cb) cb(err);                                                                                       // 224
  else throw err;                                                                                        // 225
};                                                                                                       // 226
                                                                                                         // 227
var maybePopCallback = function (args) {                                                                 // 228
  return _.isFunction(_.last(args)) ? args.pop() : undefined;                                            // 229
};                                                                                                       // 230
                                                                                                         // 231
_.extend(Miniredis.RedisStore.prototype, {                                                               // 232
  // -----                                                                                               // 233
  // convinience wrappers                                                                                // 234
  // -----                                                                                               // 235
  _keyDep: function (key) {                                                                              // 236
    var self = this;                                                                                     // 237
                                                                                                         // 238
    if (! self._keyDependencies[key])                                                                    // 239
      self._keyDependencies[key] = new Deps.Dependency();                                                // 240
                                                                                                         // 241
    if (Deps.active) {                                                                                   // 242
      // for future clean-up                                                                             // 243
      Deps.onInvalidate(function () {                                                                    // 244
        self._tryCleanUpKeyDep(key);                                                                     // 245
      });                                                                                                // 246
    }                                                                                                    // 247
                                                                                                         // 248
    return self._keyDependencies[key];                                                                   // 249
  },                                                                                                     // 250
  _has: function (key) {                                                                                 // 251
    var self = this;                                                                                     // 252
    self._keyDep(key).depend();                                                                          // 253
    return self._kv.has(key);                                                                            // 254
  },                                                                                                     // 255
  _get: function (key) {                                                                                 // 256
    var self = this;                                                                                     // 257
    self._keyDep(key).depend();                                                                          // 258
    return self._kv.get(key);                                                                            // 259
  },                                                                                                     // 260
  _set: function (key, value) {                                                                          // 261
    var self = this;                                                                                     // 262
    var oldValue = self._kv.has(key) ? self._kv.get(key) : undefined;                                    // 263
    self._kv.set(key, value);                                                                            // 264
                                                                                                         // 265
    self._saveOriginal(key, oldValue);                                                                   // 266
    if (!self.paused && oldValue !== value) {                                                            // 267
      if (oldValue === undefined) {                                                                      // 268
        self._notifyObserves(key, 'added', value);                                                       // 269
      } else {                                                                                           // 270
        self._notifyObserves(key, 'changed', value, oldValue);                                           // 271
      }                                                                                                  // 272
    }                                                                                                    // 273
  },                                                                                                     // 274
                                                                                                         // 275
  _remove: function (key) {                                                                              // 276
    var self = this;                                                                                     // 277
    if (! self._kv.has(key))                                                                             // 278
      return;                                                                                            // 279
    var oldValue = self._kv.get(key);                                                                    // 280
    self._saveOriginal(key, oldValue);                                                                   // 281
    self._kv.remove(key);                                                                                // 282
    if (!self.paused)                                                                                    // 283
      self._notifyObserves(key, 'removed', oldValue);                                                    // 284
  },                                                                                                     // 285
                                                                                                         // 286
  _tryCleanUpKeyDep: function (key) {                                                                    // 287
    var self = this;                                                                                     // 288
    if (self._keyDependencies[key] && ! self._keyDependencies[key].hasDependents())                      // 289
      delete self._keyDependencies[key];                                                                 // 290
  },                                                                                                     // 291
                                                                                                         // 292
  _notifyObserves: function (key, event, value, oldValue) {                                              // 293
    var self = this;                                                                                     // 294
                                                                                                         // 295
    self._keyDep(key).changed();                                                                         // 296
    if (event === "removed") {                                                                           // 297
      self._tryCleanUpKeyDep(key);                                                                       // 298
    }                                                                                                    // 299
                                                                                                         // 300
    if (event !== "changed") {                                                                           // 301
      _.each(self._patternDependencies, function (dep, pattern) {                                        // 302
        if (key.match(patternToRegexp(pattern))) {                                                       // 303
          dep.changed();                                                                                 // 304
        }                                                                                                // 305
      });                                                                                                // 306
    }                                                                                                    // 307
                                                                                                         // 308
    _.each(self.observes, function (obs) {                                                               // 309
      if (! key.match(patternToRegexp(obs.pattern)))                                                     // 310
        return;                                                                                          // 311
      if (event === "changed") {                                                                         // 312
        obs[event] && obs[event]({ _id: key, value: value },                                             // 313
                                 { _id: key, value: oldValue });                                         // 314
      } else {                                                                                           // 315
        obs[event] && obs[event]({ _id: key, value: value });                                            // 316
      }                                                                                                  // 317
    });                                                                                                  // 318
  },                                                                                                     // 319
                                                                                                         // 320
  _drop: function () {                                                                                   // 321
    var self = this;                                                                                     // 322
    self._kv.forEach(function (value, key) {                                                             // 323
      self._remove(key);                                                                                 // 324
    });                                                                                                  // 325
  },                                                                                                     // 326
                                                                                                         // 327
  // -----                                                                                               // 328
  // main interface built on top of Redis                                                                // 329
  // -----                                                                                               // 330
                                                                                                         // 331
  call: function (method/*, args */) {                                                                   // 332
    var self = this;                                                                                     // 333
    var args = _.toArray(arguments).slice(1);                                                            // 334
                                                                                                         // 335
    return self[method.toLowerCase()].apply(self, args);                                                 // 336
  },                                                                                                     // 337
                                                                                                         // 338
  patternFetch: function (pattern, cb) {                                                                 // 339
    var self = this;                                                                                     // 340
    var res = [];                                                                                        // 341
    var thrown = false;                                                                                  // 342
                                                                                                         // 343
    self._kv.forEach(function (value, key) {                                                             // 344
      if (thrown || ! key.match(patternToRegexp(pattern)))                                               // 345
        return;                                                                                          // 346
      self._keyDep(key).depend();                                                                        // 347
                                                                                                         // 348
      if (_.isString(value))                                                                             // 349
        res.push({ key: key, value: value });                                                            // 350
      else if (_.isObject(value))                                                                        // 351
        res.push({ key: key, value: value.toPlain() });                                                  // 352
      else {                                                                                             // 353
        callInCallbackOrThrow(new Error("Unknown type"), cb);                                            // 354
        thrown = true;                                                                                   // 355
      }                                                                                                  // 356
    });                                                                                                  // 357
                                                                                                         // 358
    if (thrown) return;                                                                                  // 359
                                                                                                         // 360
    if (! self._patternDependencies[pattern])                                                            // 361
      self._patternDependencies[pattern] = new Deps.Dependency();                                        // 362
    self._patternDependencies[pattern].depend();                                                         // 363
                                                                                                         // 364
    if (Deps.active) {                                                                                   // 365
      Deps.onInvalidate(function (c) {                                                                   // 366
        if (c.stopped)                                                                                   // 367
          delete self._patternDependencies[pattern];                                                     // 368
      });                                                                                                // 369
    }                                                                                                    // 370
                                                                                                         // 371
    return callInCallbackAndReturn(res, cb);                                                             // 372
  },                                                                                                     // 373
                                                                                                         // 374
  // Returns a Cursor                                                                                    // 375
  matching: function (pattern) {                                                                         // 376
    var self = this;                                                                                     // 377
    var c = new Miniredis.Cursor(self, pattern);                                                         // 378
    return c;                                                                                            // 379
  },                                                                                                     // 380
                                                                                                         // 381
  // -----                                                                                               // 382
  // implementing the contract of a data store                                                           // 383
  // -----                                                                                               // 384
  saveOriginals: function () {                                                                           // 385
    var self = this;                                                                                     // 386
    if (self._savedOriginals)                                                                            // 387
      throw new Error("Called saveOriginals twice without retrieveOriginals");                           // 388
    self._savedOriginals = new IdMap(EJSON.stringify, EJSON.parse);                                      // 389
  },                                                                                                     // 390
                                                                                                         // 391
  retrieveOriginals: function () {                                                                       // 392
    var self = this;                                                                                     // 393
    if (!self._savedOriginals)                                                                           // 394
      throw new Error("Called retrieveOriginals without saveOriginals");                                 // 395
                                                                                                         // 396
    var originals = self._savedOriginals;                                                                // 397
    self._savedOriginals = null;                                                                         // 398
    return originals;                                                                                    // 399
  },                                                                                                     // 400
                                                                                                         // 401
  _saveOriginal: function (key, value) {                                                                 // 402
    var self = this;                                                                                     // 403
    if (! self._savedOriginals || self._savedOriginals.has(key))                                         // 404
      return;                                                                                            // 405
    self._savedOriginals.set(key, value && { _id: key, value: value }); // XXX need to deep clone value? // 406
  },                                                                                                     // 407
                                                                                                         // 408
  // -----                                                                                               // 409
  // general operators on keys                                                                           // 410
  // -----                                                                                               // 411
                                                                                                         // 412
  del: function (/* args */) {                                                                           // 413
    var self = this;                                                                                     // 414
    var removedCount = 0;                                                                                // 415
    var args = _.toArray(arguments);                                                                     // 416
    var cb = maybePopCallback(args);                                                                     // 417
    _.each(args, function (key) {                                                                        // 418
      if (self._has(key)) {                                                                              // 419
        removedCount++;                                                                                  // 420
        self._remove(key);                                                                               // 421
      }                                                                                                  // 422
    });                                                                                                  // 423
                                                                                                         // 424
    return callInCallbackAndReturn(removedCount, cb);                                                    // 425
  },                                                                                                     // 426
  exists: function (key, cb) {                                                                           // 427
    var self = this;                                                                                     // 428
    var res = self._has(key) ? 1 : 0;                                                                    // 429
    return callInCallbackAndReturn(res, cb);                                                             // 430
  },                                                                                                     // 431
  keys: function (pattern, cb) {                                                                         // 432
    if (! pattern)                                                                                       // 433
      throw new Error("Wrong number of arguments for 'keys' command");                                   // 434
    var self = this;                                                                                     // 435
    var res = _.pluck(self.matching(pattern).fetch(), 'key');                                            // 436
    return callInCallbackAndReturn(res, cb);                                                             // 437
  },                                                                                                     // 438
  randomkey: function (cb) {                                                                             // 439
    var self = this;                                                                                     // 440
    var res = Random.choice(_.keys(self._kv));                                                           // 441
    return callInCallbackAndReturn(res, cb);                                                             // 442
  },                                                                                                     // 443
  rename: function (key, newkey, cb) {                                                                   // 444
    if (key === newkey) {                                                                                // 445
      callInCallbackOrThrow(                                                                             // 446
        new Error("Source and destination objects are the same"), cb);                                   // 447
      return;                                                                                            // 448
    }                                                                                                    // 449
                                                                                                         // 450
    var self = this;                                                                                     // 451
                                                                                                         // 452
    if (! self._has(key)) {                                                                              // 453
      callInCallbackOrThrow(new Error("No such key"), cb);                                               // 454
      return;                                                                                            // 455
    }                                                                                                    // 456
                                                                                                         // 457
    var val = self._get(key);                                                                            // 458
    self._remove(key);                                                                                   // 459
    self._set(newkey, val);                                                                              // 460
                                                                                                         // 461
    return callInCallbackAndReturn(undefined, cb);                                                       // 462
  },                                                                                                     // 463
  renamenx: function (key, newkey, cb) {                                                                 // 464
    var self = this;                                                                                     // 465
    var res;                                                                                             // 466
                                                                                                         // 467
    if (self._has(newkey)) {                                                                             // 468
      res = 0;                                                                                           // 469
    } else {                                                                                             // 470
      self.rename(key, newkey);                                                                          // 471
      res = 1;                                                                                           // 472
    }                                                                                                    // 473
                                                                                                         // 474
    return callInCallbackAndReturn(res, cb);                                                             // 475
  },                                                                                                     // 476
  sort: function (cb) {                                                                                  // 477
    // This is a non-trivial operator that requires more thought on the design                           // 478
    // and implementation. We probably want to implement this as it is the only                          // 479
    // querying mechanism.                                                                               // 480
    throwNotImplementedError(cb);                                                                        // 481
  },                                                                                                     // 482
  type: function (key, cb) {                                                                             // 483
    var self = this;                                                                                     // 484
    var type;                                                                                            // 485
                                                                                                         // 486
    // for unset keys the return value is "none"                                                         // 487
    if (! self._has(key)) {                                                                              // 488
      type = "none";                                                                                     // 489
    } else {                                                                                             // 490
      var val = self._get(key);                                                                          // 491
      type = _.isString(val) ? "string" : val.type();                                                    // 492
    }                                                                                                    // 493
                                                                                                         // 494
    return callInCallbackAndReturn(type, cb);                                                            // 495
  },                                                                                                     // 496
                                                                                                         // 497
  // -----                                                                                               // 498
  // operators on strings                                                                                // 499
  // -----                                                                                               // 500
                                                                                                         // 501
  append: function (key, value, cb) {                                                                    // 502
    var self = this;                                                                                     // 503
    var val = self._has(key) ? self._get(key) : "";                                                      // 504
                                                                                                         // 505
    if (! _.isString(val)) {                                                                             // 506
      throwIncorrectKindOfValueError(cb);                                                                // 507
      return;                                                                                            // 508
    }                                                                                                    // 509
                                                                                                         // 510
    val += value;                                                                                        // 511
    self._set(key, val);                                                                                 // 512
                                                                                                         // 513
    return callInCallbackAndReturn(val.length, cb);                                                      // 514
  },                                                                                                     // 515
  decr: function (key, cb) {                                                                             // 516
    var self = this;                                                                                     // 517
    self.decrby(key, 1);                                                                                 // 518
    callInCallbackAndReturn(undefined, cb);                                                              // 519
  },                                                                                                     // 520
  decrby: function (key, decrement, cb) {                                                                // 521
    var self = this;                                                                                     // 522
    var val = self._has(key) ? self._get(key) : "0";                                                     // 523
                                                                                                         // 524
    if (! _.isString(val)) {                                                                             // 525
      throwIncorrectKindOfValueError(cb);                                                                // 526
      return;                                                                                            // 527
    }                                                                                                    // 528
                                                                                                         // 529
    // cast to integer                                                                                   // 530
    var newVal = val |0;                                                                                 // 531
                                                                                                         // 532
    if (val !== newVal.toString()) {                                                                     // 533
      callInCallbackOrThrow(                                                                             // 534
        new Error("Value is not an integer or out of range"), cb);                                       // 535
      return;                                                                                            // 536
    }                                                                                                    // 537
                                                                                                         // 538
    self._set(key, (newVal - decrement).toString());                                                     // 539
                                                                                                         // 540
    return callInCallbackAndReturn(undefined, cb);                                                       // 541
  },                                                                                                     // 542
  get: function (key, cb) {                                                                              // 543
    var self = this;                                                                                     // 544
    var val = self._has(key) ? self._get(key) : null;                                                    // 545
    if (val !== null && ! _.isString(val)) {                                                             // 546
      throwIncorrectKindOfValueError(cb);                                                                // 547
      return;                                                                                            // 548
    }                                                                                                    // 549
    // Mirror mongo behaviour: missing get returns undefined                                             // 550
    if (val === null) {                                                                                  // 551
      val = undefined;                                                                                   // 552
    }                                                                                                    // 553
                                                                                                         // 554
    return callInCallbackAndReturn(val, cb);                                                             // 555
  },                                                                                                     // 556
  getrange: function (key, start, end, cb) {                                                             // 557
    start = start || 0;                                                                                  // 558
    end = end || 0;                                                                                      // 559
                                                                                                         // 560
    var self = this;                                                                                     // 561
    var val = self._has(key) ? self._get(key) : "";                                                      // 562
                                                                                                         // 563
    if (! _.isString(val))                                                                               // 564
      throwIncorrectKindOfValueError(cb);                                                                // 565
    if (val === "")                                                                                      // 566
      return callInCallbackAndReturn("", cb);                                                            // 567
                                                                                                         // 568
    var len = val.length;                                                                                // 569
    var normalizedBounds = normalizeBounds(start, end, len);                                             // 570
    start = normalizedBounds.start;                                                                      // 571
    end = normalizedBounds.end;                                                                          // 572
                                                                                                         // 573
    if (end < start)                                                                                     // 574
      return callInCallbackAndReturn("", cb);                                                            // 575
                                                                                                         // 576
    return callInCallbackAndReturn(val.substr(start, end - start + 1), cb);                              // 577
  },                                                                                                     // 578
  getset: function (key, value, cb) {                                                                    // 579
    var self = this;                                                                                     // 580
    var val = self.get(key);                                                                             // 581
    self.set(key, value.toString());                                                                     // 582
    return callInCallbackAndReturn(val);                                                                 // 583
  },                                                                                                     // 584
  incr: function (key, cb) {                                                                             // 585
    var self = this;                                                                                     // 586
    return self.incrby(key, 1, cb);                                                                      // 587
  },                                                                                                     // 588
  incrby: function (key, increment, cb) {                                                                // 589
    var self = this;                                                                                     // 590
    return self.decrby(key, -increment, cb);                                                             // 591
  },                                                                                                     // 592
  incrbyfloat: function (key, increment, cb) {                                                           // 593
    var self = this;                                                                                     // 594
    var val = self._has(key) ? self._get(key) : "0";                                                     // 595
                                                                                                         // 596
    if (! _.isString(val))                                                                               // 597
      throwIncorrectKindOfValueError();                                                                  // 598
                                                                                                         // 599
    // cast to float                                                                                     // 600
    var newVal = parseFloat(val);                                                                        // 601
                                                                                                         // 602
    if (isNaN(newVal))                                                                                   // 603
      throw new Error("Value is not a valid float");                                                     // 604
                                                                                                         // 605
    self._set(key, (newVal + increment).toString());                                                     // 606
    return callInCallbackAndReturn(undefined, cb);                                                       // 607
  },                                                                                                     // 608
  mget: function (/* args */) {                                                                          // 609
    var self = this;                                                                                     // 610
    var args = _.toString(arguments);                                                                    // 611
    var cb = maybePopCallback(args);                                                                     // 612
    var res = _.map(args, function (key) {                                                               // 613
      return self.get(key);                                                                              // 614
    });                                                                                                  // 615
                                                                                                         // 616
    callInCallbackAndReturn(res, cb);                                                                    // 617
  },                                                                                                     // 618
  mset: function (/* args */) {                                                                          // 619
    var self = this;                                                                                     // 620
    var args = _.toString(arguments);                                                                    // 621
    var cb = maybePopCallback(args);                                                                     // 622
                                                                                                         // 623
    for (var i = 0; i < args.length; i += 2) {                                                           // 624
      var key = args[i];                                                                                 // 625
      var value = args[i + 1];                                                                           // 626
      self.set(key, value);                                                                              // 627
    }                                                                                                    // 628
                                                                                                         // 629
    return callInCallbackAndReturn(undefined, cb);                                                       // 630
  },                                                                                                     // 631
  msetnx: function (/* args */) {                                                                        // 632
    var self = this;                                                                                     // 633
    var args = _.toString(arguments);                                                                    // 634
    var cb = maybePopCallback(args);                                                                     // 635
    var res;                                                                                             // 636
                                                                                                         // 637
    if (_.all(args, function (key, i) {                                                                  // 638
      return (i % 2 === 1) || self._has(key);                                                            // 639
    })) {                                                                                                // 640
      self.mset.apply(self, args);                                                                       // 641
      res = 1;                                                                                           // 642
    } else {                                                                                             // 643
      res = 0;                                                                                           // 644
    }                                                                                                    // 645
                                                                                                         // 646
    return callInCallbackAndReturn(res, cb);                                                             // 647
  },                                                                                                     // 648
  set: function (key, value, cb) {                                                                       // 649
    var self = this;                                                                                     // 650
    self._set(key, value.toString());                                                                    // 651
    return callInCallbackAndReturn("OK", cb);                                                            // 652
  },                                                                                                     // 653
  setex: function (key, expiration, value, cb) {                                                         // 654
    // We rely on the server to do our expirations                                                       // 655
    var self = this;                                                                                     // 656
    return self.set(key, value, cb);                                                                     // 657
  },                                                                                                     // 658
  setnx: function (key, value, cb) {                                                                     // 659
    var self = this;                                                                                     // 660
    if (self._has(key))                                                                                  // 661
      return callInCallbackAndReturn(0, cb);                                                             // 662
    self.set(key, value);                                                                                // 663
    return callInCallbackAndReturn(1, cb);                                                               // 664
  },                                                                                                     // 665
  setrange: function (key, offset, value, cb) {                                                          // 666
    // We probably should have an implementation for this one but it requires a                          // 667
    // bit more thinking on how do we zero pad the string.                                               // 668
    throwNotImplementedError(cb);                                                                        // 669
  },                                                                                                     // 670
  strlen: function (key, cb) {                                                                           // 671
    var self = this;                                                                                     // 672
    var val = self.get(key);                                                                             // 673
    var len = val ? val.length : 0;                                                                      // 674
    return callInCallbackAndReturn(len, cb);                                                             // 675
  }                                                                                                      // 676
});                                                                                                      // 677
                                                                                                         // 678
Miniredis.unsupportedMethods = ["ttl", "restore", "dump", "expire", "expireat",                          // 679
  "migrate", "move", "object", "persist", "pexpire", "pexpireat", "pttl",                                // 680
  "bitcount", "bitop", "bitops", "getbit", "setbit", "psetex",                                           // 681
  "blpop", "brpop", "brpoplpush", "rpoplpush"];                                                          // 682
                                                                                                         // 683
_.each(Miniredis.unsupportedMethods, function (method) {                                                 // 684
  Miniredis.RedisStore.prototype[method] = throwNotImplementedError;                                     // 685
});                                                                                                      // 686
                                                                                                         // 687
Miniredis.List = function () {                                                                           // 688
  this._list = [];                                                                                       // 689
};                                                                                                       // 690
                                                                                                         // 691
_.extend(Miniredis.List.prototype, {                                                                     // 692
  // since the Miniredis.List will always be used through RedisStore, there                              // 693
  // is no point of extra type-checking                                                                  // 694
  lpush: function (/* values */) {                                                                       // 695
    var values = _.invoke(arguments, "toString");                                                        // 696
    Array.prototype.splice.apply(this._list, [0, 0].concat(values));                                     // 697
    return this._list.length;                                                                            // 698
  },                                                                                                     // 699
  rpush: function (/* values */) {                                                                       // 700
    var values = _.invoke(arguments, "toString");                                                        // 701
    Array.prototype.push.apply(this._list, values);                                                      // 702
    return this._list.length;                                                                            // 703
  },                                                                                                     // 704
  lpop: function () {                                                                                    // 705
    var val = this._list.splice(0, 1)[0];                                                                // 706
    return val === undefined ? null : val;                                                               // 707
  },                                                                                                     // 708
  rpop: function () {                                                                                    // 709
    var val = this._list.pop();                                                                          // 710
    return val === undefined ? null : val;                                                               // 711
  },                                                                                                     // 712
  lindex: function (index) {                                                                             // 713
    if (index < 0)                                                                                       // 714
      index = this._list.length + index;                                                                 // 715
    var val = this._list[index];                                                                         // 716
    return val === undefined ? null : val;                                                               // 717
  },                                                                                                     // 718
  linsert: function (beforeAfter, pivot, value) {                                                        // 719
    var self = this;                                                                                     // 720
    var pos = _.indexOf(self._list, pivot.toString());                                                   // 721
    var isBefore = beforeAfter.toLowerCase() === "before";                                               // 722
                                                                                                         // 723
    if (pos === -1)                                                                                      // 724
      return -1;                                                                                         // 725
                                                                                                         // 726
    self._list.splice(isBefore ? pos : pos + 1, 0, value.toString());                                    // 727
    return self._list.length;                                                                            // 728
  },                                                                                                     // 729
  lrange: function (start, stop) {                                                                       // 730
    var self = this;                                                                                     // 731
    var normalizedBounds = normalizeBounds(start, stop, self._list.length);                              // 732
    start = normalizedBounds.start;                                                                      // 733
    stop = normalizedBounds.end;                                                                         // 734
                                                                                                         // 735
    if (start > stop)                                                                                    // 736
      return [];                                                                                         // 737
                                                                                                         // 738
    return self._list.slice(start, stop + 1);                                                            // 739
  },                                                                                                     // 740
  lset: function (index, value) {                                                                        // 741
    if (index < 0)                                                                                       // 742
      index = this._length + index;                                                                      // 743
    this._list[index] = value.toString();                                                                // 744
  },                                                                                                     // 745
  ltrim: function (start, stop) {                                                                        // 746
    this._list = this.lrange(start, stop);                                                               // 747
  },                                                                                                     // 748
  llen: function () {                                                                                    // 749
    return this._list.length;                                                                            // 750
  },                                                                                                     // 751
  type: function () { return "list"; },                                                                  // 752
  toPlain: function () { return this._list.slice(0); },                                                  // 753
  clone: function () {                                                                                   // 754
    var list = new Miniredis.List();                                                                     // 755
    list._list = _.clone(this._list);                                                                    // 756
    return list;                                                                                         // 757
  }                                                                                                      // 758
});                                                                                                      // 759
                                                                                                         // 760
_.each(["lpushx", "rpushx"], function (method) {                                                         // 761
  Miniredis.RedisStore.prototype[method] = function (key/* args */) {                                    // 762
    var self = this;                                                                                     // 763
                                                                                                         // 764
    if (! self._has(key))                                                                                // 765
      return 0;                                                                                          // 766
    return self[method.slice(0, -1)].apply(self, arguments);                                             // 767
  };                                                                                                     // 768
});                                                                                                      // 769
                                                                                                         // 770
_.each(["lpush", "rpush", "lpop", "rpop", "lindex", "linsert", "lrange",                                 // 771
        "lset", "ltrim", "llen"],                                                                        // 772
       function (method) {                                                                               // 773
         Miniredis.RedisStore.prototype[method] = function (key/*, args */) {                            // 774
           var self = this;                                                                              // 775
           var args = _.toArray(arguments).slice(1);                                                     // 776
           var cb = maybePopCallback(args);                                                              // 777
                                                                                                         // 778
           if (! self._has(key))                                                                         // 779
             self._set(key, new Miniredis.List);                                                         // 780
                                                                                                         // 781
           var list = self._get(key);                                                                    // 782
           if (! (list instanceof Miniredis.List)) {                                                     // 783
             throwIncorrectKindOfValueError(cb);                                                         // 784
             return;                                                                                     // 785
           }                                                                                             // 786
                                                                                                         // 787
           var copy = list.clone();                                                                      // 788
           var res = Miniredis.List.prototype[method].apply(copy, args);                                 // 789
           self._set(key, copy);                                                                         // 790
           return callInCallbackAndReturn(res, cb);                                                      // 791
         };                                                                                              // 792
       });                                                                                               // 793
                                                                                                         // 794
// Hash implementation                                                                                   // 795
Miniredis.Hash = function (map) {                                                                        // 796
  var self = this;                                                                                       // 797
  self._map = map || {};                                                                                 // 798
  self._didChange = false;                                                                               // 799
};                                                                                                       // 800
                                                                                                         // 801
_.extend(Miniredis.Hash.prototype, {                                                                     // 802
  hset: function (field, value) {                                                                        // 803
    var map = this._map;                                                                                 // 804
    var existed = _.has(map, field);                                                                     // 805
                                                                                                         // 806
    if (! existed || map[field] !== value)                                                               // 807
      this._didChange = true;                                                                            // 808
                                                                                                         // 809
    map[field] = value;                                                                                  // 810
    return existed ? 0 : 1;                                                                              // 811
  },                                                                                                     // 812
  hsetnx: function (field, value) {                                                                      // 813
    var map = this._map;                                                                                 // 814
    var existed = _.has(map, field);                                                                     // 815
    if (! existed) {                                                                                     // 816
      map[field] = value;                                                                                // 817
      this._didChange = true;                                                                            // 818
    }                                                                                                    // 819
                                                                                                         // 820
    return existed ? 0 : 1;                                                                              // 821
  },                                                                                                     // 822
  hget: function (field) {                                                                               // 823
    return this._map[field];                                                                             // 824
  },                                                                                                     // 825
  hkeys: function () {                                                                                   // 826
    return _.keys(this._map);                                                                            // 827
  },                                                                                                     // 828
  hvals: function () {                                                                                   // 829
    return _.values(this._map);                                                                          // 830
  },                                                                                                     // 831
  hgetall: function () {                                                                                 // 832
    return _.clone(this._map);                                                                           // 833
  },                                                                                                     // 834
  hincrby: function (field, delta) {                                                                     // 835
    var val = this._map[field];                                                                          // 836
    var newVal = (val || "0") |0;                                                                        // 837
                                                                                                         // 838
    if (val !== newVal.toString())                                                                       // 839
      throw new Error("Hash value is not an integer.");                                                  // 840
                                                                                                         // 841
    this._map[field] = (newVal - -delta).toString();                                                     // 842
                                                                                                         // 843
    if (this._map[field] !== val)                                                                        // 844
      this._didChange = true;                                                                            // 845
                                                                                                         // 846
    return this._map[field];                                                                             // 847
  },                                                                                                     // 848
  hincrbyfloat: function (field, delta) {                                                                // 849
    var val = this._map[field];                                                                          // 850
    var newVal = parseFloat(val || "0");                                                                 // 851
                                                                                                         // 852
    if (isNaN(newVal))                                                                                   // 853
      throw new Error("Hash value is not a valid float.");                                               // 854
                                                                                                         // 855
    this._map[field] = (newVal - -delta).toString();                                                     // 856
                                                                                                         // 857
    if (this._map[field] !== val)                                                                        // 858
      this._didChange = true;                                                                            // 859
                                                                                                         // 860
    return this._map[field];                                                                             // 861
  },                                                                                                     // 862
  hdel: function (/* args */) {                                                                          // 863
    var args = _.toArray(arguments);                                                                     // 864
    var self = this;                                                                                     // 865
    return _.reduce(args, function (removed, field) {                                                    // 866
      if (! _.has(self._map, field))                                                                     // 867
        return removed;                                                                                  // 868
      delete self._map[field];                                                                           // 869
      self._didChange = true;                                                                            // 870
      return removed + 1;                                                                                // 871
    }, 0);                                                                                               // 872
  },                                                                                                     // 873
  hmset: function (/* args */) {                                                                         // 874
    var args = _.toArray(arguments);                                                                     // 875
    var self = this;                                                                                     // 876
    var map = self._map;                                                                                 // 877
                                                                                                         // 878
    var changeFn = function (value, key) {                                                               // 879
      self.hset(key, value);                                                                             // 880
    };                                                                                                   // 881
                                                                                                         // 882
    if (args.length === 1 && _.isObject(args[0])) {                                                      // 883
      // a short hand form of a map                                                                      // 884
      _.each(args[0], changeFn);                                                                         // 885
    } else {                                                                                             // 886
      // a traditional syntax with key-value pairs                                                       // 887
      for (var i = 0; i + 1 < args.length; i += 2) {                                                     // 888
        var key = args[i];                                                                               // 889
        var value = args[i + 1];                                                                         // 890
        changeFn(value, key);                                                                            // 891
      }                                                                                                  // 892
    }                                                                                                    // 893
    return "OK";                                                                                         // 894
  },                                                                                                     // 895
  hmget: function (/* args */) {                                                                         // 896
    var args = _.toArray(arguments);                                                                     // 897
    var map = this._map;                                                                                 // 898
    return _.map(args, function (field) {                                                                // 899
      return map[field];                                                                                 // 900
    });                                                                                                  // 901
  },                                                                                                     // 902
  hlen: function () {                                                                                    // 903
    return this.hkeys().length;                                                                          // 904
  },                                                                                                     // 905
  hexists: function (field) {                                                                            // 906
    return _.has(this._map, field) ? 1 : 0;                                                              // 907
  },                                                                                                     // 908
  // XXX no hscan?                                                                                       // 909
                                                                                                         // 910
  // Miniredis data-structure interface                                                                  // 911
  type: function () { return "hash"; },                                                                  // 912
  clone: function () {                                                                                   // 913
    var copy = new Miniredis.Hash(_.clone(this._map));                                                   // 914
    return copy;                                                                                         // 915
  },                                                                                                     // 916
  toPlain: function () { return this._map; },                                                            // 917
  _isEmpty: function () { return _.isEmpty(this._map); },                                                // 918
                                                                                                         // 919
  // EJSONable type interface                                                                            // 920
  typeName: function () { return "redis-hash" },                                                         // 921
  toJSONValue: function () {                                                                             // 922
    return JSON.stringify(this._map);                                                                    // 923
  }                                                                                                      // 924
});                                                                                                      // 925
                                                                                                         // 926
EJSON.addType("redis-hash",  function (map) {                                                            // 927
  return new Miniredis.Hash(JSON.parse(map));                                                            // 928
});                                                                                                      // 929
                                                                                                         // 930
                                                                                                         // 931
_.each(["hset", "hsetnx", "hget", "hkeys", "hvals", "hgetall", "hincrby",                                // 932
        "hincrbyfloat", "hdel", "hmset", "hmget", "hlen", "hexists"],                                    // 933
       function (method) {                                                                               // 934
         Miniredis.RedisStore.prototype[method] = function (key/*, args */) {                            // 935
           var self = this;                                                                              // 936
           var args = _.toArray(arguments).slice(1);                                                     // 937
           var cb = maybePopCallback(args);                                                              // 938
                                                                                                         // 939
           var hash = self._get(key);                                                                    // 940
                                                                                                         // 941
           if (! self._has(key)) {                                                                       // 942
             if (_.contains(["hget", "hkeys", "hvals", "hgetall"], method)) {                            // 943
               return callInCallbackAndReturn(undefined, cb);                                            // 944
             }                                                                                           // 945
             hash = new Miniredis.Hash;                                                                  // 946
           }                                                                                             // 947
                                                                                                         // 948
           if (! (hash instanceof Miniredis.Hash)) {                                                     // 949
             throwIncorrectKindOfValueError(cb);                                                         // 950
             return;                                                                                     // 951
           }                                                                                             // 952
                                                                                                         // 953
           var copy = hash;                                                                              // 954
                                                                                                         // 955
           copy = hash.clone();                                                                          // 956
                                                                                                         // 957
           try {                                                                                         // 958
             var res = Miniredis.Hash.prototype[method].apply(copy, args);                               // 959
           } catch (err) {                                                                               // 960
             callInCallbackOrThrow(err, cb);                                                             // 961
             return;                                                                                     // 962
           }                                                                                             // 963
                                                                                                         // 964
           if (copy._didChange && ! copy._isEmpty())                                                     // 965
             self._set(key, copy);                                                                       // 966
           copy._didChange = false;                                                                      // 967
                                                                                                         // 968
           // a special case for removing the last field in a hash                                       // 969
           if (copy._isEmpty())                                                                          // 970
             self._remove(key);                                                                          // 971
                                                                                                         // 972
           return callInCallbackAndReturn(res, cb);                                                      // 973
         };                                                                                              // 974
       });                                                                                               // 975
                                                                                                         // 976
function normalizeBounds (start, end, len) {                                                             // 977
  // put start and end into [0, len) range                                                               // 978
  start %= len;                                                                                          // 979
  if (start < 0)                                                                                         // 980
    start += len;                                                                                        // 981
  if (end >= len)                                                                                        // 982
    end = len - 1;                                                                                       // 983
  end %= len;                                                                                            // 984
  if (end < 0)                                                                                           // 985
    end += len;                                                                                          // 986
  return { start: start, end: end };                                                                     // 987
}                                                                                                        // 988
                                                                                                         // 989
function patternToRegexp (pattern) {                                                                     // 990
  // all special chars except for [, ], *, ?                                                             // 991
  // - as they are used as is in patterns                                                                // 992
  var specialChars = ".\\^$()+{}";                                                                       // 993
  var regexpStr = "^";                                                                                   // 994
                                                                                                         // 995
  _.each(pattern, function (ch) {                                                                        // 996
    if (_.contains(specialChars, ch))                                                                    // 997
      regexpStr += "\\";                                                                                 // 998
                                                                                                         // 999
    // "match one" operator                                                                              // 1000
    if (ch === "?")                                                                                      // 1001
      ch = ".";                                                                                          // 1002
    // "match any number of chars" operator                                                              // 1003
    if (ch === "*")                                                                                      // 1004
      ch = ".*";                                                                                         // 1005
                                                                                                         // 1006
    regexpStr += ch;                                                                                     // 1007
  });                                                                                                    // 1008
                                                                                                         // 1009
  regexpStr += "$";                                                                                      // 1010
                                                                                                         // 1011
  return new RegExp(regexpStr);                                                                          // 1012
}                                                                                                        // 1013
                                                                                                         // 1014
Miniredis.patternToRegexp = patternToRegexp;                                                             // 1015
                                                                                                         // 1016
                                                                                                         // 1017
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['slava:miniredis'] = {
  Miniredis: Miniredis
};

})();

//# sourceMappingURL=slava_miniredis.js.map
