(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var Accounts = Package['accounts-base'].Accounts;
var check = Package.check.check;
var Match = Package.check.Match;
var _ = Package.underscore._;
var Router = Package['iron:router'].Router;
var RouteController = Package['iron:router'].RouteController;
var ReactiveVar = Package['reactive-var'].ReactiveVar;
var HTTP = Package.http.HTTP;
var HTTPInternals = Package.http.HTTPInternals;
var Iron = Package['iron:core'].Iron;

/* Package-scope variables */
var AccountsTemplates, Field, STATE_PAT, ERRORS_PAT, INFO_PAT, INPUT_ICONS_PAT, ObjWithStringValues, TEXTS_PAT, CONFIG_PAT, FIELD_SUB_PAT, FIELD_PAT, AT;

(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/useraccounts:core/lib/field.js                                                                         //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
// ---------------------------------------------------------------------------------                               // 1
                                                                                                                   // 2
// Field object                                                                                                    // 3
                                                                                                                   // 4
// ---------------------------------------------------------------------------------                               // 5
                                                                                                                   // 6
                                                                                                                   // 7
Field = function(field){                                                                                           // 8
    check(field, FIELD_PAT);                                                                                       // 9
    _.defaults(this, field);                                                                                       // 10
                                                                                                                   // 11
    this.validating = new ReactiveVar(false);                                                                      // 12
    this.status = new ReactiveVar(null);                                                                           // 13
};                                                                                                                 // 14
                                                                                                                   // 15
if (Meteor.isClient)                                                                                               // 16
    Field.prototype.clearStatus = function(){                                                                      // 17
        return this.status.set(null);                                                                              // 18
    };                                                                                                             // 19
if (Meteor.isServer)                                                                                               // 20
    Field.prototype.clearStatus = function(){                                                                      // 21
        // Nothing to do server-side                                                                               // 22
        return                                                                                                     // 23
    };                                                                                                             // 24
                                                                                                                   // 25
Field.prototype.fixValue = function(value){                                                                        // 26
    if (this.type === "checkbox")                                                                                  // 27
        return !!value;                                                                                            // 28
    if (this.type === "select")                                                                                    // 29
        // TODO: something working...                                                                              // 30
        return value;                                                                                              // 31
    if (this.type === "radio")                                                                                     // 32
        // TODO: something working...                                                                              // 33
        return value;                                                                                              // 34
    // Possibly applies required transformations to the input value                                                // 35
    if (this.trim)                                                                                                 // 36
        value = value.trim();                                                                                      // 37
    if (this.lowercase)                                                                                            // 38
        value = value.toLowerCase();                                                                               // 39
    if (this.uppercase)                                                                                            // 40
        value = value.toUpperCase();                                                                               // 41
    if (!!this.transform)                                                                                          // 42
        value = this.transform(value);                                                                             // 43
    return value;                                                                                                  // 44
};                                                                                                                 // 45
                                                                                                                   // 46
if (Meteor.isClient)                                                                                               // 47
    Field.prototype.getDisplayName = function(state){                                                              // 48
        var dN = this.displayName;                                                                                 // 49
        if (_.isObject(dN))                                                                                        // 50
            dN = dN[state] || dN["default"];                                                                       // 51
        if (!dN)                                                                                                   // 52
            dN = capitalize(this._id);                                                                             // 53
        return dN;                                                                                                 // 54
    };                                                                                                             // 55
                                                                                                                   // 56
if (Meteor.isClient)                                                                                               // 57
    Field.prototype.getPlaceholder = function(state){                                                              // 58
        var placeholder = this.placeholder;                                                                        // 59
        if (_.isObject(placeholder))                                                                               // 60
            placeholder = placeholder[state] || placeholder["default"];                                            // 61
        if (!placeholder)                                                                                          // 62
            placeholder = capitalize(this._id);                                                                    // 63
        return placeholder;                                                                                        // 64
    };                                                                                                             // 65
                                                                                                                   // 66
Field.prototype.getStatus = function(){                                                                            // 67
    return this.status.get();                                                                                      // 68
};                                                                                                                 // 69
                                                                                                                   // 70
if (Meteor.isClient)                                                                                               // 71
    Field.prototype.getValue = function(tempalteInstance){                                                         // 72
        if (this.type === "checkbox")                                                                              // 73
            return !!(tempalteInstance.$("#at-field-" + this._id + ":checked").val());                             // 74
        if (this.type === "radio")                                                                                 // 75
            return tempalteInstance.$("[name=at-field-"+ this._id + "]:checked").val();                            // 76
        return tempalteInstance.$("#at-field-" + this._id).val();                                                  // 77
    };                                                                                                             // 78
                                                                                                                   // 79
if (Meteor.isClient)                                                                                               // 80
    Field.prototype.hasError = function() {                                                                        // 81
        return this.negativeValidation && this.status.get();                                                       // 82
    };                                                                                                             // 83
                                                                                                                   // 84
if (Meteor.isClient)                                                                                               // 85
    Field.prototype.hasIcon = function(){                                                                          // 86
        if (this.showValidating && this.isValidating())                                                            // 87
            return true;                                                                                           // 88
        if (this.negativeFeedback && this.hasError())                                                              // 89
            return true;                                                                                           // 90
        if (this.positiveFeedback && this.hasSuccess())                                                            // 91
            return true;                                                                                           // 92
    };                                                                                                             // 93
                                                                                                                   // 94
if (Meteor.isClient)                                                                                               // 95
    Field.prototype.hasSuccess = function() {                                                                      // 96
        return this.positiveValidation && this.status.get() === false;                                             // 97
    };                                                                                                             // 98
                                                                                                                   // 99
if (Meteor.isClient)                                                                                               // 100
    Field.prototype.iconClass = function(){                                                                        // 101
        if (this.isValidating())                                                                                   // 102
            return AccountsTemplates.texts.inputIcons["isValidating"];                                             // 103
        if (this.hasError())                                                                                       // 104
            return AccountsTemplates.texts.inputIcons["hasError"];                                                 // 105
        if (this.hasSuccess())                                                                                     // 106
            return AccountsTemplates.texts.inputIcons["hasSuccess"];                                               // 107
    };                                                                                                             // 108
                                                                                                                   // 109
if (Meteor.isClient)                                                                                               // 110
    Field.prototype.isValidating = function(){                                                                     // 111
        return this.validating.get();                                                                              // 112
    };                                                                                                             // 113
                                                                                                                   // 114
if (Meteor.isClient)                                                                                               // 115
    Field.prototype.setError = function(err){                                                                      // 116
        check(err, Match.OneOf(String, undefined, Boolean));                                                       // 117
        if (err === false)                                                                                         // 118
            return this.status.set(false);                                                                         // 119
        return this.status.set(err || true);                                                                       // 120
    };                                                                                                             // 121
if (Meteor.isServer)                                                                                               // 122
    Field.prototype.setError = function(err){                                                                      // 123
        // Nothing to do server-side                                                                               // 124
        return;                                                                                                    // 125
    };                                                                                                             // 126
                                                                                                                   // 127
if (Meteor.isClient)                                                                                               // 128
    Field.prototype.setSuccess = function(){                                                                       // 129
        return this.status.set(false);                                                                             // 130
    };                                                                                                             // 131
if (Meteor.isServer)                                                                                               // 132
    Field.prototype.setSuccess = function(){                                                                       // 133
        // Nothing to do server-side                                                                               // 134
        return;                                                                                                    // 135
    };                                                                                                             // 136
                                                                                                                   // 137
                                                                                                                   // 138
if (Meteor.isClient)                                                                                               // 139
    Field.prototype.setValidating = function(state){                                                               // 140
        check(state, Boolean);                                                                                     // 141
        return this.validating.set(state);                                                                         // 142
    };                                                                                                             // 143
if (Meteor.isServer)                                                                                               // 144
    Field.prototype.setValidating = function(state){                                                               // 145
        // Nothing to do server-side                                                                               // 146
        return;                                                                                                    // 147
    };                                                                                                             // 148
                                                                                                                   // 149
if (Meteor.isClient)                                                                                               // 150
    Field.prototype.setValue = function(tempalteInstance, value){                                                  // 151
        if (this.type === "checkbox") {                                                                            // 152
            tempalteInstance.$("#at-field-" + this._id).prop('checked', true);                                     // 153
            return;                                                                                                // 154
        }                                                                                                          // 155
        if (this.type === "radio") {                                                                               // 156
            tempalteInstance.$("[name=at-field-"+ this._id + "]").prop('checked', true);                           // 157
            return;                                                                                                // 158
        }                                                                                                          // 159
        tempalteInstance.$("#at-field-" + this._id).val(value);                                                    // 160
    };                                                                                                             // 161
                                                                                                                   // 162
Field.prototype.validate = function(value, strict) {                                                               // 163
    check(value, Match.OneOf(undefined, String, Boolean));                                                         // 164
    this.setValidating(true);                                                                                      // 165
    this.clearStatus();                                                                                            // 166
    if (value === undefined || value === ''){                                                                      // 167
        if (!!strict){                                                                                             // 168
            if (this.required) {                                                                                   // 169
                this.setError(AccountsTemplates.texts.requiredField);                                              // 170
                this.setValidating(false);                                                                         // 171
                return AccountsTemplates.texts.requiredField;                                                      // 172
            }                                                                                                      // 173
            else {                                                                                                 // 174
                this.setSuccess();                                                                                 // 175
                this.setValidating(false);                                                                         // 176
                return false;                                                                                      // 177
            }                                                                                                      // 178
        }                                                                                                          // 179
        else {                                                                                                     // 180
            this.clearStatus();                                                                                    // 181
            this.setValidating(false);                                                                             // 182
            return null;                                                                                           // 183
        }                                                                                                          // 184
    }                                                                                                              // 185
    var valueLength = value.length;                                                                                // 186
    var minLength = this.minLength;                                                                                // 187
    if (minLength && valueLength < minLength) {                                                                    // 188
        this.setError(AccountsTemplates.texts.minRequiredLength + ": " + minLength);                               // 189
        this.setValidating(false);                                                                                 // 190
        return AccountsTemplates.texts.minRequiredLength + ": " + minLength;                                       // 191
    }                                                                                                              // 192
    var maxLength = this.maxLength;                                                                                // 193
    if (maxLength && valueLength > maxLength) {                                                                    // 194
        this.setError(AccountsTemplates.texts.maxAllowedLength + ": " + maxLength);                                // 195
        this.setValidating(false);                                                                                 // 196
        return AccountsTemplates.texts.maxAllowedLength + ": " + maxLength;                                        // 197
    }                                                                                                              // 198
    if (this.re && valueLength && !value.match(this.re)) {                                                         // 199
        this.setError(this.errStr);                                                                                // 200
        this.setValidating(false);                                                                                 // 201
        return this.errStr;                                                                                        // 202
    }                                                                                                              // 203
    if (this.func){                                                                                                // 204
        var result = this.func(value);                                                                             // 205
        var err = result === true ? this.errStr || true : result;                                                  // 206
        if (result === undefined)                                                                                  // 207
            return err;                                                                                            // 208
        this.status.set(err);                                                                                      // 209
        this.setValidating(false);                                                                                 // 210
        return err;                                                                                                // 211
    }                                                                                                              // 212
    this.setSuccess();                                                                                             // 213
    this.setValidating(false);                                                                                     // 214
    return false;                                                                                                  // 215
};                                                                                                                 // 216
                                                                                                                   // 217
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/useraccounts:core/lib/core.js                                                                          //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
// ---------------------------------------------------------------------------------                               // 1
                                                                                                                   // 2
// Patterns for methods" parameters                                                                                // 3
                                                                                                                   // 4
// ---------------------------------------------------------------------------------                               // 5
                                                                                                                   // 6
STATE_PAT = {                                                                                                      // 7
    changePwd: Match.Optional(String),                                                                             // 8
    enrollAccount: Match.Optional(String),                                                                         // 9
    forgotPwd: Match.Optional(String),                                                                             // 10
    resetPwd: Match.Optional(String),                                                                              // 11
    signIn: Match.Optional(String),                                                                                // 12
    signUp: Match.Optional(String),                                                                                // 13
    verifyEmail: Match.Optional(String),                                                                           // 14
    resendVerificationEmail: Match.Optional(String),                                                               // 15
};                                                                                                                 // 16
                                                                                                                   // 17
ERRORS_PAT = {                                                                                                     // 18
    accountsCreationDisabled: Match.Optional(String),                                                              // 19
    cannotRemoveService: Match.Optional(String),                                                                   // 20
    captchaVerification: Match.Optional(String),                                                                   // 21
    loginForbidden: Match.Optional(String),                                                                        // 22
    mustBeLoggedIn: Match.Optional(String),                                                                        // 23
    pwdMismatch: Match.Optional(String),                                                                           // 24
    validationErrors: Match.Optional(String),                                                                      // 25
    verifyEmailFirst: Match.Optional(String),                                                                      // 26
};                                                                                                                 // 27
                                                                                                                   // 28
INFO_PAT = {                                                                                                       // 29
    emailSent: Match.Optional(String),                                                                             // 30
    emailVerified: Match.Optional(String),                                                                         // 31
    pwdChanged: Match.Optional(String),                                                                            // 32
    pwdReset: Match.Optional(String),                                                                              // 33
    pwdSet: Match.Optional(String),                                                                                // 34
    signUpVerifyEmail: Match.Optional(String),                                                                     // 35
    verificationEmailSent: Match.Optional(String),                                                                 // 36
};                                                                                                                 // 37
                                                                                                                   // 38
INPUT_ICONS_PAT = {                                                                                                // 39
    hasError: Match.Optional(String),                                                                              // 40
    hasSuccess: Match.Optional(String),                                                                            // 41
    isValidating: Match.Optional(String),                                                                          // 42
};                                                                                                                 // 43
                                                                                                                   // 44
ObjWithStringValues = Match.Where(function (x) {                                                                   // 45
    check(x, Object);                                                                                              // 46
    _.each(_.values(x), function(value){                                                                           // 47
        check(value, String);                                                                                      // 48
    });                                                                                                            // 49
    return true;                                                                                                   // 50
});                                                                                                                // 51
                                                                                                                   // 52
TEXTS_PAT = {                                                                                                      // 53
    button: Match.Optional(STATE_PAT),                                                                             // 54
    errors: Match.Optional(ERRORS_PAT),                                                                            // 55
    info: Match.Optional(INFO_PAT),                                                                                // 56
    inputIcons: Match.Optional(INPUT_ICONS_PAT),                                                                   // 57
    maxAllowedLength: Match.Optional(String),                                                                      // 58
    minRequiredLength: Match.Optional(String),                                                                     // 59
    navSignIn: Match.Optional(String),                                                                             // 60
    navSignOut: Match.Optional(String),                                                                            // 61
    optionalField: Match.Optional(String),                                                                         // 62
    pwdLink_link: Match.Optional(String),                                                                          // 63
    pwdLink_pre: Match.Optional(String),                                                                           // 64
    pwdLink_suff: Match.Optional(String),                                                                          // 65
    requiredField: Match.Optional(String),                                                                         // 66
    resendVerificationEmailLink_pre: Match.Optional(String),                                                       // 67
    resendVerificationEmailLink_link: Match.Optional(String),                                                      // 68
    resendVerificationEmailLink_suff: Match.Optional(String),                                                      // 69
    sep: Match.Optional(String),                                                                                   // 70
    signInLink_link: Match.Optional(String),                                                                       // 71
    signInLink_pre: Match.Optional(String),                                                                        // 72
    signInLink_suff: Match.Optional(String),                                                                       // 73
    signUpLink_link: Match.Optional(String),                                                                       // 74
    signUpLink_pre: Match.Optional(String),                                                                        // 75
    signUpLink_suff: Match.Optional(String),                                                                       // 76
    socialAdd: Match.Optional(String),                                                                             // 77
    socialConfigure: Match.Optional(String),                                                                       // 78
    socialIcons: Match.Optional(ObjWithStringValues),                                                              // 79
    socialRemove: Match.Optional(String),                                                                          // 80
    socialSignIn: Match.Optional(String),                                                                          // 81
    socialSignUp: Match.Optional(String),                                                                          // 82
    socialWith: Match.Optional(String),                                                                            // 83
    termsAnd: Match.Optional(String),                                                                              // 84
    termsPreamble: Match.Optional(String),                                                                         // 85
    termsPrivacy: Match.Optional(String),                                                                          // 86
    termsTerms: Match.Optional(String),                                                                            // 87
    title: Match.Optional(STATE_PAT),                                                                              // 88
};                                                                                                                 // 89
                                                                                                                   // 90
// Configuration pattern to be checked with check                                                                  // 91
CONFIG_PAT = {                                                                                                     // 92
    // Behaviour                                                                                                   // 93
    confirmPassword: Match.Optional(Boolean),                                                                      // 94
    defaultState: Match.Optional(String),                                                                          // 95
    enablePasswordChange: Match.Optional(Boolean),                                                                 // 96
    enforceEmailVerification: Match.Optional(Boolean),                                                             // 97
    forbidClientAccountCreation: Match.Optional(Boolean),                                                          // 98
    lowercaseUsername: Match.Optional(Boolean),                                                                    // 99
    overrideLoginErrors: Match.Optional(Boolean),                                                                  // 100
    sendVerificationEmail: Match.Optional(Boolean),                                                                // 101
    socialLoginStyle: Match.Optional(Match.OneOf("popup", "redirect")),                                            // 102
                                                                                                                   // 103
    // Appearance                                                                                                  // 104
    defaultLayout: Match.Optional(String),                                                                         // 105
    hideSignInLink: Match.Optional(Boolean),                                                                       // 106
    hideSignUpLink: Match.Optional(Boolean),                                                                       // 107
    showAddRemoveServices: Match.Optional(Boolean),                                                                // 108
    showForgotPasswordLink: Match.Optional(Boolean),                                                               // 109
    showResendVerificationEmailLink: Match.Optional(Boolean),                                                      // 110
    showLabels: Match.Optional(Boolean),                                                                           // 111
    showPlaceholders: Match.Optional(Boolean),                                                                     // 112
                                                                                                                   // 113
    // Client-side Validation                                                                                      // 114
    continuousValidation: Match.Optional(Boolean),                                                                 // 115
    negativeFeedback: Match.Optional(Boolean),                                                                     // 116
    negativeValidation: Match.Optional(Boolean),                                                                   // 117
    positiveFeedback: Match.Optional(Boolean),                                                                     // 118
    positiveValidation: Match.Optional(Boolean),                                                                   // 119
    showValidating: Match.Optional(Boolean),                                                                       // 120
                                                                                                                   // 121
    // Privacy Policy and Terms of Use                                                                             // 122
    privacyUrl: Match.Optional(String),                                                                            // 123
    termsUrl: Match.Optional(String),                                                                              // 124
                                                                                                                   // 125
    // Redirects                                                                                                   // 126
    homeRoutePath: Match.Optional(String),                                                                         // 127
    redirectTimeout: Match.Optional(Number),                                                                       // 128
                                                                                                                   // 129
    // Hooks                                                                                                       // 130
    onLogoutHook: Match.Optional(Function),                                                                        // 131
    onSubmitHook: Match.Optional(Function),                                                                        // 132
    preSignUpHook: Match.Optional(Function),                                                                       // 133
                                                                                                                   // 134
    texts: Match.Optional(TEXTS_PAT),                                                                              // 135
                                                                                                                   // 136
    //reCaptcha config                                                                                             // 137
    reCaptcha: Match.Optional({                                                                                    // 138
        data_type: Match.Optional(Match.OneOf("audio", "image")),                                                  // 139
        secretKey: Match.Optional(String),                                                                         // 140
        siteKey: Match.Optional(String),                                                                           // 141
        theme: Match.Optional(Match.OneOf("dark", "light")),                                                       // 142
    }),                                                                                                            // 143
                                                                                                                   // 144
    showReCaptcha: Match.Optional(Boolean),                                                                        // 145
};                                                                                                                 // 146
                                                                                                                   // 147
                                                                                                                   // 148
FIELD_SUB_PAT = {                                                                                                  // 149
    "default": Match.Optional(String),                                                                             // 150
    changePwd: Match.Optional(String),                                                                             // 151
    enrollAccount: Match.Optional(String),                                                                         // 152
    forgotPwd: Match.Optional(String),                                                                             // 153
    resetPwd: Match.Optional(String),                                                                              // 154
    signIn: Match.Optional(String),                                                                                // 155
    signUp: Match.Optional(String),                                                                                // 156
};                                                                                                                 // 157
                                                                                                                   // 158
                                                                                                                   // 159
// Field pattern                                                                                                   // 160
FIELD_PAT = {                                                                                                      // 161
    _id: String,                                                                                                   // 162
    type: String,                                                                                                  // 163
    required: Match.Optional(Boolean),                                                                             // 164
    displayName: Match.Optional(Match.OneOf(String, FIELD_SUB_PAT)),                                               // 165
    placeholder: Match.Optional(Match.OneOf(String, FIELD_SUB_PAT)),                                               // 166
    select: Match.Optional([{text: String, value: Match.Any}]),                                                    // 167
    minLength: Match.Optional(Match.Integer),                                                                      // 168
    maxLength: Match.Optional(Match.Integer),                                                                      // 169
    re: Match.Optional(RegExp),                                                                                    // 170
    func: Match.Optional(Match.Where(_.isFunction)),                                                               // 171
    errStr: Match.Optional(String),                                                                                // 172
                                                                                                                   // 173
    // Client-side Validation                                                                                      // 174
    continuousValidation: Match.Optional(Boolean),                                                                 // 175
    negativeFeedback: Match.Optional(Boolean),                                                                     // 176
    negativeValidation: Match.Optional(Boolean),                                                                   // 177
    positiveValidation: Match.Optional(Boolean),                                                                   // 178
    positiveFeedback: Match.Optional(Boolean),                                                                     // 179
                                                                                                                   // 180
    // Transforms                                                                                                  // 181
    trim: Match.Optional(Boolean),                                                                                 // 182
    lowercase: Match.Optional(Boolean),                                                                            // 183
    uppercase: Match.Optional(Boolean),                                                                            // 184
    transform: Match.Optional(Match.Where(_.isFunction)),                                                          // 185
                                                                                                                   // 186
    // Custom options                                                                                              // 187
    options: Match.Optional(Object),                                                                               // 188
    template: Match.Optional(String),                                                                              // 189
};                                                                                                                 // 190
                                                                                                                   // 191
// Route configuration pattern to be checked with check                                                            // 192
var ROUTE_PAT = {                                                                                                  // 193
    name: Match.Optional(String),                                                                                  // 194
    path: Match.Optional(String),                                                                                  // 195
    template: Match.Optional(String),                                                                              // 196
    layoutTemplate: Match.Optional(String),                                                                        // 197
    redirect: Match.Optional(Match.OneOf(String, Match.Where(_.isFunction))),                                      // 198
};                                                                                                                 // 199
                                                                                                                   // 200
                                                                                                                   // 201
// -----------------------------------------------------------------------------                                   // 202
                                                                                                                   // 203
// AccountsTemplates object                                                                                        // 204
                                                                                                                   // 205
// -----------------------------------------------------------------------------                                   // 206
                                                                                                                   // 207
                                                                                                                   // 208
                                                                                                                   // 209
// -------------------                                                                                             // 210
// Client/Server stuff                                                                                             // 211
// -------------------                                                                                             // 212
                                                                                                                   // 213
// Constructor                                                                                                     // 214
AT = function() {                                                                                                  // 215
                                                                                                                   // 216
};                                                                                                                 // 217
                                                                                                                   // 218
                                                                                                                   // 219
                                                                                                                   // 220
                                                                                                                   // 221
/*                                                                                                                 // 222
    Each field object is represented by the following properties:                                                  // 223
        _id:         String   (required)  // A unique field"s id / name                                            // 224
        type:        String   (required)  // Displayed input type                                                  // 225
        required:    Boolean  (optional)  // Specifies Whether to fail or not when field is left empty             // 226
        displayName: String   (optional)  // The field"s name to be displayed as a label above the input element   // 227
        placeholder: String   (optional)  // The placeholder text to be displayed inside the input element         // 228
        minLength:   Integer  (optional)  // Possibly specifies the minimum allowed length                         // 229
        maxLength:   Integer  (optional)  // Possibly specifies the maximum allowed length                         // 230
        re:          RegExp   (optional)  // Regular expression for validation                                     // 231
        func:        Function (optional)  // Custom function for validation                                        // 232
        errStr:      String   (optional)  // Error message to be displayed in case re validation fails             // 233
*/                                                                                                                 // 234
                                                                                                                   // 235
                                                                                                                   // 236
                                                                                                                   // 237
/*                                                                                                                 // 238
    Routes configuration can be done by calling AccountsTemplates.configureRoute with the route name and the       // 239
    following options in a separate object. E.g. AccountsTemplates.configureRoute("gingIn", option);               // 240
        name:           String (optional). A unique route"s name to be passed to iron-router                       // 241
        path:           String (optional). A unique route"s path to be passed to iron-router                       // 242
        template:       String (optional). The name of the template to be rendered                                 // 243
        layoutTemplate: String (optional). The name of the layout to be used                                       // 244
        redirect:       String (optional). The name of the route (or its path) where to redirect after form submit // 245
*/                                                                                                                 // 246
                                                                                                                   // 247
                                                                                                                   // 248
// Allowed routes along with theirs default configuration values                                                   // 249
AT.prototype.ROUTE_DEFAULT = {                                                                                     // 250
    changePwd:      { name: "atChangePwd",      path: "/change-password"},                                         // 251
    enrollAccount:  { name: "atEnrollAccount",  path: "/enroll-account"},                                          // 252
    ensureSignedIn: { name: "atEnsureSignedIn", path: null},                                                       // 253
    forgotPwd:      { name: "atForgotPwd",      path: "/forgot-password"},                                         // 254
    resetPwd:       { name: "atResetPwd",       path: "/reset-password"},                                          // 255
    signIn:         { name: "atSignIn",         path: "/sign-in"},                                                 // 256
    signUp:         { name: "atSignUp",         path: "/sign-up"},                                                 // 257
    verifyEmail:    { name: "atVerifyEmail",    path: "/verify-email"},                                            // 258
    resendVerificationEmail: { name: "atResendVerificationEmail", path: "/send-again"},                            // 259
};                                                                                                                 // 260
                                                                                                                   // 261
                                                                                                                   // 262
                                                                                                                   // 263
// Allowed input types                                                                                             // 264
AT.prototype.INPUT_TYPES = [                                                                                       // 265
    "checkbox",                                                                                                    // 266
    "email",                                                                                                       // 267
    "hidden",                                                                                                      // 268
    "password",                                                                                                    // 269
    "radio",                                                                                                       // 270
    "select",                                                                                                      // 271
    "tel",                                                                                                         // 272
    "text",                                                                                                        // 273
    "url",                                                                                                         // 274
];                                                                                                                 // 275
                                                                                                                   // 276
// Current configuration values                                                                                    // 277
AT.prototype.options = {                                                                                           // 278
    // Appearance                                                                                                  // 279
    //defaultLayout: undefined,                                                                                    // 280
    showAddRemoveServices: false,                                                                                  // 281
    showForgotPasswordLink: false,                                                                                 // 282
    showResendVerificationEmailLink: false,                                                                        // 283
    showLabels: true,                                                                                              // 284
    showPlaceholders: true,                                                                                        // 285
                                                                                                                   // 286
    // Behaviour                                                                                                   // 287
    confirmPassword: true,                                                                                         // 288
    defaultState: "signIn",                                                                                        // 289
    enablePasswordChange: false,                                                                                   // 290
    forbidClientAccountCreation: false,                                                                            // 291
    lowercaseUsername: false,                                                                                      // 292
    overrideLoginErrors: true,                                                                                     // 293
    sendVerificationEmail: false,                                                                                  // 294
    socialLoginStyle: "popup",                                                                                     // 295
                                                                                                                   // 296
    // Client-side Validation                                                                                      // 297
    //continuousValidation: false,                                                                                 // 298
    //negativeFeedback: false,                                                                                     // 299
    //negativeValidation: false,                                                                                   // 300
    //positiveValidation: false,                                                                                   // 301
    //positiveFeedback: false,                                                                                     // 302
    //showValidating: false,                                                                                       // 303
                                                                                                                   // 304
    // Privacy Policy and Terms of Use                                                                             // 305
    privacyUrl: undefined,                                                                                         // 306
    termsUrl: undefined,                                                                                           // 307
                                                                                                                   // 308
    // Redirects                                                                                                   // 309
    homeRoutePath: "/",                                                                                            // 310
    redirectTimeout: 2000, // 2 seconds                                                                            // 311
                                                                                                                   // 312
    // Hooks                                                                                                       // 313
    onSubmitHook: undefined,                                                                                       // 314
};                                                                                                                 // 315
                                                                                                                   // 316
AT.prototype.texts = {                                                                                             // 317
    button: {                                                                                                      // 318
        changePwd: "updateYourPassword",                                                                           // 319
        //enrollAccount: "createAccount",                                                                          // 320
        enrollAccount: "signUp",                                                                                   // 321
        forgotPwd: "emailResetLink",                                                                               // 322
        resetPwd: "setPassword",                                                                                   // 323
        signIn: "signIn",                                                                                          // 324
        signUp: "signUp",                                                                                          // 325
        resendVerificationEmail: "Send email again",                                                               // 326
    },                                                                                                             // 327
    errors: {                                                                                                      // 328
        accountsCreationDisabled: "Client side accounts creation is disabled!!!",                                  // 329
        cannotRemoveService: "Cannot remove the only active service!",                                             // 330
        captchaVerification: "Captcha verification failed!",                                                       // 331
        loginForbidden: "error.accounts.Login forbidden",                                                          // 332
        mustBeLoggedIn: "error.accounts.Must be logged in",                                                        // 333
        pwdMismatch: "error.pwdsDontMatch",                                                                        // 334
        validationErrors: "Validation Errors",                                                                     // 335
        verifyEmailFirst: "Please verify your email first. Check the email and follow the link!",                  // 336
    },                                                                                                             // 337
    navSignIn: 'signIn',                                                                                           // 338
    navSignOut: 'signOut',                                                                                         // 339
    info: {                                                                                                        // 340
        emailSent: "info.emailSent",                                                                               // 341
        emailVerified: "info.emailVerified",                                                                       // 342
        pwdChanged: "info.passwordChanged",                                                                        // 343
        pwdReset: "info.passwordReset",                                                                            // 344
        pwdSet: "Password Set",                                                                                    // 345
        signUpVerifyEmail: "Successful Registration! Please check your email and follow the instructions.",        // 346
        verificationEmailSent: "A new email has been sent to you. If the email doesn't show up in your inbox, be sure to check your spam folder.",
    },                                                                                                             // 348
    inputIcons: {                                                                                                  // 349
        isValidating: "fa fa-spinner fa-spin",                                                                     // 350
        hasSuccess: "fa fa-check",                                                                                 // 351
        hasError: "fa fa-times",                                                                                   // 352
    },                                                                                                             // 353
    maxAllowedLength: "Maximum allowed length",                                                                    // 354
    minRequiredLength: "Minimum required length",                                                                  // 355
    optionalField: "optional",                                                                                     // 356
    pwdLink_pre: "",                                                                                               // 357
    pwdLink_link: "forgotPassword",                                                                                // 358
    pwdLink_suff: "",                                                                                              // 359
    requiredField: "Required Field",                                                                               // 360
    resendVerificationEmailLink_pre: "Verification email lost?",                                                   // 361
    resendVerificationEmailLink_link: "Send again",                                                                // 362
    resendVerificationEmailLink_suff: "",                                                                          // 363
    sep: "OR",                                                                                                     // 364
    signInLink_pre: "ifYouAlreadyHaveAnAccount",                                                                   // 365
    signInLink_link: "signin",                                                                                     // 366
    signInLink_suff: "",                                                                                           // 367
    signUpLink_pre: "dontHaveAnAccount",                                                                           // 368
    signUpLink_link: "signUp",                                                                                     // 369
    signUpLink_suff: "",                                                                                           // 370
    socialAdd: "add",                                                                                              // 371
    socialConfigure: "configure",                                                                                  // 372
    socialIcons: {                                                                                                 // 373
        "meteor-developer": "fa fa-rocket"                                                                         // 374
    },                                                                                                             // 375
    socialRemove: "remove",                                                                                        // 376
    socialSignIn: "signIn",                                                                                        // 377
    socialSignUp: "signUp",                                                                                        // 378
    socialWith: "with",                                                                                            // 379
    termsPreamble: "clickAgree",                                                                                   // 380
    termsPrivacy: "privacyPolicy",                                                                                 // 381
    termsAnd: "and",                                                                                               // 382
    termsTerms: "terms",                                                                                           // 383
    title: {                                                                                                       // 384
        changePwd: "changePassword",                                                                               // 385
        enrollAccount: "createAccount",                                                                            // 386
        forgotPwd: "resetYourPassword",                                                                            // 387
        resetPwd: "resetYourPassword",                                                                             // 388
        signIn: "signIn",                                                                                          // 389
        signUp: "createAccount",                                                                                   // 390
        verifyEmail: "",                                                                                           // 391
        resendVerificationEmail: "Send the verification email again",                                              // 392
    },                                                                                                             // 393
};                                                                                                                 // 394
                                                                                                                   // 395
AT.prototype.SPECIAL_FIELDS = [                                                                                    // 396
    "password_again",                                                                                              // 397
    "username_and_email",                                                                                          // 398
];                                                                                                                 // 399
                                                                                                                   // 400
// SignIn / SignUp fields                                                                                          // 401
AT.prototype._fields = [                                                                                           // 402
    new Field({                                                                                                    // 403
        _id: "email",                                                                                              // 404
        type: "email",                                                                                             // 405
        required: true,                                                                                            // 406
        lowercase: true,                                                                                           // 407
        trim: true,                                                                                                // 408
        func: function(email){                                                                                     // 409
            return !_.contains(email, '@');                                                                        // 410
        },                                                                                                         // 411
        errStr: 'Invalid email',                                                                                   // 412
    }),                                                                                                            // 413
    new Field({                                                                                                    // 414
        _id: "password",                                                                                           // 415
        type: "password",                                                                                          // 416
        required: true,                                                                                            // 417
        minLength: 6,                                                                                              // 418
        displayName: {                                                                                             // 419
            "default": "password",                                                                                 // 420
            changePwd: "newPassword",                                                                              // 421
            resetPwd: "newPassword",                                                                               // 422
        },                                                                                                         // 423
        placeholder: {                                                                                             // 424
            "default": "password",                                                                                 // 425
            changePwd: "newPassword",                                                                              // 426
            resetPwd: "newPassword",                                                                               // 427
        },                                                                                                         // 428
    }),                                                                                                            // 429
];                                                                                                                 // 430
                                                                                                                   // 431
// Configured routes                                                                                               // 432
AT.prototype.routes = {};                                                                                          // 433
                                                                                                                   // 434
AT.prototype._initialized = false;                                                                                 // 435
                                                                                                                   // 436
// Input type validation                                                                                           // 437
AT.prototype._isValidInputType = function(value) {                                                                 // 438
    return _.indexOf(this.INPUT_TYPES, value) !== -1;                                                              // 439
};                                                                                                                 // 440
                                                                                                                   // 441
AT.prototype.addField = function(field) {                                                                          // 442
    // Fields can be added only before initialization                                                              // 443
    if (this._initialized)                                                                                         // 444
        throw new Error("AccountsTemplates.addField should strictly be called before AccountsTemplates.init!");    // 445
    field = _.pick(field, _.keys(FIELD_PAT));                                                                      // 446
    check(field, FIELD_PAT);                                                                                       // 447
    // Checks there"s currently no field called field._id                                                          // 448
    if (_.indexOf(_.pluck(this._fields, "_id"), field._id) !== -1)                                                 // 449
        throw new Error("A field called " + field._id + " already exists!");                                       // 450
    // Validates field.type                                                                                        // 451
    if (!this._isValidInputType(field.type))                                                                       // 452
        throw new Error("field.type is not valid!");                                                               // 453
    // Checks field.minLength is strictly positive                                                                 // 454
    if (typeof field.minLength !== "undefined" && field.minLength <= 0)                                            // 455
        throw new Error("field.minLength should be greater than zero!");                                           // 456
    // Checks field.maxLength is strictly positive                                                                 // 457
    if (typeof field.maxLength !== "undefined" && field.maxLength <= 0)                                            // 458
        throw new Error("field.maxLength should be greater than zero!");                                           // 459
    // Checks field.maxLength is greater than field.minLength                                                      // 460
    if (typeof field.minLength !== "undefined" && typeof field.minLength !== "undefined" && field.maxLength < field.minLength)
        throw new Error("field.maxLength should be greater than field.maxLength!");                                // 462
                                                                                                                   // 463
    if (!(Meteor.isServer && _.contains(this.SPECIAL_FIELDS, field._id)))                                          // 464
        this._fields.push(new Field(field));                                                                       // 465
    return this._fields;                                                                                           // 466
};                                                                                                                 // 467
                                                                                                                   // 468
AT.prototype.addFields = function(fields) {                                                                        // 469
    var ok;                                                                                                        // 470
    try { // don"t bother with `typeof` - just access `length` and `catch`                                         // 471
        ok = fields.length > 0 && "0" in Object(fields);                                                           // 472
    } catch (e) {                                                                                                  // 473
        throw new Error("field argument should be an array of valid field objects!");                              // 474
    }                                                                                                              // 475
    if (ok) {                                                                                                      // 476
        _.map(fields, function(field){                                                                             // 477
            this.addField(field);                                                                                  // 478
        }, this);                                                                                                  // 479
    } else                                                                                                         // 480
        throw new Error("field argument should be an array of valid field objects!");                              // 481
    return this._fields;                                                                                           // 482
};                                                                                                                 // 483
                                                                                                                   // 484
AT.prototype.configure = function(config) {                                                                        // 485
    // Configuration options can be set only before initialization                                                 // 486
    if (this._initialized)                                                                                         // 487
        throw new Error("Configuration options must be set before AccountsTemplates.init!");                       // 488
                                                                                                                   // 489
    // Updates the current configuration                                                                           // 490
    check(config, CONFIG_PAT);                                                                                     // 491
    var options = _.omit(config, "texts", "reCaptcha");                                                            // 492
    this.options = _.defaults(options, this.options);                                                              // 493
                                                                                                                   // 494
    // Possibly sets up reCaptcha options                                                                          // 495
    var reCaptcha = config.reCaptcha;                                                                              // 496
    if (reCaptcha) {                                                                                               // 497
        // Updates the current button object                                                                       // 498
        this.options.reCaptcha = _.defaults(reCaptcha, this.options.reCaptcha || {});                              // 499
    }                                                                                                              // 500
                                                                                                                   // 501
    // Possibly sets up texts...                                                                                   // 502
    if (config.texts){                                                                                             // 503
        var texts = config.texts;                                                                                  // 504
        var simpleTexts = _.omit(texts, "button", "errors", "info", "inputIcons", "socialIcons", "title");         // 505
        this.texts = _.defaults(simpleTexts, this.texts);                                                          // 506
                                                                                                                   // 507
        if (texts.button) {                                                                                        // 508
            // Updates the current button object                                                                   // 509
            this.texts.button = _.defaults(texts.button, this.texts.button);                                       // 510
        }                                                                                                          // 511
        if (texts.errors) {                                                                                        // 512
            // Updates the current errors object                                                                   // 513
            this.texts.errors = _.defaults(texts.errors, this.texts.errors);                                       // 514
        }                                                                                                          // 515
        if (texts.info) {                                                                                          // 516
            // Updates the current info object                                                                     // 517
            this.texts.info = _.defaults(texts.info, this.texts.info);                                             // 518
        }                                                                                                          // 519
        if (texts.inputIcons) {                                                                                    // 520
            // Updates the current inputIcons object                                                               // 521
            this.texts.inputIcons = _.defaults(texts.inputIcons, this.texts.inputIcons);                           // 522
        }                                                                                                          // 523
        if (texts.socialIcons) {                                                                                   // 524
            // Updates the current socialIcons object                                                              // 525
            this.texts.socialIcons = _.defaults(texts.socialIcons, this.texts.socialIcons);                        // 526
        }                                                                                                          // 527
        if (texts.title) {                                                                                         // 528
            // Updates the current title object                                                                    // 529
            this.texts.title = _.defaults(texts.title, this.texts.title);                                          // 530
        }                                                                                                          // 531
    }                                                                                                              // 532
};                                                                                                                 // 533
                                                                                                                   // 534
AT.prototype.configureRoute = function(route, options) {                                                           // 535
    check(route, String);                                                                                          // 536
    check(options, Match.OneOf(undefined, Match.ObjectIncluding(ROUTE_PAT)));                                      // 537
    options = _.clone(options);                                                                                    // 538
    // Route Configuration can be done only before initialization                                                  // 539
    if (this._initialized)                                                                                         // 540
        throw new Error("Route Configuration can be done only before AccountsTemplates.init!");                    // 541
    // Only allowed routes can be configured                                                                       // 542
    if (!(route in this.ROUTE_DEFAULT))                                                                            // 543
        throw new Error("Unknown Route!");                                                                         // 544
                                                                                                                   // 545
    // Possibly adds a initial / to the provided path                                                              // 546
    if (options && options.path && options.path[0] !== "/")                                                        // 547
        options.path = "/" + options.path;                                                                         // 548
    // Updates the current configuration                                                                           // 549
    options = _.defaults(options || {}, this.ROUTE_DEFAULT[route]);                                                // 550
    this.routes[route] = options;                                                                                  // 551
};                                                                                                                 // 552
                                                                                                                   // 553
AT.prototype.hasField = function(fieldId) {                                                                        // 554
    return !!this.getField(fieldId);                                                                               // 555
};                                                                                                                 // 556
                                                                                                                   // 557
AT.prototype.getField = function(fieldId) {                                                                        // 558
    var field = _.filter(this._fields, function(field){                                                            // 559
        return field._id == fieldId;                                                                               // 560
    });                                                                                                            // 561
    return (field.length === 1) ? field[0] : undefined;                                                            // 562
};                                                                                                                 // 563
                                                                                                                   // 564
AT.prototype.getFields = function() {                                                                              // 565
    return this._fields;                                                                                           // 566
};                                                                                                                 // 567
                                                                                                                   // 568
AT.prototype.getFieldIds = function() {                                                                            // 569
    return _.pluck(this._fields, "_id");                                                                           // 570
};                                                                                                                 // 571
                                                                                                                   // 572
AT.prototype.getRouteName = function(route) {                                                                      // 573
    if (route in this.routes)                                                                                      // 574
        return this.routes[route].name;                                                                            // 575
    return null;                                                                                                   // 576
};                                                                                                                 // 577
                                                                                                                   // 578
AT.prototype.getRoutePath = function(route) {                                                                      // 579
    if (route in this.routes)                                                                                      // 580
        return this.routes[route].path;                                                                            // 581
    return "#";                                                                                                    // 582
};                                                                                                                 // 583
                                                                                                                   // 584
AT.prototype.oauthServices = function(){                                                                           // 585
    // Extracts names of available services                                                                        // 586
    var names;                                                                                                     // 587
    if (Meteor.isServer)                                                                                           // 588
        names = (Accounts.oauth && Accounts.oauth.serviceNames()) || [];                                           // 589
    else                                                                                                           // 590
        names = (Accounts.oauth && Accounts.loginServicesConfigured() && Accounts.oauth.serviceNames()) || [];     // 591
    // Extracts names of configured services                                                                       // 592
    var configuredServices = [];                                                                                   // 593
    if (Accounts.loginServiceConfiguration)                                                                        // 594
        configuredServices = _.pluck(Accounts.loginServiceConfiguration.find().fetch(), "service");                // 595
                                                                                                                   // 596
    // Builds a list of objects containing service name as _id and its configuration status                        // 597
    var services = _.map(names, function(name){                                                                    // 598
        return {                                                                                                   // 599
            _id : name,                                                                                            // 600
            configured: _.contains(configuredServices, name),                                                      // 601
        };                                                                                                         // 602
    });                                                                                                            // 603
                                                                                                                   // 604
    // Checks whether there is a UI to configure services...                                                       // 605
    // XXX: this only works with the accounts-ui package                                                           // 606
    var showUnconfigured = typeof Accounts._loginButtonsSession !== "undefined";                                   // 607
                                                                                                                   // 608
    // Filters out unconfigured services in case they"re not to be displayed                                       // 609
    if (!showUnconfigured){                                                                                        // 610
        services = _.filter(services, function(service){                                                           // 611
            return service.configured;                                                                             // 612
        });                                                                                                        // 613
    }                                                                                                              // 614
                                                                                                                   // 615
    // Sorts services by name                                                                                      // 616
    services = _.sortBy(services, function(service){                                                               // 617
        return service._id;                                                                                        // 618
    });                                                                                                            // 619
                                                                                                                   // 620
    return services;                                                                                               // 621
};                                                                                                                 // 622
                                                                                                                   // 623
AT.prototype.removeField = function(fieldId) {                                                                     // 624
    // Fields can be removed only before initialization                                                            // 625
    if (this._initialized)                                                                                         // 626
        throw new Error("AccountsTemplates.removeField should strictly be called before AccountsTemplates.init!"); // 627
    // Tries to look up the field with given _id                                                                   // 628
    var index = _.indexOf(_.pluck(this._fields, "_id"), fieldId);                                                  // 629
    if (index !== -1)                                                                                              // 630
        return this._fields.splice(index, 1)[0];                                                                   // 631
    else                                                                                                           // 632
        if (!(Meteor.isServer && _.contains(this.SPECIAL_FIELDS, fieldId)))                                        // 633
            throw new Error("A field called " + fieldId + " does not exist!");                                     // 634
};                                                                                                                 // 635
                                                                                                                   // 636
AT.prototype.setupRoutes = function() {                                                                            // 637
    if (Meteor.isServer){                                                                                          // 638
        // Possibly prints a warning in case showForgotPasswordLink is set to true but the route is not configured // 639
        // if (AccountsTemplates.options.showForgotPasswordLink && !("forgotPwd" in  AccountsTemplates.routes))    // 640
        //    console.warn("[AccountsTemplates] WARNING: showForgotPasswordLink set to true, but forgotPwd route is not configured!");
        // Configures "reset password" email link                                                                  // 642
        if ("resetPwd" in AccountsTemplates.routes){                                                               // 643
            var resetPwdPath = AccountsTemplates.routes["resetPwd"].path.substr(1);                                // 644
            Accounts.urls.resetPassword = function(token){                                                         // 645
                return Meteor.absoluteUrl(resetPwdPath + "/" + token);                                             // 646
            };                                                                                                     // 647
        }                                                                                                          // 648
        // Configures "enroll account" email link                                                                  // 649
        if ("enrollAccount" in AccountsTemplates.routes){                                                          // 650
            var enrollAccountPath = AccountsTemplates.routes["enrollAccount"].path.substr(1);                      // 651
            Accounts.urls.enrollAccount = function(token){                                                         // 652
                return Meteor.absoluteUrl(enrollAccountPath + "/" + token);                                        // 653
            };                                                                                                     // 654
        }                                                                                                          // 655
        // Configures "verify email" email link                                                                    // 656
        if ("verifyEmail" in AccountsTemplates.routes){                                                            // 657
            var verifyEmailPath = AccountsTemplates.routes["verifyEmail"].path.substr(1);                          // 658
            Accounts.urls.verifyEmail = function(token){                                                           // 659
                return Meteor.absoluteUrl(verifyEmailPath + "/" + token);                                          // 660
            };                                                                                                     // 661
        }                                                                                                          // 662
    }                                                                                                              // 663
                                                                                                                   // 664
    // Determines the default layout to be used in case no specific one is specified for single routes             // 665
    var defaultLayout = AccountsTemplates.options.defaultLayout || Router.options.layoutTemplate;                  // 666
                                                                                                                   // 667
    _.each(AccountsTemplates.routes, function(options, route){                                                     // 668
        if (route === "ensureSignedIn")                                                                            // 669
            return;                                                                                                // 670
        if (route === "changePwd" && !AccountsTemplates.options.enablePasswordChange)                              // 671
            throw new Error("changePwd route configured but enablePasswordChange set to false!");                  // 672
        if (route === "forgotPwd" && !AccountsTemplates.options.showForgotPasswordLink)                            // 673
            throw new Error("forgotPwd route configured but showForgotPasswordLink set to false!");                // 674
        if (route === "signUp" && AccountsTemplates.options.forbidClientAccountCreation)                           // 675
            throw new Error("signUp route configured but forbidClientAccountCreation set to true!");               // 676
        // Possibly prints a warning in case the MAIL_URL environment variable was not set                         // 677
        //if (Meteor.isServer && route === "forgotPwd" && (!process.env.MAIL_URL || ! Package["email"])){          // 678
        //    console.warn("[AccountsTemplates] WARNING: showForgotPasswordLink set to true, but MAIL_URL is not configured!");
        //}                                                                                                        // 680
                                                                                                                   // 681
        var name = options.name; // Default provided...                                                            // 682
        var path = options.path; // Default provided...                                                            // 683
        var template = options.template || "fullPageAtForm";                                                       // 684
        var layoutTemplate = options.layoutTemplate || defaultLayout;                                              // 685
        var additionalOptions = _.omit(options, [                                                                  // 686
          "layoutTemplate", "name", "path", "redirect", "template"                                                 // 687
        ]);                                                                                                        // 688
                                                                                                                   // 689
        // Possibly adds token parameter                                                                           // 690
        if (_.contains(["enrollAccount", "resetPwd", "verifyEmail"], route)){                                      // 691
            path += "/:paramToken";                                                                                // 692
            if (route === "verifyEmail")                                                                           // 693
                Router.route(path, _.extend(additionalOptions, {                                                   // 694
                    name: name,                                                                                    // 695
                    template: template,                                                                            // 696
                    layoutTemplate: layoutTemplate,                                                                // 697
                    onRun: function() {                                                                            // 698
                        AccountsTemplates.setState(route);                                                         // 699
                        AccountsTemplates.setDisabled(true);                                                       // 700
                        var token = this.params.paramToken;                                                        // 701
                        Accounts.verifyEmail(token, function(error){                                               // 702
                            AccountsTemplates.setDisabled(false);                                                  // 703
                            AccountsTemplates.submitCallback(error, route, function(){                             // 704
                                AccountsTemplates.state.form.set("result", AccountsTemplates.texts.info.emailVerified);
                            });                                                                                    // 706
                        });                                                                                        // 707
                                                                                                                   // 708
                        this.next();                                                                               // 709
                    },                                                                                             // 710
                    onStop: function() {                                                                           // 711
                        AccountsTemplates.clearState();                                                            // 712
                    },                                                                                             // 713
                }));                                                                                               // 714
            else                                                                                                   // 715
                Router.route(path, _.extend(additionalOptions, {                                                   // 716
                    name: name,                                                                                    // 717
                    template: template,                                                                            // 718
                    layoutTemplate: layoutTemplate,                                                                // 719
                    onBeforeAction: function() {                                                                   // 720
                        AccountsTemplates.paramToken = this.params.paramToken;                                     // 721
                        AccountsTemplates.setState(route);                                                         // 722
                        this.next();                                                                               // 723
                    },                                                                                             // 724
                    onStop: function() {                                                                           // 725
                        AccountsTemplates.clearState();                                                            // 726
                        AccountsTemplates.paramToken = null;                                                       // 727
                    }                                                                                              // 728
                }));                                                                                               // 729
        }                                                                                                          // 730
        else                                                                                                       // 731
            Router.route(path, _.extend(additionalOptions, {                                                       // 732
                name: name,                                                                                        // 733
                template: template,                                                                                // 734
                layoutTemplate: layoutTemplate,                                                                    // 735
                onBeforeAction: function() {                                                                       // 736
                    var redirect = false;                                                                          // 737
                    if (route === 'changePwd') {                                                                   // 738
                      if (!Meteor.loggingIn() && !Meteor.userId()) {                                               // 739
                        redirect = true;                                                                           // 740
                      }                                                                                            // 741
                    }                                                                                              // 742
                    else if (Meteor.userId()) {                                                                    // 743
                        redirect = true;                                                                           // 744
                    }                                                                                              // 745
                    if (redirect) {                                                                                // 746
                        AccountsTemplates.postSubmitRedirect(route);                                               // 747
                        this.stop();                                                                               // 748
                    }                                                                                              // 749
                    else {                                                                                         // 750
                        AccountsTemplates.setState(route);                                                         // 751
                        this.next();                                                                               // 752
                    }                                                                                              // 753
                },                                                                                                 // 754
                onStop: function() {                                                                               // 755
                    AccountsTemplates.clearState();                                                                // 756
                }                                                                                                  // 757
            }));                                                                                                   // 758
    });                                                                                                            // 759
};                                                                                                                 // 760
                                                                                                                   // 761
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/useraccounts:core/lib/server.js                                                                        //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
// Initialization                                                                                                  // 1
                                                                                                                   // 2
AT.prototype.init = function() {                                                                                   // 3
    console.warn("[AccountsTemplates] There is no more need to call AccountsTemplates.init()! Simply remove the call ;-)");
};                                                                                                                 // 5
                                                                                                                   // 6
AT.prototype._init = function() {                                                                                  // 7
    if (this._initialized)                                                                                         // 8
        return;                                                                                                    // 9
                                                                                                                   // 10
    // Checks there is at least one account service installed                                                      // 11
    if (!Package["accounts-password"] && (!Accounts.oauth || Accounts.oauth.serviceNames().length === 0))          // 12
        throw Error("AccountsTemplates: You must add at least one account service!");                              // 13
                                                                                                                   // 14
    // A password field is strictly required                                                                       // 15
    var password = this.getField("password");                                                                      // 16
    if (!password)                                                                                                 // 17
        throw Error("A password field is strictly required!");                                                     // 18
    if (password.type !== "password")                                                                              // 19
        throw Error("The type of password field should be password!");                                             // 20
                                                                                                                   // 21
    // Then we can have "username" or "email" or even both of them                                                 // 22
    // but at least one of the two is strictly required                                                            // 23
    var username = this.getField("username");                                                                      // 24
    var email = this.getField("email");                                                                            // 25
    if (!username && !email)                                                                                       // 26
        throw Error("At least one field out of username and email is strictly required!");                         // 27
    if (username && !username.required)                                                                            // 28
        throw Error("The username field should be required!");                                                     // 29
    if (email){                                                                                                    // 30
        if (email.type !== "email")                                                                                // 31
            throw Error("The type of email field should be email!");                                               // 32
        if (username){                                                                                             // 33
            // username and email                                                                                  // 34
            if (username.type !== "text")                                                                          // 35
                throw Error("The type of username field should be text when email field is present!");             // 36
        }else{                                                                                                     // 37
            // email only                                                                                          // 38
            if (!email.required)                                                                                   // 39
                throw Error("The email field should be required when username is not present!");                   // 40
        }                                                                                                          // 41
    }                                                                                                              // 42
    else{                                                                                                          // 43
        // username only                                                                                           // 44
        if (username.type !== "text" && username.type !== "tel")                                                   // 45
            throw Error("The type of username field should be text or tel!");                                      // 46
    }                                                                                                              // 47
                                                                                                                   // 48
    // Possibly publish more user data in order to be able to show add/remove                                      // 49
    // buttons for 3rd-party services                                                                              // 50
    if (this.options.showAddRemoveServices){                                                                       // 51
        // Publish additional current user info to get the list of registered services                             // 52
        // XXX TODO: use                                                                                           // 53
        // Accounts.addAutopublishFields({                                                                         // 54
        //   forLoggedInUser: ['services.facebook'],                                                               // 55
        //   forOtherUsers: [],                                                                                    // 56
        // })                                                                                                      // 57
        // ...adds only user.services.*.id                                                                         // 58
        Meteor.publish("userRegisteredServices", function() {                                                      // 59
            var userId = this.userId;                                                                              // 60
            return Meteor.users.find(userId, {fields: {services: 1}});                                             // 61
            /*                                                                                                     // 62
            if (userId){                                                                                           // 63
                var user = Meteor.users.findOne(userId);                                                           // 64
                var services_id = _.chain(user.services)                                                           // 65
                    .keys()                                                                                        // 66
                    .reject(function(service){return service === "resume";})                                       // 67
                    .map(function(service){return "services." + service + ".id";})                                 // 68
                    .value();                                                                                      // 69
                var projection = {};                                                                               // 70
                _.each(services_id, function(key){projection[key] = 1;});                                          // 71
                return Meteor.users.find(userId, {fields: projection});                                            // 72
            }                                                                                                      // 73
            */                                                                                                     // 74
        });                                                                                                        // 75
    }                                                                                                              // 76
                                                                                                                   // 77
    // Security stuff                                                                                              // 78
    if (this.options.overrideLoginErrors){                                                                         // 79
        Accounts.validateLoginAttempt(function(attempt){                                                           // 80
            if (attempt.error){                                                                                    // 81
                var reason = attempt.error.reason;                                                                 // 82
                if (reason === "User not found" || reason === "Incorrect password")                                // 83
                    throw new Meteor.Error(403, AccountsTemplates.texts.errors.loginForbidden);                    // 84
            }                                                                                                      // 85
            return attempt.allowed;                                                                                // 86
        });                                                                                                        // 87
    }                                                                                                              // 88
                                                                                                                   // 89
    if (this.options.sendVerificationEmail && this.options.enforceEmailVerification){                              // 90
        Accounts.validateLoginAttempt(function(attempt){                                                           // 91
            if (!attempt.allowed) {                                                                                // 92
              return false;                                                                                        // 93
            }                                                                                                      // 94
            if (attempt.type !== "password" || attempt.methodName !== "login") {                                   // 95
                return attempt.allowed;                                                                            // 96
            }                                                                                                      // 97
            var user = attempt.user;                                                                               // 98
            if (!user) {                                                                                           // 99
                return attempt.allowed;                                                                            // 100
            }                                                                                                      // 101
            var ok = true;                                                                                         // 102
            var loginEmail = attempt.methodArguments[0].user.email;                                                // 103
            if (loginEmail){                                                                                       // 104
              var email = _.filter(user.emails, function(obj){                                                     // 105
                  return obj.address === loginEmail;                                                               // 106
              });                                                                                                  // 107
              if (!email.length || !email[0].verified) {                                                           // 108
                  ok = false;                                                                                      // 109
              }                                                                                                    // 110
            }                                                                                                      // 111
            else {                                                                                                 // 112
              // we got the username, lets check there's at lease one verified email                               // 113
              var emailVerified = _.chain(user.emails)                                                             // 114
                .pluck('verified')                                                                                 // 115
                .any()                                                                                             // 116
                .value();                                                                                          // 117
              if (!emailVerified) {                                                                                // 118
                ok = false;                                                                                        // 119
              }                                                                                                    // 120
            }                                                                                                      // 121
            if (!ok) {                                                                                             // 122
              throw new Meteor.Error(401, AccountsTemplates.texts.errors.verifyEmailFirst);                        // 123
              return false;                                                                                        // 124
            }                                                                                                      // 125
            return attempt.allowed;                                                                                // 126
        });                                                                                                        // 127
    }                                                                                                              // 128
                                                                                                                   // 129
    //Check that reCaptcha secret keys are available                                                               // 130
    if (this.options.showReCaptcha) {                                                                              // 131
        var atSecretKey = AccountsTemplates.options.reCaptcha && AccountsTemplates.options.reCaptcha.secretKey;    // 132
        var settingsSecretKey = Meteor.settings.reCaptcha && Meteor.settings.reCaptcha.secretKey;                  // 133
                                                                                                                   // 134
        if (!atSecretKey && !settingsSecretKey) {                                                                  // 135
            throw new Meteor.Error(401, "User Accounts: reCaptcha secret key not found! Please provide it or set showReCaptcha to false." );
        }                                                                                                          // 137
    }                                                                                                              // 138
                                                                                                                   // 139
    // ------------                                                                                                // 140
    // Server-Side Routes Definition                                                                               // 141
    //                                                                                                             // 142
    //   this allows for server-side iron-router usage, like, e.g.                                                 // 143
    //   Router.map(function(){                                                                                    // 144
    //       this.route("fullPageSigninForm", {                                                                    // 145
    //           path: "*",                                                                                        // 146
    //           where: "server"                                                                                   // 147
    //           action: function() {                                                                              // 148
    //               this.response.statusCode = 404;                                                               // 149
    //               return this.response.end(Handlebars.templates["404"]());                                      // 150
    //           }                                                                                                 // 151
    //       });                                                                                                   // 152
    //   })                                                                                                        // 153
    // ------------                                                                                                // 154
    AccountsTemplates.setupRoutes();                                                                               // 155
                                                                                                                   // 156
    // Marks AccountsTemplates as initialized                                                                      // 157
    this._initialized = true;                                                                                      // 158
};                                                                                                                 // 159
                                                                                                                   // 160
                                                                                                                   // 161
// Fake server-side IR plugin to allow for shared routing files                                                    // 162
Iron.Router.plugins.ensureSignedIn = function (router, options) {};                                                // 163
                                                                                                                   // 164
                                                                                                                   // 165
AccountsTemplates = new AT();                                                                                      // 166
                                                                                                                   // 167
                                                                                                                   // 168
// Client side account creation is disabled by default:                                                            // 169
// the methos ATCreateUserServer is used instead!                                                                  // 170
// to actually disable client side account creation use:                                                           // 171
//                                                                                                                 // 172
//    AccountsTemplates.config({                                                                                   // 173
//        forbidClientAccountCreation: true                                                                        // 174
//    });                                                                                                          // 175
Accounts.config({                                                                                                  // 176
    forbidClientAccountCreation: true                                                                              // 177
});                                                                                                                // 178
                                                                                                                   // 179
                                                                                                                   // 180
// Initialization                                                                                                  // 181
Meteor.startup(function(){                                                                                         // 182
    AccountsTemplates._init();                                                                                     // 183
});                                                                                                                // 184
                                                                                                                   // 185
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/useraccounts:core/lib/methods.js                                                                       //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
                                                                                                                   // 1
Meteor.methods({                                                                                                   // 2
    ATRemoveService: function(service_name){                                                                       // 3
        var userId = this.userId;                                                                                  // 4
        if (userId){                                                                                               // 5
            var user = Meteor.users.findOne(userId);                                                               // 6
            var numServices = _.keys(user.services).length; // including "resume"                                  // 7
            if (numServices === 2)                                                                                 // 8
                throw new Meteor.Error(403, AccountsTemplates.texts.errors.cannotRemoveService, {});               // 9
            var unset = {};                                                                                        // 10
            unset["services." + service_name] = "";                                                                // 11
            Meteor.users.update(userId, {$unset: unset});                                                          // 12
        }                                                                                                          // 13
    },                                                                                                             // 14
});                                                                                                                // 15
                                                                                                                   // 16
                                                                                                                   // 17
if (Meteor.isServer) {                                                                                             // 18
    Meteor.methods({                                                                                               // 19
        ATCreateUserServer: function(options){                                                                     // 20
            if (AccountsTemplates.options.forbidClientAccountCreation)                                             // 21
                throw new Meteor.Error(403, AccountsTemplates.texts.errors.accountsCreationDisabled);              // 22
            // createUser() does more checking.                                                                    // 23
            check(options, Object);                                                                                // 24
            var allFieldIds = AccountsTemplates.getFieldIds();                                                     // 25
            // Picks-up whitelisted fields for profile                                                             // 26
            var profile = options.profile;                                                                         // 27
            profile = _.pick(profile, allFieldIds);                                                                // 28
            profile = _.omit(profile, "username", "email", "password");                                            // 29
            // Validates fields" value                                                                             // 30
            var signupInfo = _.clone(profile);                                                                     // 31
            if (options.username) {                                                                                // 32
                signupInfo.username = options.username;                                                            // 33
                                                                                                                   // 34
                if (AccountsTemplates.options.lowercaseUsername) {                                                 // 35
                  signupInfo.username = signupInfo.username.trim().replace(/\s+/gm, ' ');                          // 36
                  options.profile.name = signupInfo.username;                                                      // 37
                  signupInfo.username = signupInfo.username.toLowerCase().replace(/\s+/gm, '');                    // 38
                  options.username = signupInfo.username                                                           // 39
                }                                                                                                  // 40
            }                                                                                                      // 41
            if (options.email) {                                                                                   // 42
                signupInfo.email = options.email;                                                                  // 43
                                                                                                                   // 44
                if (AccountsTemplates.options.lowercaseUsername) {                                                 // 45
                  signupInfo.email = signupInfo.email.toLowerCase().replace(/\s+/gm, '');                          // 46
                  options.email = signupInfo.email                                                                 // 47
                }                                                                                                  // 48
            }                                                                                                      // 49
            if (options.password)                                                                                  // 50
                signupInfo.password = options.password;                                                            // 51
            var validationErrors = {};                                                                             // 52
            var someError = false;                                                                                 // 53
                                                                                                                   // 54
            // Validates fields values                                                                             // 55
            _.each(AccountsTemplates.getFields(), function(field){                                                 // 56
                var fieldId = field._id;                                                                           // 57
                var value = signupInfo[fieldId];                                                                   // 58
                if (fieldId === "password"){                                                                       // 59
                    // Can"t Pick-up password here                                                                 // 60
                    // NOTE: at this stage the password is already encripted,                                      // 61
                    //       so there is no way to validate it!!!                                                  // 62
                    check(value, Object);                                                                          // 63
                    return;                                                                                        // 64
                }                                                                                                  // 65
                var validationErr = field.validate(value, "strict");                                               // 66
                if (validationErr) {                                                                               // 67
                    validationErrors[fieldId] = validationErr;                                                     // 68
                    someError = true;                                                                              // 69
                }                                                                                                  // 70
            });                                                                                                    // 71
                                                                                                                   // 72
            if (AccountsTemplates.options.showReCaptcha) {                                                         // 73
                var secretKey = null;                                                                              // 74
                                                                                                                   // 75
                if (AccountsTemplates.options.reCaptcha && AccountsTemplates.options.reCaptcha.secretKey) {        // 76
                    secretKey = AccountsTemplates.options.reCaptcha.secretKey;                                     // 77
                }                                                                                                  // 78
                else {                                                                                             // 79
                    secretKey = Meteor.settings.reCaptcha.secretKey;                                               // 80
                }                                                                                                  // 81
                                                                                                                   // 82
                var apiResponse = HTTP.post("https://www.google.com/recaptcha/api/siteverify", {                   // 83
                  params: {                                                                                        // 84
                      secret: secretKey,                                                                           // 85
                      response: options.profile.reCaptchaResponse,                                                 // 86
                      remoteip: this.connection.clientAddress,                                                     // 87
                  }                                                                                                // 88
                }).data;                                                                                           // 89
                                                                                                                   // 90
                if (!apiResponse.success) {                                                                        // 91
                    throw new Meteor.Error(403, AccountsTemplates.texts.errors.captchaVerification,                // 92
                      apiResponse['error-codes'] ? apiResponse['error-codes'].join(", ") : "Unknown Error.");      // 93
                }                                                                                                  // 94
            }                                                                                                      // 95
                                                                                                                   // 96
            if (someError)                                                                                         // 97
                throw new Meteor.Error(403, AccountsTemplates.texts.errors.validationErrors, validationErrors);    // 98
                                                                                                                   // 99
            // Possibly removes the profile field                                                                  // 100
            if (_.isEmpty(options.profile))                                                                        // 101
                delete options.profile;                                                                            // 102
                                                                                                                   // 103
            // Create user. result contains id and token.                                                          // 104
            var userId = Accounts.createUser(options);                                                             // 105
            // safety belt. createUser is supposed to throw on error. send 500 error                               // 106
            // instead of sending a verification email with empty userid.                                          // 107
            if (! userId)                                                                                          // 108
                throw new Error("createUser failed to insert new user");                                           // 109
                                                                                                                   // 110
            // Send a email address verification email in case the context permits it                              // 111
            // and the specific configuration flag was set to true                                                 // 112
            if (options.email && AccountsTemplates.options.sendVerificationEmail)                                  // 113
                Accounts.sendVerificationEmail(userId, options.email);                                             // 114
        },                                                                                                         // 115
                                                                                                                   // 116
        // Resend a user's verification e-mail                                                                     // 117
        ATResendVerificationEmail: function (email) {                                                              // 118
            check(email, String);                                                                                  // 119
                                                                                                                   // 120
            var user = Meteor.users.findOne({ "emails.address": email });                                          // 121
                                                                                                                   // 122
            // Send the standard error back to the client if no user exist with this e-mail                        // 123
            if (!user)                                                                                             // 124
                throw new Meteor.Error(403, "User not found");                                                     // 125
                                                                                                                   // 126
            try {                                                                                                  // 127
                Accounts.sendVerificationEmail(user._id);                                                          // 128
            }                                                                                                      // 129
            catch (error) {                                                                                        // 130
                // Handle error when email already verified                                                        // 131
                // https://github.com/dwinston/send-verification-email-bug                                         // 132
                throw new Meteor.Error(403, "Already verified");                                                   // 133
            }                                                                                                      // 134
        },                                                                                                         // 135
    });                                                                                                            // 136
}                                                                                                                  // 137
                                                                                                                   // 138
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['useraccounts:core'] = {
  AccountsTemplates: AccountsTemplates
};

})();

//# sourceMappingURL=useraccounts_core.js.map
