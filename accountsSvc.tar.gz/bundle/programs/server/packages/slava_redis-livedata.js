(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var Random = Package.random.Random;
var EJSON = Package.ejson.EJSON;
var _ = Package.underscore._;
var Log = Package.logging.Log;
var check = Package.check.check;
var Match = Package.check.Match;
var DDP = Package.ddp.DDP;
var DDPServer = Package.ddp.DDPServer;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var IdMap = Package['id-map'].IdMap;
var Miniredis = Package['slava:miniredis'].Miniredis;
var MaxHeap = Package['binary-heap'].MaxHeap;
var MinHeap = Package['binary-heap'].MinHeap;
var MinMaxHeap = Package['binary-heap'].MinMaxHeap;
var Hook = Package['callback-hook'].Hook;

/* Package-scope variables */
var RedisInternals, RedisTest, _SynchronousMapEntry, SynchronousMap, REDIS_COMMANDS_HASH, REDIS_COMMANDS_LOCAL, RedisObserver, RedisConnection, CursorDescription, Cursor, listenAll, forEachTrigger, idForOp, OplogHandle, ObserveHelpers, ObserveMultiplexer, ObserveHandle, DocFetcher, KeyspaceNotificationObserveDriver, RedisClient, RedisWatcher, LocalCollectionDriver, meteorOnce, RedisSingletons, ret;

(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// packages/slava:redis-livedata/sync_map.js                                                          //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
if (Meteor.isServer) {                                                                                // 1
  var path = Npm.require('path');                                                                     // 2
  var Future = Npm.require(path.join('fibers', 'future'));                                            // 3
}                                                                                                     // 4
                                                                                                      // 5
_SynchronousMapEntry = function () {                                                                  // 6
  var self = this;                                                                                    // 7
                                                                                                      // 8
  self._future = undefined;                                                                           // 9
  self._value = undefined;                                                                            // 10
  self._done = false;                                                                                 // 11
};                                                                                                    // 12
                                                                                                      // 13
SynchronousMap = function () {                                                                        // 14
  var self = this;                                                                                    // 15
                                                                                                      // 16
  self._map = {};                                                                                     // 17
};                                                                                                    // 18
                                                                                                      // 19
_.extend(SynchronousMap.prototype, {                                                                  // 20
  get: function (arguments, f) {                                                                      // 21
    var self = this;                                                                                  // 22
    var v = self._map[arguments];                                                                     // 23
    if (v === undefined) {                                                                            // 24
      self._map[arguments] = v = new _SynchronousMapEntry;                                            // 25
    }                                                                                                 // 26
    if (v._done) {                                                                                    // 27
      return v._value;                                                                                // 28
    }                                                                                                 // 29
    if (Meteor.isServer) {                                                                            // 30
      if (v._future) {                                                                                // 31
        return v._future.wait();                                                                      // 32
      }                                                                                               // 33
      var future = v._future = new Future();                                                          // 34
      try {                                                                                           // 35
        var value = f.apply(null, arguments);                                                         // 36
        v._future.return(value);                                                                      // 37
        v._value = value;                                                                             // 38
        v._done = true;                                                                               // 39
      } catch (e) {                                                                                   // 40
        v._future.throw(e);                                                                           // 41
      // We'll retry this, so we won't set _done                                                      // 42
      }                                                                                               // 43
      v._future = null;                                                                               // 44
      return future.wait();                                                                           // 45
    } else {                                                                                          // 46
      v._value = f.apply(null, arguments);                                                            // 47
      v._done = true;                                                                                 // 48
      return v._value;                                                                                // 49
    }                                                                                                 // 50
  }                                                                                                   // 51
});                                                                                                   // 52
                                                                                                      // 53
////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// packages/slava:redis-livedata/redis_commands.js                                                    //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
REDIS_COMMANDS_HASH = [                                                                               // 1
  'hdel', 'hexists', 'hget', 'hgetall', 'hincrby',                                                    // 2
  'hincrbyfloat', 'hkeys', 'hlen', 'hmget',                                                           // 3
  'hmset', 'hset', 'hsetnx', 'hvals', 'hscan'                                                         // 4
];                                                                                                    // 5
                                                                                                      // 6
REDIS_COMMANDS_LOCAL = [                                                                              // 7
  'get', 'keys',                                                                                      // 8
  'hexists', 'hget', 'hgetall', 'hmget', 'hkeys', 'hlen', 'hvals'                                     // 9
];                                                                                                    // 10
                                                                                                      // 11
////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// packages/slava:redis-livedata/redis_driver.js                                                      //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
/**                                                                                                   // 1
 * Provide a synchronous Collection API using fibers, backed by                                       // 2
 * MongoDB.  This is only for use on the server, and mostly identical                                 // 3
 * to the client API.                                                                                 // 4
 *                                                                                                    // 5
 * NOTE: the public API methods must be run within a fiber. If you call                               // 6
 * these outside of a fiber they will explode!                                                        // 7
 */                                                                                                   // 8
                                                                                                      // 9
var path = Npm.require('path');                                                                       // 10
                                                                                                      // 11
var Fiber = Npm.require('fibers');                                                                    // 12
var Future = Npm.require(path.join('fibers', 'future'));                                              // 13
                                                                                                      // 14
RedisInternals = {};                                                                                  // 15
RedisTest = {};                                                                                       // 16
                                                                                                      // 17
// This is used to add or remove EJSON from the beginning of everything nested                        // 18
// inside an EJSON custom type. It should only be called on pure JSON!                                // 19
var replaceNames = function (filter, thing) {                                                         // 20
  if (typeof thing === "object") {                                                                    // 21
    if (_.isArray(thing)) {                                                                           // 22
      return _.map(thing, _.bind(replaceNames, null, filter));                                        // 23
    }                                                                                                 // 24
    var ret = {};                                                                                     // 25
    _.each(thing, function (value, key) {                                                             // 26
      ret[filter(key)] = replaceNames(filter, value);                                                 // 27
    });                                                                                               // 28
    return ret;                                                                                       // 29
  }                                                                                                   // 30
  return thing;                                                                                       // 31
};                                                                                                    // 32
                                                                                                      // 33
// Ensure that EJSON.clone keeps a Timestamp as a Timestamp (instead of just                          // 34
// doing a structural clone).                                                                         // 35
// XXX how ok is this? what if there are multiple copies of MongoDB loaded?                           // 36
//MongoDB.Timestamp.prototype.clone = function () {                                                   // 37
//  // Timestamps should be immutable.                                                                // 38
//  return this;                                                                                      // 39
//};                                                                                                  // 40
                                                                                                      // 41
var makeMongoLegal = function (name) { return "EJSON" + name; };                                      // 42
var unmakeMongoLegal = function (name) { return name.substr(5); };                                    // 43
                                                                                                      // 44
var replaceRedisAtomWithMeteor = function (document) {                                                // 45
//  if (document instanceof MongoDB.Binary) {                                                         // 46
//    var buffer = document.value(true);                                                              // 47
//    return new Uint8Array(buffer);                                                                  // 48
//  }                                                                                                 // 49
//  if (document instanceof MongoDB.ObjectID) {                                                       // 50
//    return new Meteor.RedisCollection.ObjectID(document.toHexString());                             // 51
//  }                                                                                                 // 52
  if (document["EJSON$type"] && document["EJSON$value"]                                               // 53
      && _.size(document) === 2) {                                                                    // 54
    return EJSON.fromJSONValue(replaceNames(unmakeMongoLegal, document));                             // 55
  }                                                                                                   // 56
//  if (document instanceof MongoDB.Timestamp) {                                                      // 57
//    // For now, the Meteor representation of a Mongo timestamp type (not a date!                    // 58
//    // this is a weird internal thing used in the oplog!) is the same as the                        // 59
//    // Mongo representation. We need to do this explicitly or else we would do a                    // 60
//    // structural clone and lose the prototype.                                                     // 61
//    return document;                                                                                // 62
//  }                                                                                                 // 63
  return undefined;                                                                                   // 64
};                                                                                                    // 65
                                                                                                      // 66
var replaceMeteorAtomWithRedis = function (document) {                                                // 67
//  if (EJSON.isBinary(document)) {                                                                   // 68
//    // This does more copies than we'd like, but is necessary because                               // 69
//    // MongoDB.BSON only looks like it takes a Uint8Array (and doesn't actually                     // 70
//    // serialize it correctly).                                                                     // 71
//    return new MongoDB.Binary(new Buffer(document));                                                // 72
//  }                                                                                                 // 73
//  if (document instanceof Meteor.RedisCollection.ObjectID) {                                        // 74
//    return new MongoDB.ObjectID(document.toHexString());                                            // 75
//  }                                                                                                 // 76
//  if (document instanceof MongoDB.Timestamp) {                                                      // 77
//    // For now, the Meteor representation of a Mongo timestamp type (not a date!                    // 78
//    // this is a weird internal thing used in the oplog!) is the same as the                        // 79
//    // Mongo representation. We need to do this explicitly or else we would do a                    // 80
//    // structural clone and lose the prototype.                                                     // 81
//    return document;                                                                                // 82
//  }                                                                                                 // 83
  if (EJSON._isCustomType(document)) {                                                                // 84
    return replaceNames(makeMongoLegal, EJSON.toJSONValue(document));                                 // 85
  }                                                                                                   // 86
  // It is not ordinarily possible to stick dollar-sign keys into mongo                               // 87
  // so we don't bother checking for things that need escaping at this time.                          // 88
  return undefined;                                                                                   // 89
};                                                                                                    // 90
                                                                                                      // 91
var replaceTypes = function (document, atomTransformer) {                                             // 92
  if (typeof document !== 'object' || document === null)                                              // 93
    return document;                                                                                  // 94
                                                                                                      // 95
  var replacedTopLevelAtom = atomTransformer(document);                                               // 96
  if (replacedTopLevelAtom !== undefined)                                                             // 97
    return replacedTopLevelAtom;                                                                      // 98
                                                                                                      // 99
  var ret = document;                                                                                 // 100
  _.each(document, function (val, key) {                                                              // 101
    var valReplaced = replaceTypes(val, atomTransformer);                                             // 102
    if (val !== valReplaced) {                                                                        // 103
      // Lazy clone. Shallow copy.                                                                    // 104
      if (ret === document)                                                                           // 105
        ret = _.clone(document);                                                                      // 106
      ret[key] = valReplaced;                                                                         // 107
    }                                                                                                 // 108
  });                                                                                                 // 109
  return ret;                                                                                         // 110
};                                                                                                    // 111
                                                                                                      // 112
                                                                                                      // 113
RedisObserver = function (watcher, observer) {                                                        // 114
  var self = this;                                                                                    // 115
  self._watcher = watcher;                                                                            // 116
  var listener = function (key, message) {                                                            // 117
    var methodName;                                                                                   // 118
    if (message == 'hset' || message == 'set') {                                                      // 119
      methodName = 'updated';                                                                         // 120
    } else if (message == 'hincrby'                                                                   // 121
               || message == 'incr'                                                                   // 122
               || message == 'incrby'                                                                 // 123
               || message == 'incrbyfloat'                                                            // 124
               || message == 'decr'                                                                   // 125
               || message == 'decrby'                                                                 // 126
               || message == 'append') {                                                              // 127
      methodName = 'updated';                                                                         // 128
    } else if (message == 'del') {                                                                    // 129
      methodName = 'removed';                                                                         // 130
    }                                                                                                 // 131
                                                                                                      // 132
    if (!methodName) {                                                                                // 133
      Meteor._debug("RedisConnection::observe: Unknown message: " + message);                         // 134
    } else {                                                                                          // 135
      if (_.isFunction(observer[methodName])) {                                                       // 136
        var value = { _id: key };                                                                     // 137
        observer[methodName](key, value);                                                             // 138
      }                                                                                               // 139
    }                                                                                                 // 140
//      addedAt: function (doc, before_index, before) {                                               // 141
//        log += 'a(' + doc.x + ',' + before_index + ',' + before + ')';                              // 142
//      },                                                                                            // 143
//      changedAt: function (new_doc, old_doc, at_index) {                                            // 144
//        log += 'c(' + new_doc.x + ',' + at_index + ',' + old_doc.x + ')';                           // 145
//      },                                                                                            // 146
//      movedTo: function (doc, old_index, new_index) {                                               // 147
//        log += 'm(' + doc.x + ',' + old_index + ',' + new_index + ')';                              // 148
//      },                                                                                            // 149
//      removedAt: function (doc, at_index) {                                                         // 150
//        log += 'r(' + doc.x + ',' + at_index + ')';                                                 // 151
//      }                                                                                             // 152
  };                                                                                                  // 153
  self._listener = listener;                                                                          // 154
  watcher.addListener(listener);                                                                      // 155
};                                                                                                    // 156
                                                                                                      // 157
RedisObserver.prototype.stop = function () {                                                          // 158
  var self = this;                                                                                    // 159
  self._watcher.removeListener(self._listener);                                                       // 160
};                                                                                                    // 161
                                                                                                      // 162
RedisConnection = function (url, options) {                                                           // 163
  var self = this;                                                                                    // 164
  options = options || {};                                                                            // 165
  self._connectCallbacks = [];                                                                        // 166
  self._observeMultiplexers = {};                                                                     // 167
  self._onFailoverHook = new Hook;                                                                    // 168
                                                                                                      // 169
  var redisOptions = {}; // {db: {safe: true}, server: {}, replSet: {}};                              // 170
                                                                                                      // 171
  // Set autoReconnect to true, unless passed on the URL. Why someone                                 // 172
  // would want to set autoReconnect to false, I'm not really sure, but                               // 173
  // keeping this for backwards compatibility for now.                                                // 174
//  if (!(/[\?&]auto_?[rR]econnect=/.test(url))) {                                                    // 175
//    mongoOptions.server.auto_reconnect = true;                                                      // 176
//  }                                                                                                 // 177
                                                                                                      // 178
  // Disable the native parser by default, unless specifically enabled                                // 179
  // in the mongo URL.                                                                                // 180
  // - The native driver can cause errors which normally would be                                     // 181
  //   thrown, caught, and handled into segfaults that take down the                                  // 182
  //   whole app.                                                                                     // 183
  // - Binary modules don't yet work when you bundle and move the bundle                              // 184
  //   to a different platform (aka deploy)                                                           // 185
  // We should revisit this after binary npm module support lands.                                    // 186
//  if (!(/[\?&]native_?[pP]arser=/.test(url))) {                                                     // 187
//    mongoOptions._client.native_parser = false;                                                     // 188
//  }                                                                                                 // 189
                                                                                                      // 190
  // XXX maybe we should have a better way of allowing users to configure the                         // 191
  // underlying Mongo driver                                                                          // 192
//  if (_.has(options, 'poolSize')) {                                                                 // 193
//    // If we just set this for "server", replSet will override it. If we just                       // 194
//    // set it for replSet, it will be ignored if we're not using a replSet.                         // 195
//    mongoOptions.server.poolSize = options.poolSize;                                                // 196
//    mongoOptions.replSet.poolSize = options.poolSize;                                               // 197
//  }                                                                                                 // 198
                                                                                                      // 199
  var client = self._client = new RedisClient(url, redisOptions);                                     // 200
  self._watcher = new RedisWatcher(url);                                                              // 201
                                                                                                      // 202
  // Note ==, not ===, so we accept '1' or 1                                                          // 203
  var fixConfig = options.configureKeyspaceNotifications == '1';                                      // 204
  checkConfig(client, fixConfig);                                                                     // 205
                                                                                                      // 206
//  MongoDB.connect(url, mongoOptions, Meteor.bindEnvironment(function(err, db) {                     // 207
//    if (err)                                                                                        // 208
//      throw err;                                                                                    // 209
//    self._client = db;                                                                              // 210
//    // We keep track of the ReplSet's primary, so that we can trigger hooks when                    // 211
//    // it changes.  The Node driver's joined callback seems to fire way too                         // 212
//    // often, which is why we need to track it ourselves.                                           // 213
//    self._primary = null;                                                                           // 214
//    // First, figure out what the current primary is, if any.                                       // 215
//    if (self._client.serverConfig._state.master)                                                    // 216
//      self._primary = self._client.serverConfig._state.master.name;                                 // 217
//    self._client.serverConfig.on(                                                                   // 218
//      'joined', Meteor.bindEnvironment(function (kind, doc) {                                       // 219
//        if (kind === 'primary') {                                                                   // 220
//          if (doc.primary !== self._primary) {                                                      // 221
//            self._primary = doc.primary;                                                            // 222
//            self._onFailoverHook.each(function (callback) {                                         // 223
//              callback();                                                                           // 224
//              return true;                                                                          // 225
//            });                                                                                     // 226
//          }                                                                                         // 227
//        } else if (doc.me === self._primary) {                                                      // 228
//          // The thing we thought was primary is now something other than                           // 229
//          // primary.  Forget that we thought it was primary.  (This means that                     // 230
//          // if a server stops being primary and then starts being primary again                    // 231
//          // without another server becoming primary in the middle, we'll                           // 232
//          // correctly count it as a failover.)                                                     // 233
//          self._primary = null;                                                                     // 234
//        }                                                                                           // 235
//    }));                                                                                            // 236
//                                                                                                    // 237
//    // drain queue of pending callbacks                                                             // 238
//    _.each(self._connectCallbacks, function (c) {                                                   // 239
//      c(_client);                                                                                   // 240
//    });                                                                                             // 241
//  }));                                                                                              // 242
                                                                                                      // 243
  // XXX: Authenticated connections?                                                                  // 244
                                                                                                      // 245
  // XXX: Wait until 'ready' event?                                                                   // 246
  // drain queue of pending callbacks                                                                 // 247
  _.each(self._connectCallbacks, function (c) {                                                       // 248
    c(client);                                                                                        // 249
  });                                                                                                 // 250
                                                                                                      // 251
  self._docFetcher = new DocFetcher(self);                                                            // 252
  self._oplogHandle = null;                                                                           // 253
                                                                                                      // 254
//  if (options.oplogUrl && !Package['disable-oplog']) {                                              // 255
//    var dbNameFuture = new Future;                                                                  // 256
//    self._withDb(function (db) {                                                                    // 257
//      dbNameFuture.return(db.databaseName);                                                         // 258
//    });                                                                                             // 259
//    self._oplogHandle = new OplogHandle(options.oplogUrl, dbNameFuture.wait());                     // 260
//  }                                                                                                 // 261
                                                                                                      // 262
  self._oplogHandle = new OplogHandle(self._client, self._watcher);                                   // 263
};                                                                                                    // 264
                                                                                                      // 265
// Help the user, by verifying that notify-keyspace-events is set correctly                           // 266
function checkConfig(client, fix) {                                                                   // 267
  var notifyConfig = Future.wrap(_.bind(client.getConfig, client))('notify-keyspace-events').wait();  // 268
  var config = '';                                                                                    // 269
  var missing = '';                                                                                   // 270
  if (_.isArray(notifyConfig) && notifyConfig.length >= 2) {                                          // 271
    config = notifyConfig[1];                                                                         // 272
  } else {                                                                                            // 273
    throw new Error("Error from 'config get notify-keyspace-events'");                                // 274
  }                                                                                                   // 275
                                                                                                      // 276
  // K = keyspace events are being published                                                          // 277
  if (config.indexOf('K') == -1) {                                                                    // 278
    missing += 'K';                                                                                   // 279
  }                                                                                                   // 280
                                                                                                      // 281
  // We need at least:                                                                                // 282
  //  $ string events                                                                                 // 283
  //  h hash events                                                                                   // 284
  //  g generic events (del)                                                                          // 285
  //  x expired events                                                                                // 286
  //  e evicted events                                                                                // 287
  //                                                                                                  // 288
  // "A" means "everything"                                                                           // 289
  if (config.indexOf('A') == -1) {                                                                    // 290
    _.each(['$', 'h', 'g', 'x', 'e'], function (key) {                                                // 291
      if (config.indexOf(key) == -1) {                                                                // 292
        missing += key;                                                                               // 293
      }                                                                                               // 294
    });                                                                                               // 295
  }                                                                                                   // 296
                                                                                                      // 297
  if (missing) {                                                                                      // 298
    if (fix) {                                                                                        // 299
      var newConfig = config + missing;                                                               // 300
      Future.wrap(_.bind(client.setConfig, client))('notify-keyspace-events', newConfig).wait();      // 301
                                                                                                      // 302
      // Sanity check!                                                                                // 303
      checkConfig(client, false);                                                                     // 304
    } else {                                                                                          // 305
      throw new Error("You must configure notify-keyspace-events for Meteor (or launch with REDIS_CONFIGURE_KEYSPACE_NOTIFICATIONS=1).  Current config=" + config + " missing=" + missing);
    }                                                                                                 // 307
  }                                                                                                   // 308
};                                                                                                    // 309
                                                                                                      // 310
RedisConnection.prototype.close = function() {                                                        // 311
  var self = this;                                                                                    // 312
                                                                                                      // 313
  // XXX probably untested                                                                            // 314
  var oplogHandle = self._oplogHandle;                                                                // 315
  self._oplogHandle = null;                                                                           // 316
  if (oplogHandle)                                                                                    // 317
    oplogHandle.stop();                                                                               // 318
                                                                                                      // 319
  // Use Future.wrap so that errors get thrown. This happens to                                       // 320
  // work even outside a fiber since the 'close' method is not                                        // 321
  // actually asynchronous.                                                                           // 322
  Future.wrap(_.bind(self._client.close, self._client))(true).wait();                                 // 323
};                                                                                                    // 324
                                                                                                      // 325
RedisConnection.prototype._withDb = function (callback) {                                             // 326
  var self = this;                                                                                    // 327
  if (self._client) {                                                                                 // 328
    callback(self._client);                                                                           // 329
  } else {                                                                                            // 330
    self._connectCallbacks.push(callback);                                                            // 331
  }                                                                                                   // 332
};                                                                                                    // 333
                                                                                                      // 334
// Returns the Mongo Collection object; may yield.                                                    // 335
RedisConnection.prototype._getCollection = function (collectionName) {                                // 336
  var self = this;                                                                                    // 337
                                                                                                      // 338
  var future = new Future;                                                                            // 339
  self._withDb(function (db) {                                                                        // 340
    db.collection(collectionName, future.resolver());                                                 // 341
  });                                                                                                 // 342
  return future.wait();                                                                               // 343
};                                                                                                    // 344
                                                                                                      // 345
RedisConnection.prototype._createCappedCollection = function (collectionName,                         // 346
                                                              byteSize) {                             // 347
  var self = this;                                                                                    // 348
  var future = new Future();                                                                          // 349
  self._withDb(function (db) {                                                                        // 350
    db.createCollection(collectionName, {capped: true, size: byteSize},                               // 351
                        future.resolver());                                                           // 352
  });                                                                                                 // 353
  future.wait();                                                                                      // 354
};                                                                                                    // 355
                                                                                                      // 356
// This should be called synchronously with a write, to create a                                      // 357
// transaction on the current write fence, if any. After we can read                                  // 358
// the write, and after observers have been notified (or at least,                                    // 359
// after the observer notifiers have added themselves to the write                                    // 360
// fence), you should call 'committed()' on the object returned.                                      // 361
RedisConnection.prototype._maybeBeginWrite = function () {                                            // 362
  var self = this;                                                                                    // 363
  var fence = DDPServer._CurrentWriteFence.get();                                                     // 364
  if (fence)                                                                                          // 365
    return fence.beginWrite();                                                                        // 366
  else                                                                                                // 367
    return {committed: function () {}};                                                               // 368
};                                                                                                    // 369
                                                                                                      // 370
// Internal interface: adds a callback which is called when the Mongo primary                         // 371
// changes. Returns a stop handle.                                                                    // 372
RedisConnection.prototype._onFailover = function (callback) {                                         // 373
  return this._onFailoverHook.register(callback);                                                     // 374
};                                                                                                    // 375
                                                                                                      // 376
                                                                                                      // 377
//////////// Public API //////////                                                                    // 378
                                                                                                      // 379
// The write methods block until the database has confirmed the write (it may                         // 380
// not be replicated or stable on disk, but one server has confirmed it) if no                        // 381
// callback is provided. If a callback is provided, then they call the callback                       // 382
// when the write is confirmed. They return nothing on success, and raise an                          // 383
// exception on failure.                                                                              // 384
//                                                                                                    // 385
// After making a write (with insert, update, remove), observers are                                  // 386
// notified asynchronously. If you want to receive a callback once all                                // 387
// of the observer notifications have landed for your write, do the                                   // 388
// writes inside a write fence (set DDPServer._CurrentWriteFence to a new                             // 389
// _WriteFence, and then set a callback on the write fence.)                                          // 390
//                                                                                                    // 391
// Since our execution environment is single-threaded, this is                                        // 392
// well-defined -- a write "has been made" if it's returned, and an                                   // 393
// observer "has been notified" if its callback has returned.                                         // 394
                                                                                                      // 395
var writeCallback = function (write, refresh, callback) {                                             // 396
  return function (err, result) {                                                                     // 397
    if (! err) {                                                                                      // 398
      // XXX We don't have to run this on error, right?                                               // 399
      refresh();                                                                                      // 400
    }                                                                                                 // 401
    write.committed();                                                                                // 402
    if (callback)                                                                                     // 403
      callback(err, result);                                                                          // 404
    else if (err)                                                                                     // 405
      throw err;                                                                                      // 406
  };                                                                                                  // 407
};                                                                                                    // 408
                                                                                                      // 409
var bindEnvironmentForWrite = function (callback) {                                                   // 410
  return Meteor.bindEnvironment(callback, "Mongo write");                                             // 411
};                                                                                                    // 412
                                                                                                      // 413
RedisConnection.prototype._insert = function (collection_name, document,                              // 414
                                              callback) {                                             // 415
  var self = this;                                                                                    // 416
                                                                                                      // 417
  var sendError = function (e) {                                                                      // 418
    if (callback)                                                                                     // 419
      return callback(e);                                                                             // 420
    throw e;                                                                                          // 421
  };                                                                                                  // 422
                                                                                                      // 423
  if (collection_name === "___meteor_failure_test_collection") {                                      // 424
    var e = new Error("Failure test");                                                                // 425
    e.expected = true;                                                                                // 426
    sendError(e);                                                                                     // 427
    return;                                                                                           // 428
  }                                                                                                   // 429
                                                                                                      // 430
  if (!(LocalCollection._isPlainObject(document) &&                                                   // 431
        !EJSON._isCustomType(document))) {                                                            // 432
    sendError(new Error(                                                                              // 433
      "Only documents (plain objects) may be inserted into MongoDB"));                                // 434
    return;                                                                                           // 435
  }                                                                                                   // 436
                                                                                                      // 437
  var write = self._maybeBeginWrite();                                                                // 438
  var refresh = function () {                                                                         // 439
    Meteor.refresh({collection: collection_name, id: document._id });                                 // 440
  };                                                                                                  // 441
  callback = bindEnvironmentForWrite(writeCallback(write, refresh, callback));                        // 442
  try {                                                                                               // 443
    var collection = self._getCollection(collection_name);                                            // 444
    collection.insert(replaceTypes(document, replaceMeteorAtomWithRedis),                             // 445
                      {safe: true}, callback);                                                        // 446
  } catch (e) {                                                                                       // 447
    write.committed();                                                                                // 448
    throw e;                                                                                          // 449
  }                                                                                                   // 450
};                                                                                                    // 451
                                                                                                      // 452
// Cause queries that may be affected by the selector to poll in this write                           // 453
// fence.                                                                                             // 454
RedisConnection.prototype._refresh = function (collectionName, selector) {                            // 455
  var self = this;                                                                                    // 456
  var refreshKey = {collection: collectionName};                                                      // 457
  // If we know which documents we're removing, don't poll queries that are                           // 458
  // specific to other documents. (Note that multiple notifications here should                       // 459
  // not cause multiple polls, since all our listener is doing is enqueueing a                        // 460
  // poll.)                                                                                           // 461
  var specificIds = LocalCollection._idsMatchedBySelector(selector);                                  // 462
  if (specificIds) {                                                                                  // 463
    _.each(specificIds, function (id) {                                                               // 464
      Meteor.refresh(_.extend({id: id}, refreshKey));                                                 // 465
    });                                                                                               // 466
  } else {                                                                                            // 467
    Meteor.refresh(refreshKey);                                                                       // 468
  }                                                                                                   // 469
};                                                                                                    // 470
                                                                                                      // 471
RedisConnection.prototype._remove = function (collection_name, selector,                              // 472
                                              callback) {                                             // 473
  var self = this;                                                                                    // 474
                                                                                                      // 475
  if (collection_name === "___meteor_failure_test_collection") {                                      // 476
    var e = new Error("Failure test");                                                                // 477
    e.expected = true;                                                                                // 478
    if (callback)                                                                                     // 479
      return callback(e);                                                                             // 480
    else                                                                                              // 481
      throw e;                                                                                        // 482
  }                                                                                                   // 483
                                                                                                      // 484
  var write = self._maybeBeginWrite();                                                                // 485
  var refresh = function () {                                                                         // 486
    self._refresh(collection_name, selector);                                                         // 487
  };                                                                                                  // 488
  callback = bindEnvironmentForWrite(writeCallback(write, refresh, callback));                        // 489
                                                                                                      // 490
  try {                                                                                               // 491
    var collection = self._getCollection(collection_name);                                            // 492
    collection.remove(replaceTypes(selector, replaceMeteorAtomWithRedis),                             // 493
                      {safe: true}, callback);                                                        // 494
  } catch (e) {                                                                                       // 495
    write.committed();                                                                                // 496
    throw e;                                                                                          // 497
  }                                                                                                   // 498
};                                                                                                    // 499
                                                                                                      // 500
RedisConnection.prototype._dropCollection = function (collectionName, cb) {                           // 501
  var self = this;                                                                                    // 502
                                                                                                      // 503
  var write = self._maybeBeginWrite();                                                                // 504
  var refresh = function () {                                                                         // 505
    Meteor.refresh({collection: collectionName, id: null,                                             // 506
                    dropCollection: true});                                                           // 507
  };                                                                                                  // 508
  cb = bindEnvironmentForWrite(writeCallback(write, refresh, cb));                                    // 509
                                                                                                      // 510
  try {                                                                                               // 511
    var collection = self._getCollection(collectionName);                                             // 512
    collection.drop(cb);                                                                              // 513
  } catch (e) {                                                                                       // 514
    write.committed();                                                                                // 515
    throw e;                                                                                          // 516
  }                                                                                                   // 517
};                                                                                                    // 518
                                                                                                      // 519
RedisConnection.prototype._update = function (collection_name, selector, mod,                         // 520
                                              options, callback) {                                    // 521
  var self = this;                                                                                    // 522
                                                                                                      // 523
  if (! callback && options instanceof Function) {                                                    // 524
    callback = options;                                                                               // 525
    options = null;                                                                                   // 526
  }                                                                                                   // 527
                                                                                                      // 528
  if (collection_name === "___meteor_failure_test_collection") {                                      // 529
    var e = new Error("Failure test");                                                                // 530
    e.expected = true;                                                                                // 531
    if (callback)                                                                                     // 532
      return callback(e);                                                                             // 533
    else                                                                                              // 534
      throw e;                                                                                        // 535
  }                                                                                                   // 536
                                                                                                      // 537
  // explicit safety check. null and undefined can crash the mongo                                    // 538
  // driver. Although the node driver and minimongo do 'support'                                      // 539
  // non-object modifier in that they don't crash, they are not                                       // 540
  // meaningful operations and do not do anything. Defensively throw an                               // 541
  // error here.                                                                                      // 542
  if (!mod || typeof mod !== 'object')                                                                // 543
    throw new Error("Invalid modifier. Modifier must be an object.");                                 // 544
                                                                                                      // 545
  if (!options) options = {};                                                                         // 546
                                                                                                      // 547
  var write = self._maybeBeginWrite();                                                                // 548
  var refresh = function () {                                                                         // 549
    self._refresh(collection_name, selector);                                                         // 550
  };                                                                                                  // 551
  callback = writeCallback(write, refresh, callback);                                                 // 552
  try {                                                                                               // 553
    var collection = self._getCollection(collection_name);                                            // 554
    var mongoOpts = {safe: true};                                                                     // 555
    // explictly enumerate options that minimongo supports                                            // 556
    if (options.upsert) mongoOpts.upsert = true;                                                      // 557
    if (options.multi) mongoOpts.multi = true;                                                        // 558
                                                                                                      // 559
    var mongoSelector = replaceTypes(selector, replaceMeteorAtomWithRedis);                           // 560
    var mongoMod = replaceTypes(mod, replaceMeteorAtomWithRedis);                                     // 561
                                                                                                      // 562
    var isModify = isModificationMod(mongoMod);                                                       // 563
    var knownId = (isModify ? selector._id : mod._id);                                                // 564
                                                                                                      // 565
    if (options.upsert && (! knownId) && options.insertedId) {                                        // 566
      // XXX In future we could do a real upsert for the mongo id generation                          // 567
      // case, if the the node mongo driver gives us back the id of the upserted                      // 568
      // doc (which our current version does not).                                                    // 569
      simulateUpsertWithInsertedId(                                                                   // 570
        collection, mongoSelector, mongoMod,                                                          // 571
        isModify, options,                                                                            // 572
        // This callback does not need to be bindEnvironment'ed because                               // 573
        // simulateUpsertWithInsertedId() wraps it and then passes it through                         // 574
        // bindEnvironmentForWrite.                                                                   // 575
        function (err, result) {                                                                      // 576
          // If we got here via a upsert() call, then options._returnObject will                      // 577
          // be set and we should return the whole object. Otherwise, we should                       // 578
          // just return the number of affected docs to match the mongo API.                          // 579
          if (result && ! options._returnObject)                                                      // 580
            callback(err, result.numberAffected);                                                     // 581
          else                                                                                        // 582
            callback(err, result);                                                                    // 583
        }                                                                                             // 584
      );                                                                                              // 585
    } else {                                                                                          // 586
      collection.update(                                                                              // 587
        mongoSelector, mongoMod, mongoOpts,                                                           // 588
        bindEnvironmentForWrite(function (err, result, extra) {                                       // 589
          if (! err) {                                                                                // 590
            if (result && options._returnObject) {                                                    // 591
              result = { numberAffected: result };                                                    // 592
              // If this was an upsert() call, and we ended up                                        // 593
              // inserting a new doc and we know its id, then                                         // 594
              // return that id as well.                                                              // 595
              if (options.upsert && knownId &&                                                        // 596
                  ! extra.updatedExisting)                                                            // 597
                result.insertedId = knownId;                                                          // 598
            }                                                                                         // 599
          }                                                                                           // 600
          callback(err, result);                                                                      // 601
        }));                                                                                          // 602
    }                                                                                                 // 603
  } catch (e) {                                                                                       // 604
    write.committed();                                                                                // 605
    throw e;                                                                                          // 606
  }                                                                                                   // 607
};                                                                                                    // 608
                                                                                                      // 609
var isModificationMod = function (mod) {                                                              // 610
  for (var k in mod)                                                                                  // 611
    if (k.substr(0, 1) === '$')                                                                       // 612
      return true;                                                                                    // 613
  return false;                                                                                       // 614
};                                                                                                    // 615
                                                                                                      // 616
var NUM_OPTIMISTIC_TRIES = 3;                                                                         // 617
                                                                                                      // 618
// exposed for testing                                                                                // 619
RedisConnection._isCannotChangeIdError = function (err) {                                             // 620
  // either of these checks should work, but just to be safe...                                       // 621
  return (err.code === 13596 ||                                                                       // 622
          err.err.indexOf("cannot change _id of a document") === 0);                                  // 623
};                                                                                                    // 624
                                                                                                      // 625
var simulateUpsertWithInsertedId = function (collection, selector, mod,                               // 626
                                             isModify, options, callback) {                           // 627
  // STRATEGY:  First try doing a plain update.  If it affected 0 documents,                          // 628
  // then without affecting the database, we know we should probably do an                            // 629
  // insert.  We then do a *conditional* insert that will fail in the case                            // 630
  // of a race condition.  This conditional insert is actually an                                     // 631
  // upsert-replace with an _id, which will never successfully update an                              // 632
  // existing document.  If this upsert fails with an error saying it                                 // 633
  // couldn't change an existing _id, then we know an intervening write has                           // 634
  // caused the query to match something.  We go back to step one and repeat.                         // 635
  // Like all "optimistic write" schemes, we rely on the fact that it's                               // 636
  // unlikely our writes will continue to be interfered with under normal                             // 637
  // circumstances (though sufficiently heavy contention with writers                                 // 638
  // disagreeing on the existence of an object will cause writes to fail                              // 639
  // in theory).                                                                                      // 640
                                                                                                      // 641
  var newDoc;                                                                                         // 642
  // Run this code up front so that it fails fast if someone uses                                     // 643
  // a Mongo update operator we don't support.                                                        // 644
  if (isModify) {                                                                                     // 645
    // We've already run replaceTypes/replaceMeteorAtomWithRedis on                                   // 646
    // selector and mod.  We assume it doesn't matter, as far as                                      // 647
    // the behavior of modifiers is concerned, whether `_modify`                                      // 648
    // is run on EJSON or on mongo-converted EJSON.                                                   // 649
    var selectorDoc = LocalCollection._removeDollarOperators(selector);                               // 650
    LocalCollection._modify(selectorDoc, mod, {isInsert: true});                                      // 651
    newDoc = selectorDoc;                                                                             // 652
  } else {                                                                                            // 653
    newDoc = mod;                                                                                     // 654
  }                                                                                                   // 655
                                                                                                      // 656
  var insertedId = options.insertedId; // must exist                                                  // 657
  var mongoOptsForUpdate = {                                                                          // 658
    safe: true,                                                                                       // 659
    multi: options.multi                                                                              // 660
  };                                                                                                  // 661
  var mongoOptsForInsert = {                                                                          // 662
    safe: true,                                                                                       // 663
    upsert: true                                                                                      // 664
  };                                                                                                  // 665
                                                                                                      // 666
  var tries = NUM_OPTIMISTIC_TRIES;                                                                   // 667
                                                                                                      // 668
  var doUpdate = function () {                                                                        // 669
    tries--;                                                                                          // 670
    if (! tries) {                                                                                    // 671
      callback(new Error("Upsert failed after " + NUM_OPTIMISTIC_TRIES + " tries."));                 // 672
    } else {                                                                                          // 673
      collection.update(selector, mod, mongoOptsForUpdate,                                            // 674
                        bindEnvironmentForWrite(function (err, result) {                              // 675
                          if (err)                                                                    // 676
                            callback(err);                                                            // 677
                          else if (result)                                                            // 678
                            callback(null, {                                                          // 679
                              numberAffected: result                                                  // 680
                            });                                                                       // 681
                          else                                                                        // 682
                            doConditionalInsert();                                                    // 683
                        }));                                                                          // 684
    }                                                                                                 // 685
  };                                                                                                  // 686
                                                                                                      // 687
  var doConditionalInsert = function () {                                                             // 688
    var replacementWithId = _.extend(                                                                 // 689
      replaceTypes({_id: insertedId}, replaceMeteorAtomWithRedis),                                    // 690
      newDoc);                                                                                        // 691
    collection.update(selector, replacementWithId, mongoOptsForInsert,                                // 692
                      bindEnvironmentForWrite(function (err, result) {                                // 693
                        if (err) {                                                                    // 694
                          // figure out if this is a                                                  // 695
                          // "cannot change _id of document" error, and                               // 696
                          // if so, try doUpdate() again, up to 3 times.                              // 697
                          if (RedisConnection._isCannotChangeIdError(err)) {                          // 698
                            doUpdate();                                                               // 699
                          } else {                                                                    // 700
                            callback(err);                                                            // 701
                          }                                                                           // 702
                        } else {                                                                      // 703
                          callback(null, {                                                            // 704
                            numberAffected: result,                                                   // 705
                            insertedId: insertedId                                                    // 706
                          });                                                                         // 707
                        }                                                                             // 708
                      }));                                                                            // 709
  };                                                                                                  // 710
                                                                                                      // 711
  doUpdate();                                                                                         // 712
};                                                                                                    // 713
                                                                                                      // 714
_.each(["insert", "update", "remove", "dropCollection"], function (method) {                          // 715
  RedisConnection.prototype[method] = function (/* arguments */) {                                    // 716
    throw new Error("not part of redis api");                                                         // 717
  };                                                                                                  // 718
});                                                                                                   // 719
                                                                                                      // 720
_.each(REDIS_COMMANDS_LOCAL, function (method) {                                                      // 721
  RedisConnection.prototype[method] = function (/* arguments */) {                                    // 722
    var self = this;                                                                                  // 723
    var wrapAsync = Meteor.wrapAsync || Meteor._wrapAsync;                                            // 724
    return wrapAsync(self._client[method]).apply(self._client, arguments);                            // 725
  };                                                                                                  // 726
});                                                                                                   // 727
                                                                                                      // 728
_.each(["set", "setex", "append", "del",                                                              // 729
        "incr", "incrby", "incrbyfloat", "decr", "decrby",                                            // 730
        "flushall"].concat(REDIS_COMMANDS_HASH), function (method) {                                  // 731
  if (_.has(REDIS_COMMANDS_LOCAL, method)) {                                                          // 732
    return;                                                                                           // 733
  }                                                                                                   // 734
                                                                                                      // 735
  RedisConnection.prototype[method] = function (/* arguments */) {                                    // 736
    var self = this;                                                                                  // 737
    var wrapAsync = Meteor.wrapAsync || Meteor._wrapAsync;                                            // 738
    return wrapAsync(self["_" + method]).apply(self, arguments);                                      // 739
  };                                                                                                  // 740
                                                                                                      // 741
  RedisConnection.prototype["_" + method] = function (key /*, arguments */) {                         // 742
    var self = this;                                                                                  // 743
                                                                                                      // 744
    var args = _.toArray(arguments);                                                                  // 745
                                                                                                      // 746
    var callback = args.pop();                                                                        // 747
                                                                                                      // 748
    var sendError = function (e) {                                                                    // 749
      if (callback)                                                                                   // 750
        return callback(e);                                                                           // 751
      throw e;                                                                                        // 752
    };                                                                                                // 753
                                                                                                      // 754
    var collection_name = 'redis';                                                                    // 755
                                                                                                      // 756
    var write = self._maybeBeginWrite();                                                              // 757
    var refresh = function () {                                                                       // 758
      Meteor.refresh({ collection: collection_name, id: key });                                       // 759
    };                                                                                                // 760
    callback = bindEnvironmentForWrite(writeCallback(write, refresh, callback));                      // 761
    try {                                                                                             // 762
      args.push(callback);                                                                            // 763
      //var collection = self._getCollection(collection_name);                                        // 764
      var self = this;                                                                                // 765
                                                                                                      // 766
      var future = new Future;                                                                        // 767
      self._withDb(function (db) {                                                                    // 768
        future.return(db);                                                                            // 769
      });                                                                                             // 770
      var db = future.wait();                                                                         // 771
      db[method].apply(db, args);                                                                     // 772
    } catch (e) {                                                                                     // 773
      write.committed();                                                                              // 774
      throw e;                                                                                        // 775
    }                                                                                                 // 776
  };                                                                                                  // 777
});                                                                                                   // 778
                                                                                                      // 779
RedisConnection.prototype.matching = function (collectionName, pattern) {                             // 780
  var self = this;                                                                                    // 781
                                                                                                      // 782
  return new Cursor(                                                                                  // 783
    self, new CursorDescription(collectionName, pattern));                                            // 784
};                                                                                                    // 785
                                                                                                      // 786
RedisConnection.prototype._observe = function (observer) {                                            // 787
  var self = this;                                                                                    // 788
  return new RedisObserver(self._watcher, observer);                                                  // 789
};                                                                                                    // 790
                                                                                                      // 791
                                                                                                      // 792
// We'll actually design an index API later. For now, we just pass through to                         // 793
// Mongo's, but make it synchronous.                                                                  // 794
RedisConnection.prototype._ensureIndex = function (collectionName, index,                             // 795
                                                   options) {                                         // 796
  var self = this;                                                                                    // 797
  options = _.extend({safe: true}, options);                                                          // 798
                                                                                                      // 799
  // We expect this function to be called at startup, not from within a method,                       // 800
  // so we don't interact with the write fence.                                                       // 801
  var collection = self._getCollection(collectionName);                                               // 802
  var future = new Future;                                                                            // 803
  var indexName = collection.ensureIndex(index, options, future.resolver());                          // 804
  future.wait();                                                                                      // 805
};                                                                                                    // 806
RedisConnection.prototype._dropIndex = function (collectionName, index) {                             // 807
  var self = this;                                                                                    // 808
                                                                                                      // 809
  // This function is only used by test code, not within a method, so we don't                        // 810
  // interact with the write fence.                                                                   // 811
  var collection = self._getCollection(collectionName);                                               // 812
  var future = new Future;                                                                            // 813
  var indexName = collection.dropIndex(index, future.resolver());                                     // 814
  future.wait();                                                                                      // 815
};                                                                                                    // 816
                                                                                                      // 817
// CURSORS                                                                                            // 818
                                                                                                      // 819
// There are several classes which relate to cursors:                                                 // 820
//                                                                                                    // 821
// CursorDescription represents the arguments used to construct a cursor:                             // 822
// collectionName, selector, and (find) options.  Because it is used as a key                         // 823
// for cursor de-dup, everything in it should either be JSON-stringifiable or                         // 824
// not affect observeChanges output (eg, options.transform functions are not                          // 825
// stringifiable but do not affect observeChanges).                                                   // 826
//                                                                                                    // 827
// SynchronousCursor is a wrapper around a MongoDB cursor                                             // 828
// which includes fully-synchronous versions of forEach, etc.                                         // 829
//                                                                                                    // 830
// Cursor is the cursor object returned from find(), which implements the                             // 831
// documented Meteor.RedisCollection cursor API.  It wraps a CursorDescription and a                  // 832
// SynchronousCursor (lazily: it doesn't contact Mongo until you call a method                        // 833
// like fetch or forEach on it).                                                                      // 834
//                                                                                                    // 835
// ObserveHandle is the "observe handle" returned from observeChanges. It has a                       // 836
// reference to an ObserveMultiplexer.                                                                // 837
//                                                                                                    // 838
// ObserveMultiplexer allows multiple identical ObserveHandles to be driven by a                      // 839
// single observe driver.                                                                             // 840
//                                                                                                    // 841
// There is one "observe driver" which drives ObserveMultiplexers:                                    // 842
//   - KeyspaceNotificationObserveDriver uses redis keyspace notifications to                         // 843
//     directly observe database changes.                                                             // 844
// Implementations follow the normal driver interface: when you create them,                          // 845
// they start sending observeChanges callbacks (and a ready() invocation) to                          // 846
// their ObserveMultiplexer, and you stop them by calling their stop() method.                        // 847
                                                                                                      // 848
CursorDescription = function (collectionName, pattern) {                                              // 849
  var self = this;                                                                                    // 850
  self.collectionName = collectionName;                                                               // 851
  self.pattern = pattern;                                                                             // 852
  self.options = {};                                                                                  // 853
};                                                                                                    // 854
                                                                                                      // 855
Cursor = function (connection, cursorDescription) {                                                   // 856
  var self = this;                                                                                    // 857
                                                                                                      // 858
  self._connection = connection;                                                                      // 859
  self._cursorDescription = cursorDescription;                                                        // 860
  self._synchronousCursor = null;                                                                     // 861
};                                                                                                    // 862
                                                                                                      // 863
_.each(['forEach', 'map', 'rewind', 'fetch', 'count'], function (method) {                            // 864
  Cursor.prototype[method] = function () {                                                            // 865
    var self = this;                                                                                  // 866
                                                                                                      // 867
    // You can only observe a tailable cursor.                                                        // 868
    if (self._cursorDescription.options.tailable)                                                     // 869
      throw new Error("Cannot call " + method + " on a tailable cursor");                             // 870
                                                                                                      // 871
    if (!self._synchronousCursor) {                                                                   // 872
      self._synchronousCursor = self._connection._createSynchronousCursor(                            // 873
        self._cursorDescription, {                                                                    // 874
          // Make sure that the "self" argument to forEach/map callbacks is the                       // 875
          // Cursor, not the SynchronousCursor.                                                       // 876
          selfForIteration: self,                                                                     // 877
          useTransform: true                                                                          // 878
        });                                                                                           // 879
    }                                                                                                 // 880
                                                                                                      // 881
    return self._synchronousCursor[method].apply(                                                     // 882
      self._synchronousCursor, arguments);                                                            // 883
  };                                                                                                  // 884
});                                                                                                   // 885
                                                                                                      // 886
Cursor.prototype.getTransform = function () {                                                         // 887
  return this._cursorDescription.options.transform;                                                   // 888
};                                                                                                    // 889
                                                                                                      // 890
// When you call Meteor.publish() with a function that returns a Cursor, we need                      // 891
// to transmute it into the equivalent subscription.  This is the function that                       // 892
// does that.                                                                                         // 893
                                                                                                      // 894
Cursor.prototype._publishCursor = function (sub) {                                                    // 895
  var self = this;                                                                                    // 896
  var collection = "redis"; // XXX don't hard-code this                                               // 897
  return Meteor.RedisCollection._publishCursor(self, sub, collection);                                // 898
};                                                                                                    // 899
                                                                                                      // 900
// Used to guarantee that publish functions return at most one cursor per                             // 901
// collection. Private, because we might later have cursors that include                              // 902
// documents from multiple collections somehow.                                                       // 903
Cursor.prototype._getCollectionName = function () {                                                   // 904
  var self = this;                                                                                    // 905
  return self._cursorDescription.collectionName;                                                      // 906
};                                                                                                    // 907
                                                                                                      // 908
                                                                                                      // 909
Cursor.prototype.observe = function (callbacks) {                                                     // 910
  var self = this;                                                                                    // 911
  //return self._connection._observe(callbacks);                                                      // 912
  var pattern = self._cursorDescription.pattern;                                                      // 913
  return self._connection._observe(self._cursorDescription, callbacks);                               // 914
//  return LocalCollection._observeFromObserveChanges(self, callbacks);                               // 915
};                                                                                                    // 916
                                                                                                      // 917
Cursor.prototype.observeChanges = function (callbacks) {                                              // 918
  var self = this;                                                                                    // 919
  //var ordered = LocalCollection._observeChangesCallbacksAreOrdered(callbacks);                      // 920
//  return self._connection._observeChanges(                                                          // 921
//    self._cursorDescription, ordered, callbacks);                                                   // 922
  try {                                                                                               // 923
    return self._connection._observeChanges(self._cursorDescription, callbacks);                      // 924
  } catch (e) {                                                                                       // 925
    Meteor._debug("Error in _observeChanges", e.stack);                                               // 926
    throw e;                                                                                          // 927
  }                                                                                                   // 928
};                                                                                                    // 929
                                                                                                      // 930
RedisConnection.prototype._createSynchronousCursor = function(                                        // 931
    cursorDescription, options) {                                                                     // 932
  var self = this;                                                                                    // 933
                                                                                                      // 934
  var pattern = cursorDescription.pattern;                                                            // 935
//  options = _.pick(options || {}, 'selfForIteration', 'useTransform');                              // 936
                                                                                                      // 937
//  var collection = self._getCollection(cursorDescription.collectionName);                           // 938
//  var cursorOptions = cursorDescription.options;                                                    // 939
//  var mongoOptions = {                                                                              // 940
//    sort: cursorOptions.sort,                                                                       // 941
//    limit: cursorOptions.limit,                                                                     // 942
//    skip: cursorOptions.skip                                                                        // 943
//  };                                                                                                // 944
                                                                                                      // 945
//  // Do we want a tailable cursor (which only works on capped collections)?                         // 946
//  if (cursorOptions.tailable) {                                                                     // 947
//    // We want a tailable cursor...                                                                 // 948
//    mongoOptions.tailable = true;                                                                   // 949
//    // ... and for the server to wait a bit if any getMore has no data (rather                      // 950
//    // than making us put the relevant sleeps in the client)...                                     // 951
//    mongoOptions.awaitdata = true;                                                                  // 952
//    // ... and to keep querying the server indefinitely rather than just 5 times                    // 953
//    // if there's no more data.                                                                     // 954
//    mongoOptions.numberOfRetries = -1;                                                              // 955
//    // And if this is on the oplog collection and the cursor specifies a 'ts',                      // 956
//    // then set the undocumented oplog replay flag, which does a special scan to                    // 957
//    // find the first document (instead of creating an index on ts). This is a                      // 958
//    // very hard-coded Mongo flag which only works on the oplog collection and                      // 959
//    // only works with the ts field.                                                                // 960
//    if (cursorDescription.collectionName === OPLOG_COLLECTION &&                                    // 961
//        cursorDescription.selector.ts) {                                                            // 962
//      mongoOptions.oplogReplay = true;                                                              // 963
//    }                                                                                               // 964
//  }                                                                                                 // 965
                                                                                                      // 966
                                                                                                      // 967
//  var dbCursor = collection.find(                                                                   // 968
//    replaceTypes(cursorDescription.selector, replaceMeteorAtomWithRedis),                           // 969
//    cursorOptions.fields, mongoOptions);                                                            // 970
//                                                                                                    // 971
//  return new SynchronousCursor(dbCursor, cursorDescription, options);                               // 972
                                                                                                      // 973
                                                                                                      // 974
  var future = new Future;                                                                            // 975
  self._withDb(function (db) {                                                                        // 976
    db.matching(pattern, future.resolver());                                                          // 977
  });                                                                                                 // 978
  var entries = future.wait();                                                                        // 979
                                                                                                      // 980
  return new SynchronousCursor(entries, cursorDescription, options);                                  // 981
                                                                                                      // 982
};                                                                                                    // 983
                                                                                                      // 984
var SynchronousCursor = function (entries, cursorDescription, options) {                              // 985
  var self = this;                                                                                    // 986
//  options = _.pick(options || {}, 'selfForIteration', 'useTransform');                              // 987
                                                                                                      // 988
  self._entries = entries;                                                                            // 989
  self._pos = -1;                                                                                     // 990
  self._cursorDescription = cursorDescription;                                                        // 991
  // The "self" argument passed to forEach/map callbacks. If we're wrapped                            // 992
  // inside a user-visible Cursor, we want to provide the outer cursor!                               // 993
//  self._selfForIteration = options.selfForIteration || self;                                        // 994
//  if (options.useTransform && cursorDescription.options.transform) {                                // 995
//    self._transform = LocalCollection.wrapTransform(                                                // 996
//      cursorDescription.options.transform);                                                         // 997
//  } else {                                                                                          // 998
//    self._transform = null;                                                                         // 999
//  }                                                                                                 // 1000
                                                                                                      // 1001
  // Need to specify that the callback is the first argument to nextObject,                           // 1002
  // since otherwise when we try to call it with no args the driver will                              // 1003
  // interpret "undefined" first arg as an options hash and crash.                                    // 1004
//  self._synchronousNextObject = Future.wrap(                                                        // 1005
//    dbCursor.nextObject.bind(dbCursor), 0);                                                         // 1006
//  self._synchronousCount = Future.wrap(dbCursor.count.bind(dbCursor));                              // 1007
  self._visitedIds = new IdMap; // LocalCollection._IdMap;                                            // 1008
};                                                                                                    // 1009
                                                                                                      // 1010
_.extend(SynchronousCursor.prototype, {                                                               // 1011
//  _synchronousNextObject: function () {                                                             // 1012
//                                                                                                    // 1013
//  },                                                                                                // 1014
  _nextObject: function () {                                                                          // 1015
    var self = this;                                                                                  // 1016
                                                                                                      // 1017
    while (true) {                                                                                    // 1018
      //var doc = self._synchronousNextObject().wait();                                               // 1019
      var doc;                                                                                        // 1020
      if ((self._pos + 1) < self._entries.length) {                                                   // 1021
        self._pos++;                                                                                  // 1022
        doc = self._entries[self._pos];                                                               // 1023
      }                                                                                               // 1024
                                                                                                      // 1025
      if (!doc) return null;                                                                          // 1026
      doc = replaceTypes(doc, replaceRedisAtomWithMeteor);                                            // 1027
                                                                                                      // 1028
      if (!self._cursorDescription.options.tailable && _.has(doc, '_id')) {                           // 1029
        // Did Mongo give us duplicate documents in the same cursor? If so,                           // 1030
        // ignore this one. (Do this before the transform, since transform might                      // 1031
        // return some unrelated value.) We don't do this for tailable cursors,                       // 1032
        // because we want to maintain O(1) memory usage. And if there isn't _id                      // 1033
        // for some reason (maybe it's the oplog), then we don't do this either.                      // 1034
        // (Be careful to do this for falsey but existing _id, though.)                               // 1035
        if (self._visitedIds.has(doc._id)) continue;                                                  // 1036
        self._visitedIds.set(doc._id, true);                                                          // 1037
      }                                                                                               // 1038
                                                                                                      // 1039
      if (self._transform)                                                                            // 1040
        doc = self._transform(doc);                                                                   // 1041
                                                                                                      // 1042
      return doc;                                                                                     // 1043
    }                                                                                                 // 1044
  },                                                                                                  // 1045
                                                                                                      // 1046
  forEach: function (callback, thisArg) {                                                             // 1047
    var self = this;                                                                                  // 1048
                                                                                                      // 1049
    // We implement the loop ourself instead of using self._dbCursor.each,                            // 1050
    // because "each" will call its callback outside of a fiber which makes it                        // 1051
    // much more complex to make this function synchronous.                                           // 1052
    var index = 0;                                                                                    // 1053
    while (true) {                                                                                    // 1054
      var doc = self._nextObject();                                                                   // 1055
      if (!doc) return;                                                                               // 1056
      callback.call(thisArg, doc, index++, self._selfForIteration);                                   // 1057
    }                                                                                                 // 1058
  },                                                                                                  // 1059
                                                                                                      // 1060
  // XXX Allow overlapping callback executions if callback yields.                                    // 1061
  map: function (callback, thisArg) {                                                                 // 1062
    var self = this;                                                                                  // 1063
    var res = [];                                                                                     // 1064
    self.forEach(function (doc, index) {                                                              // 1065
      res.push(callback.call(thisArg, doc, index, self._selfForIteration));                           // 1066
    });                                                                                               // 1067
    return res;                                                                                       // 1068
  },                                                                                                  // 1069
                                                                                                      // 1070
  rewind: function () {                                                                               // 1071
    var self = this;                                                                                  // 1072
                                                                                                      // 1073
    self._pos = -1;                                                                                   // 1074
                                                                                                      // 1075
    self._visitedIds = new IdMap;                                                                     // 1076
  },                                                                                                  // 1077
                                                                                                      // 1078
  // No-op since we don't actually have a connection to the database.                                 // 1079
  close: function () {},                                                                              // 1080
                                                                                                      // 1081
  fetch: function () {                                                                                // 1082
    var self = this;                                                                                  // 1083
    return self.map(_.identity);                                                                      // 1084
  },                                                                                                  // 1085
                                                                                                      // 1086
  count: function () {                                                                                // 1087
    var self = this;                                                                                  // 1088
    return self._entries.length;                                                                      // 1089
//    return self._synchronousCount().wait();                                                         // 1090
  },                                                                                                  // 1091
                                                                                                      // 1092
  // This method is NOT wrapped in Cursor.                                                            // 1093
  getRawObjects: function (ordered) {                                                                 // 1094
    var self = this;                                                                                  // 1095
    if (ordered) {                                                                                    // 1096
      return self.fetch();                                                                            // 1097
    } else {                                                                                          // 1098
      var results = new IdMap;                                                                        // 1099
      self.forEach(function (doc) {                                                                   // 1100
        results.set(doc._id, doc);                                                                    // 1101
      });                                                                                             // 1102
      return results;                                                                                 // 1103
    }                                                                                                 // 1104
  }                                                                                                   // 1105
});                                                                                                   // 1106
                                                                                                      // 1107
RedisConnection.prototype._observeChanges = function (cursorDescription, callbacks) {                 // 1108
  var self = this;                                                                                    // 1109
                                                                                                      // 1110
//  if (cursorDescription.options.tailable) {                                                         // 1111
//    return self._observeChangesTailable(cursorDescription, ordered, callbacks);                     // 1112
//  }                                                                                                 // 1113
                                                                                                      // 1114
//  // You may not filter out _id when observing changes, because the id is a core                    // 1115
//  // part of the observeChanges API.                                                                // 1116
//  if (cursorDescription.options.fields &&                                                           // 1117
//      (cursorDescription.options.fields._id === 0 ||                                                // 1118
//       cursorDescription.options.fields._id === false)) {                                           // 1119
//    throw Error("You may not observe a cursor with {fields: {_id: 0}}");                            // 1120
//  }                                                                                                 // 1121
                                                                                                      // 1122
  var observeKey = JSON.stringify(                                                                    // 1123
    _.extend({ /*ordered: ordered */}, cursorDescription));                                           // 1124
                                                                                                      // 1125
  var multiplexer, observeDriver;                                                                     // 1126
  var firstHandle = false;                                                                            // 1127
                                                                                                      // 1128
  // Find a matching ObserveMultiplexer, or create a new one. This next block is                      // 1129
  // guaranteed to not yield (and it doesn't call anything that can observe a                         // 1130
  // new query), so no other calls to this function can interleave with it.                           // 1131
  Meteor._noYieldsAllowed(function () {                                                               // 1132
    if (_.has(self._observeMultiplexers, observeKey)) {                                               // 1133
      multiplexer = self._observeMultiplexers[observeKey];                                            // 1134
    } else {                                                                                          // 1135
      firstHandle = true;                                                                             // 1136
      // Create a new ObserveMultiplexer.                                                             // 1137
      multiplexer = new ObserveMultiplexer({                                                          // 1138
        //ordered: ordered,                                                                           // 1139
        onStop: function () {                                                                         // 1140
          observeDriver.stop();                                                                       // 1141
          delete self._observeMultiplexers[observeKey];                                               // 1142
        }                                                                                             // 1143
      });                                                                                             // 1144
      self._observeMultiplexers[observeKey] = multiplexer;                                            // 1145
    }                                                                                                 // 1146
  });                                                                                                 // 1147
                                                                                                      // 1148
  var observeHandle = new ObserveHandle(multiplexer, callbacks);                                      // 1149
                                                                                                      // 1150
  if (firstHandle) {                                                                                  // 1151
    var driverClass = KeyspaceNotificationObserveDriver;                                              // 1152
    observeDriver = new driverClass({                                                                 // 1153
      cursorDescription: cursorDescription,                                                           // 1154
      mongoHandle: self,                                                                              // 1155
      multiplexer: multiplexer,                                                                       // 1156
      _testOnlyPollCallback: callbacks._testOnlyPollCallback                                          // 1157
    });                                                                                               // 1158
                                                                                                      // 1159
    // This field is only set for use in tests.                                                       // 1160
    multiplexer._observeDriver = observeDriver;                                                       // 1161
  }                                                                                                   // 1162
                                                                                                      // 1163
  // Blocks until the initial adds have been sent.                                                    // 1164
  multiplexer.addHandleAndSendInitialAdds(observeHandle);                                             // 1165
                                                                                                      // 1166
  return observeHandle;                                                                               // 1167
};                                                                                                    // 1168
                                                                                                      // 1169
// Listen for the invalidation messages that will trigger us to poll the                              // 1170
// database for changes. If this selector specifies specific IDs, specify them                        // 1171
// here, so that updates to different specific IDs don't cause us to poll.                            // 1172
// listenCallback is the same kind of (notification, complete) callback passed                        // 1173
// to InvalidationCrossbar.listen.                                                                    // 1174
                                                                                                      // 1175
listenAll = function (cursorDescription, listenCallback) {                                            // 1176
  var listeners = [];                                                                                 // 1177
  forEachTrigger(cursorDescription, function (trigger) {                                              // 1178
    listeners.push(DDPServer._InvalidationCrossbar.listen(                                            // 1179
      trigger, listenCallback));                                                                      // 1180
  });                                                                                                 // 1181
                                                                                                      // 1182
  return {                                                                                            // 1183
    stop: function () {                                                                               // 1184
      _.each(listeners, function (listener) {                                                         // 1185
        listener.stop();                                                                              // 1186
      });                                                                                             // 1187
    }                                                                                                 // 1188
  };                                                                                                  // 1189
};                                                                                                    // 1190
                                                                                                      // 1191
forEachTrigger = function (cursorDescription, triggerCallback) {                                      // 1192
//  var key = {collection: cursorDescription.collectionName};                                         // 1193
  var key = { collection: 'redis' };                                                                  // 1194
//  var specificIds = LocalCollection._idsMatchedBySelector(                                          // 1195
//    cursorDescription.selector);                                                                    // 1196
//  if (specificIds) {                                                                                // 1197
//    _.each(specificIds, function (id) {                                                             // 1198
//      triggerCallback(_.extend({id: id}, key));                                                     // 1199
//    });                                                                                             // 1200
//    triggerCallback(_.extend({dropCollection: true, id: null}, key));                               // 1201
//  } else {                                                                                          // 1202
    triggerCallback(key);                                                                             // 1203
//  }                                                                                                 // 1204
};                                                                                                    // 1205
                                                                                                      // 1206
// observeChanges for tailable cursors on capped collections.                                         // 1207
//                                                                                                    // 1208
// Some differences from normal cursors:                                                              // 1209
//   - Will never produce anything other than 'added' or 'addedBefore'. If you                        // 1210
//     do update a document that has already been produced, this will not notice                      // 1211
//     it.                                                                                            // 1212
//   - If you disconnect and reconnect from Mongo, it will essentially restart                        // 1213
//     the query, which will lead to duplicate results. This is pretty bad,                           // 1214
//     but if you include a field called 'ts' which is inserted as                                    // 1215
//     new RedisInternals.MongoTimestamp(0, 0) (which is initialized to the                           // 1216
//     current Mongo-style timestamp), we'll be able to find the place to                             // 1217
//     restart properly. (This field is specifically understood by Mongo with an                      // 1218
//     optimization which allows it to find the right place to start without                          // 1219
//     an index on ts. It's how the oplog works.)                                                     // 1220
//   - No callbacks are triggered synchronously with the call (there's no                             // 1221
//     differentiation between "initial data" and "later changes"; everything                         // 1222
//     that matches the query gets sent asynchronously).                                              // 1223
//   - De-duplication is not implemented.                                                             // 1224
//   - Does not yet interact with the write fence. Probably, this should work by                      // 1225
//     ignoring removes (which don't work on capped collections) and updates                          // 1226
//     (which don't affect tailable cursors), and just keeping track of the ID                        // 1227
//     of the inserted object, and closing the write fence once you get to that                       // 1228
//     ID (or timestamp?).  This doesn't work well if the document doesn't match                      // 1229
//     the query, though.  On the other hand, the write fence can close                               // 1230
//     immediately if it does not match the query. So if we trust minimongo                           // 1231
//     enough to accurately evaluate the query against the write fence, we                            // 1232
//     should be able to do this...  Of course, minimongo doesn't even support                        // 1233
//     Mongo Timestamps yet.                                                                          // 1234
RedisConnection.prototype._observeChangesTailable = function (                                        // 1235
    cursorDescription, ordered, callbacks) {                                                          // 1236
  var self = this;                                                                                    // 1237
                                                                                                      // 1238
  // Tailable cursors only ever call added/addedBefore callbacks, so it's an                          // 1239
  // error if you didn't provide them.                                                                // 1240
  if ((ordered && !callbacks.addedBefore) ||                                                          // 1241
      (!ordered && !callbacks.added)) {                                                               // 1242
    throw new Error("Can't observe an " + (ordered ? "ordered" : "unordered")                         // 1243
                    + " tailable cursor without a "                                                   // 1244
                    + (ordered ? "addedBefore" : "added") + " callback");                             // 1245
  }                                                                                                   // 1246
                                                                                                      // 1247
  return self.tail(cursorDescription, function (doc) {                                                // 1248
    var id = doc._id;                                                                                 // 1249
    delete doc._id;                                                                                   // 1250
    // The ts is an implementation detail. Hide it.                                                   // 1251
    delete doc.ts;                                                                                    // 1252
    if (ordered) {                                                                                    // 1253
      callbacks.addedBefore(id, doc, null);                                                           // 1254
    } else {                                                                                          // 1255
      callbacks.added(id, doc);                                                                       // 1256
    }                                                                                                 // 1257
  });                                                                                                 // 1258
};                                                                                                    // 1259
                                                                                                      // 1260
// XXX We probably need to find a better way to expose this. Right now                                // 1261
// it's only used by tests, but in fact you need it in normal                                         // 1262
// operation to interact with capped collections (eg, Galaxy uses it).                                // 1263
//RedisInternals.MongoTimestamp = MongoDB.Timestamp;                                                  // 1264
                                                                                                      // 1265
RedisInternals.Connection = RedisConnection;                                                          // 1266
                                                                                                      // 1267
////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// packages/slava:redis-livedata/oplog_tailing.js                                                     //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
var Future = Npm.require('fibers/future');                                                            // 1
                                                                                                      // 2
//OPLOG_COLLECTION = 'oplog.rs';                                                                      // 3
//var REPLSET_COLLECTION = 'system.replset';                                                          // 4
                                                                                                      // 5
// Like Perl's quotemeta: quotes all regexp metacharacters. See                                       // 6
//   https://github.com/substack/quotemeta/blob/master/index.js                                       // 7
// XXX this is duplicated with accounts_server.js                                                     // 8
var quotemeta = function (str) {                                                                      // 9
    return String(str).replace(/(\W)/g, '\\$1');                                                      // 10
};                                                                                                    // 11
                                                                                                      // 12
var showTS = function (ts) {                                                                          // 13
  return "Timestamp(" + ts.getHighBits() + ", " + ts.getLowBits() + ")";                              // 14
};                                                                                                    // 15
                                                                                                      // 16
idForOp = function (op) {                                                                             // 17
  if (op.op === 'd')                                                                                  // 18
    return op.o._id;                                                                                  // 19
  else if (op.op === 'i')                                                                             // 20
    return op.o._id;                                                                                  // 21
  else if (op.op === 'u')                                                                             // 22
    return op.o2._id;                                                                                 // 23
  else if (op.op === 'c')                                                                             // 24
    throw Error("Operator 'c' doesn't supply an object with id: " +                                   // 25
                EJSON.stringify(op));                                                                 // 26
  else                                                                                                // 27
    throw Error("Unknown op: " + EJSON.stringify(op));                                                // 28
};                                                                                                    // 29
                                                                                                      // 30
OplogHandle = function (client, watcher /*oplogUrl, dbName*/) {                                       // 31
  var self = this;                                                                                    // 32
  self._client = client;                                                                              // 33
//  self._oplogUrl = oplogUrl;                                                                        // 34
//  self._dbName = dbName;                                                                            // 35
  self._watcher = watcher;                                                                            // 36
                                                                                                      // 37
  self._oplogLastEntryConnection = null;                                                              // 38
  self._oplogTailConnection = null;                                                                   // 39
  self._stopped = false;                                                                              // 40
  self._tailHandle = null;                                                                            // 41
  self._readyFuture = new Future();                                                                   // 42
  self._crossbar = new DDPServer._Crossbar({                                                          // 43
    factPackage: "redis-livedata", factName: "oplog-watchers"                                         // 44
  });                                                                                                 // 45
  self._lastProcessedTS = null;                                                                       // 46
  self._baseOplogSelector = {                                                                         // 47
    ns: new RegExp('^' + quotemeta(self._dbName) + '\\.'),                                            // 48
    $or: [                                                                                            // 49
      { op: {$in: ['i', 'u', 'd']} },                                                                 // 50
      // If it is not db.collection.drop(), ignore it                                                 // 51
      { op: 'c', 'o.drop': { $exists: true } }]                                                       // 52
  };                                                                                                  // 53
  // XXX doc                                                                                          // 54
  self._catchingUpFutures = [];                                                                       // 55
                                                                                                      // 56
  self._startTailing();                                                                               // 57
};                                                                                                    // 58
                                                                                                      // 59
_.extend(OplogHandle.prototype, {                                                                     // 60
  stop: function () {                                                                                 // 61
    var self = this;                                                                                  // 62
    if (self._stopped)                                                                                // 63
      return;                                                                                         // 64
    self._stopped = true;                                                                             // 65
    if (self._tailHandle)                                                                             // 66
      self._tailHandle.stop();                                                                        // 67
    // XXX should close connections too                                                               // 68
  },                                                                                                  // 69
  onOplogEntry: function (trigger, callback) {                                                        // 70
    var self = this;                                                                                  // 71
    if (self._stopped)                                                                                // 72
      throw new Error("Called onOplogEntry on stopped handle!");                                      // 73
                                                                                                      // 74
    // Calling onOplogEntry requires us to wait for the tailing to be ready.                          // 75
    self._readyFuture.wait();                                                                         // 76
                                                                                                      // 77
    var originalCallback = callback;                                                                  // 78
    callback = Meteor.bindEnvironment(function (notification) {                                       // 79
      // XXX can we avoid this clone by making oplog.js careful?                                      // 80
      originalCallback(EJSON.clone(notification));                                                    // 81
    }, function (err) {                                                                               // 82
      Meteor._debug("Error in oplog callback", err.stack);                                            // 83
    });                                                                                               // 84
    var listenHandle = self._crossbar.listen(trigger, callback);                                      // 85
    return {                                                                                          // 86
      stop: function () {                                                                             // 87
        listenHandle.stop();                                                                          // 88
      }                                                                                               // 89
    };                                                                                                // 90
  },                                                                                                  // 91
  // Calls `callback` once the oplog has been processed up to a point that is                         // 92
  // roughly "now": specifically, once we've processed all ops that are                               // 93
  // currently visible.                                                                               // 94
  // XXX become convinced that this is actually safe even if oplogConnection                          // 95
  // is some kind of pool                                                                             // 96
  waitUntilCaughtUp: function () {                                                                    // 97
    var self = this;                                                                                  // 98
    if (self._stopped)                                                                                // 99
      throw new Error("Called waitUntilCaughtUp on stopped handle!");                                 // 100
                                                                                                      // 101
    // Calling waitUntilCaughtUp requires us to wait for the oplog connection to                      // 102
    // be ready.                                                                                      // 103
    self._readyFuture.wait();                                                                         // 104
                                                                                                      // 105
//    while (!self._stopped) {                                                                        // 106
//      // We need to make the selector at least as restrictive as the actual                         // 107
//      // tailing selector (ie, we need to specify the DB name) or else we might                     // 108
//      // find a TS that won't show up in the actual tail stream.                                    // 109
//      try {                                                                                         // 110
//        var lastEntry = self._oplogLastEntryConnection.findOne(                                     // 111
//          OPLOG_COLLECTION, self._baseOplogSelector,                                                // 112
//          {fields: {ts: 1}, sort: {$natural: -1}});                                                 // 113
//        break;                                                                                      // 114
//      } catch (e) {                                                                                 // 115
//        // During failover (eg) if we get an exception we should log and retry                      // 116
//        // instead of crashing.                                                                     // 117
//        Meteor._debug("Got exception while reading last entry: ", e.stack);                         // 118
//        Meteor._sleepForMs(100);                                                                    // 119
//      }                                                                                             // 120
//    }                                                                                               // 121
                                                                                                      // 122
    if (self._stopped)                                                                                // 123
      return;                                                                                         // 124
                                                                                                      // 125
//    if (!lastEntry) {                                                                               // 126
//      // Really, nothing in the oplog? Well, we've processed everything.                            // 127
//      return;                                                                                       // 128
//    }                                                                                               // 129
                                                                                                      // 130
    var ts = self._publishSequenceKey();                                                              // 131
//    var ts = lastEntry.ts;                                                                          // 132
//    if (!ts)                                                                                        // 133
//      throw Error("oplog entry without ts: " + EJSON.stringify(lastEntry));                         // 134
//                                                                                                    // 135
//    if (self._lastProcessedTS && ts.lessThanOrEqual(self._lastProcessedTS)) {                       // 136
//      // We've already caught up to here.                                                           // 137
//      return;                                                                                       // 138
//    }                                                                                               // 139
                                                                                                      // 140
                                                                                                      // 141
    // Insert the future into our list. Almost always, this will be at the end,                       // 142
    // but it's conceivable that if we fail over from one primary to another,                         // 143
    // the oplog entries we see will go backwards.                                                    // 144
    var insertAfter = self._catchingUpFutures.length;                                                 // 145
    while (insertAfter - 1 > 0                                                                        // 146
           && (self._catchingUpFutures[insertAfter - 1].ts > ts)) {                                   // 147
      insertAfter--;                                                                                  // 148
    }                                                                                                 // 149
    var f = new Future;                                                                               // 150
    self._catchingUpFutures.splice(insertAfter, 0, {ts: ts, future: f});                              // 151
    f.wait();                                                                                         // 152
  },                                                                                                  // 153
  _publishSequenceKey: function () {                                                                  // 154
    var self = this;                                                                                  // 155
                                                                                                      // 156
    var seq = self._sequenceSent + 1;                                                                 // 157
    self._client.publish("__keyspace@0__:" + self._sequenceKey, "sequence_" + seq,                    // 158
      function (err, results) {                                                                       // 159
        if (err != null) {                                                                            // 160
          // TODO: Panic?                                                                             // 161
          Meteor._debug("Error while publishing sequence key: " + err);                               // 162
        } else {                                                                                      // 163
          self._sequenceAcked++;                                                                      // 164
        }                                                                                             // 165
      }                                                                                               // 166
    );                                                                                                // 167
    self._sequenceSent++;                                                                             // 168
    return seq;                                                                                       // 169
  },                                                                                                  // 170
  _gotSequenceKey: function(message) {                                                                // 171
    var self = this;                                                                                  // 172
                                                                                                      // 173
    if (message != ("sequence_" + (self._sequenceSeen + 1))) {                                        // 174
      Meteor._debug("Got out-of-sequence message: " + message + " vs " + (self._sequenceSeen + 1));   // 175
      throw new Error("Sequence received out of sequence");                                           // 176
    }                                                                                                 // 177
                                                                                                      // 178
    self._sequenceSeen++;                                                                             // 179
                                                                                                      // 180
    var ts = self._sequenceSeen;                                                                      // 181
    // Now that we've processed this operation, process pending sequencers.                           // 182
    while (!_.isEmpty(self._catchingUpFutures)                                                        // 183
      && (self._catchingUpFutures[0].ts <= ts)) {                                                     // 184
      var sequencer = self._catchingUpFutures.shift();                                                // 185
      sequencer.future.return();                                                                      // 186
    }                                                                                                 // 187
  },                                                                                                  // 188
  _startTailing: function () {                                                                        // 189
    var self = this;                                                                                  // 190
//    // We make two separate connections to Mongo. The Node Mongo driver                             // 191
//    // implements a naive round-robin connection pool: each "connection" is a                       // 192
//    // pool of several (5 by default) TCP connections, and each request is                          // 193
//    // rotated through the pools. Tailable cursor queries block on the server                       // 194
//    // until there is some data to return (or until a few seconds have                              // 195
//    // passed). So if the connection pool used for tailing cursors is the same                      // 196
//    // pool used for other queries, the other queries will be delayed by seconds                    // 197
//    // 1/5 of the time.                                                                             // 198
//    //                                                                                              // 199
//    // The tail connection will only ever be running a single tail command, so                      // 200
//    // it only needs to make one underlying TCP connection.                                         // 201
//    self._oplogTailConnection = new RedisConnection(                                                // 202
//      self._oplogUrl, {poolSize: 1});                                                               // 203
//    // XXX better docs, but: it's to get monotonic results                                          // 204
//    // XXX is it safe to say "if there's an in flight query, just use its                           // 205
//    //     results"? I don't think so but should consider that                                      // 206
//    self._oplogLastEntryConnection = new RedisConnection(                                           // 207
//      self._oplogUrl, {poolSize: 1});                                                               // 208
//                                                                                                    // 209
//    // First, make sure that there actually is a repl set here. If not, oplog                       // 210
//    // tailing won't ever find anything! (Blocks until the connection is ready.)                    // 211
//    var replSetInfo = self._oplogLastEntryConnection.findOne(                                       // 212
//      REPLSET_COLLECTION, {});                                                                      // 213
//    if (!replSetInfo)                                                                               // 214
//      throw Error("$MONGO_OPLOG_URL must be set to the 'local' database of " +                      // 215
//                  "a Mongo replica set");                                                           // 216
//                                                                                                    // 217
//    // Find the last oplog entry.                                                                   // 218
//    var lastOplogEntry = self._oplogLastEntryConnection.findOne(                                    // 219
//      OPLOG_COLLECTION, {}, {sort: {$natural: -1}, fields: {ts: 1}});                               // 220
//                                                                                                    // 221
//    var oplogSelector = _.clone(self._baseOplogSelector);                                           // 222
//    if (lastOplogEntry) {                                                                           // 223
//      // Start after the last entry that currently exists.                                          // 224
//      oplogSelector.ts = {$gt: lastOplogEntry.ts};                                                  // 225
//      // If there are any calls to callWhenProcessedLatest before any other                         // 226
//      // oplog entries show up, allow callWhenProcessedLatest to call its                           // 227
//      // callback immediately.                                                                      // 228
//      self._lastProcessedTS = lastOplogEntry.ts;                                                    // 229
//    }                                                                                               // 230
//                                                                                                    // 231
//    var cursorDescription = new CursorDescription(                                                  // 232
//      OPLOG_COLLECTION, oplogSelector, {tailable: true});                                           // 233
                                                                                                      // 234
    self._sequenceSent = 0;                                                                           // 235
    self._sequenceAcked = 0;                                                                          // 236
    self._sequenceSeen = 0;                                                                           // 237
    // We need a unique key so we can have multiple Meteor servers                                    // 238
    var sequencePrefix = "__meteor_sequence_";                                                        // 239
    self._sequenceKey = sequencePrefix + Random.id() + "__";                                          // 240
                                                                                                      // 241
    self._tailHandle = self._watcher.addListener(function (key, message) {                            // 242
      // Observe our sequence keys, making sure to trap other servers' keys too so they're            // 243
      // not published as keyspace operations.                                                        // 244
      if (key.indexOf(sequencePrefix) === 0) {                                                        // 245
        if (key === self._sequenceKey) {                                                              // 246
          self._gotSequenceKey(message);                                                              // 247
        }                                                                                             // 248
        return;                                                                                       // 249
      }                                                                                               // 250
                                                                                                      // 251
      // Other events are keyspace operations.                                                        // 252
      // XXX collection name                                                                          // 253
      var trigger = {collection: "redis",                                                             // 254
                     id: key,                                                                         // 255
                     message: message };                                                              // 256
                                                                                                      // 257
                                                                                                      // 258
      self._crossbar.fire(trigger);                                                                   // 259
                                                                                                      // 260
//      // Now that we've processed this operation, process pending sequencers.                       // 261
//      if (!doc.ts)                                                                                  // 262
//        throw Error("oplog entry without ts: " + EJSON.stringify(doc));                             // 263
//      self._lastProcessedTS = doc.ts;                                                               // 264
//      while (!_.isEmpty(self._catchingUpFutures)                                                    // 265
//             && self._catchingUpFutures[0].ts.lessThanOrEqual(                                      // 266
//               self._lastProcessedTS)) {                                                            // 267
//        var sequencer = self._catchingUpFutures.shift();                                            // 268
//        sequencer.future.return();                                                                  // 269
//      }                                                                                             // 270
    });                                                                                               // 271
//    self._tailHandle = self._oplogTailConnection.tail(                                              // 272
//      cursorDescription, function (doc) {                                                           // 273
//        if (!(doc.ns && doc.ns.length > self._dbName.length + 1 &&                                  // 274
//              doc.ns.substr(0, self._dbName.length + 1) ===                                         // 275
//              (self._dbName + '.'))) {                                                              // 276
//          throw new Error("Unexpected ns");                                                         // 277
//        }                                                                                           // 278
//                                                                                                    // 279
//        var trigger = {collection: doc.ns.substr(self._dbName.length + 1),                          // 280
//                       dropCollection: false,                                                       // 281
//                       op: doc};                                                                    // 282
//                                                                                                    // 283
//        // Is it a special command and the collection name is hidden somewhere                      // 284
//        // in operator?                                                                             // 285
//        if (trigger.collection === "$cmd") {                                                        // 286
//          trigger.collection = doc.o.drop;                                                          // 287
//          trigger.dropCollection = true;                                                            // 288
//          trigger.id = null;                                                                        // 289
//        } else {                                                                                    // 290
//          // All other ops have an id.                                                              // 291
//          trigger.id = idForOp(doc);                                                                // 292
//        }                                                                                           // 293
//                                                                                                    // 294
//        self._crossbar.fire(trigger);                                                               // 295
//                                                                                                    // 296
//        // Now that we've processed this operation, process pending sequencers.                     // 297
//        if (!doc.ts)                                                                                // 298
//          throw Error("oplog entry without ts: " + EJSON.stringify(doc));                           // 299
//        self._lastProcessedTS = doc.ts;                                                             // 300
//        while (!_.isEmpty(self._catchingUpFutures)                                                  // 301
//               && self._catchingUpFutures[0].ts.lessThanOrEqual(                                    // 302
//                 self._lastProcessedTS)) {                                                          // 303
//          var sequencer = self._catchingUpFutures.shift();                                          // 304
//          sequencer.future.return();                                                                // 305
//        }                                                                                           // 306
//      });                                                                                           // 307
    self._readyFuture.return();                                                                       // 308
  }                                                                                                   // 309
});                                                                                                   // 310
                                                                                                      // 311
////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// packages/slava:redis-livedata/observe_multiplex.js                                                 //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
var Future = Npm.require('fibers/future');                                                            // 1
                                                                                                      // 2
ObserveHelpers = {};                                                                                  // 3
                                                                                                      // 4
//_CachingChangeObserver is an object which receives observeChanges callbacks                         // 5
//and keeps a cache of the current cursor state up to date in self.docs. Users                        // 6
//of this class should read the docs field but not modify it. You should pass                         // 7
//the "applyChange" field as the callbacks to the underlying observeChanges                           // 8
//call. Optionally, you can specify your own observeChanges callbacks which are                       // 9
//invoked immediately before the docs field is updated; this object is made                           // 10
//available as `this` to those callbacks.                                                             // 11
ObserveHelpers._CachingChangeObserver = function (options) {                                          // 12
  var self = this;                                                                                    // 13
  options = options || {};                                                                            // 14
                                                                                                      // 15
  var orderedFromCallbacks = false;                                                                   // 16
  //options.callbacks &&                                                                              // 17
  //     LocalCollection._observeChangesCallbacksAreOrdered(options.callbacks);                       // 18
  if (_.has(options, 'ordered')) {                                                                    // 19
    self.ordered = options.ordered;                                                                   // 20
    if (options.callbacks && options.ordered !== orderedFromCallbacks)                                // 21
      throw Error("ordered option doesn't match callbacks");                                          // 22
  } else if (options.callbacks) {                                                                     // 23
    self.ordered = orderedFromCallbacks;                                                              // 24
  } else {                                                                                            // 25
    throw Error("must provide ordered or callbacks");                                                 // 26
  }                                                                                                   // 27
  var callbacks = options.callbacks || {};                                                            // 28
                                                                                                      // 29
  if (self.ordered) {                                                                                 // 30
    self.docs = new OrderedDict(LocalCollection._idStringify);                                        // 31
    self.applyChange = {                                                                              // 32
      addedBefore: function (id, fields, before) {                                                    // 33
        var doc = EJSON.clone(fields);                                                                // 34
        doc._id = id;                                                                                 // 35
        callbacks.addedBefore && callbacks.addedBefore.call(                                          // 36
          self, id, fields, before);                                                                  // 37
          // This line triggers if we provide added with movedBefore.                                 // 38
          callbacks.added && callbacks.added.call(self, id, fields);                                  // 39
          // XXX could `before` be a falsy ID?  Technically                                           // 40
          // idStringify seems to allow for them -- though                                            // 41
          // OrderedDict won't call stringify on a falsy arg.                                         // 42
          self.docs.putBefore(id, doc, before || null);                                               // 43
      },                                                                                              // 44
      movedBefore: function (id, before) {                                                            // 45
        var doc = self.docs.get(id);                                                                  // 46
        callbacks.movedBefore && callbacks.movedBefore.call(self, id, before);                        // 47
        self.docs.moveBefore(id, before || null);                                                     // 48
      }                                                                                               // 49
    };                                                                                                // 50
  } else {                                                                                            // 51
    //self.docs = new LocalCollection._IdMap;                                                         // 52
    self.docs = new IdMap(EJSON.stringify, EJSON.parse);                                              // 53
    self.applyChange = {                                                                              // 54
      added: function (id, fields) {                                                                  // 55
        var doc = EJSON.clone(fields);                                                                // 56
        callbacks.added && callbacks.added.call(self, id, fields);                                    // 57
        doc._id = id;                                                                                 // 58
        self.docs.set(id,  doc);                                                                      // 59
      }                                                                                               // 60
    };                                                                                                // 61
  }                                                                                                   // 62
                                                                                                      // 63
  // The methods in _IdMap and OrderedDict used by these callbacks are                                // 64
  // identical.                                                                                       // 65
  self.applyChange.changed = function (id, fields) {                                                  // 66
    var doc = self.docs.get(id);                                                                      // 67
    if (!doc)                                                                                         // 68
      throw new Error("Unknown id for changed: " + id);                                               // 69
    callbacks.changed && callbacks.changed.call(                                                      // 70
      self, id, EJSON.clone(fields));                                                                 // 71
      _applyChanges(doc, fields);                                                                     // 72
  };                                                                                                  // 73
  self.applyChange.removed = function (id) {                                                          // 74
    callbacks.removed && callbacks.removed.call(self, id);                                            // 75
    self.docs.remove(id);                                                                             // 76
  };                                                                                                  // 77
};                                                                                                    // 78
                                                                                                      // 79
var _applyChanges = function (doc, changeFields) {                                                    // 80
  _.each(changeFields, function (value, key) {                                                        // 81
    if (value === undefined)                                                                          // 82
      delete doc[key];                                                                                // 83
    else                                                                                              // 84
      doc[key] = value;                                                                               // 85
  });                                                                                                 // 86
};                                                                                                    // 87
                                                                                                      // 88
                                                                                                      // 89
                                                                                                      // 90
ObserveMultiplexer = function (options) {                                                             // 91
  var self = this;                                                                                    // 92
                                                                                                      // 93
//  if (!options || !_.has(options, 'ordered'))                                                       // 94
//    throw Error("must specified ordered");                                                          // 95
                                                                                                      // 96
  Package.facts && Package.facts.Facts.incrementServerFact(                                           // 97
    "redis-livedata", "observe-multiplexers", 1);                                                     // 98
                                                                                                      // 99
  self._ordered = !!options.ordered;                                                                  // 100
  self._onStop = options.onStop || function () {};                                                    // 101
  self._queue = new Meteor._SynchronousQueue();                                                       // 102
  self._handles = {};                                                                                 // 103
  self._readyFuture = new Future;                                                                     // 104
  self._cache = new ObserveHelpers._CachingChangeObserver({                                           // 105
    ordered: options.ordered});                                                                       // 106
  // Number of addHandleAndSendInitialAdds tasks scheduled but not yet                                // 107
  // running. removeHandle uses this to know if it's time to call the onStop                          // 108
  // callback.                                                                                        // 109
  self._addHandleTasksScheduledButNotPerformed = 0;                                                   // 110
                                                                                                      // 111
  _.each(self.callbackNames(), function (callbackName) {                                              // 112
    self[callbackName] = function (/* ... */) {                                                       // 113
      self._applyCallback(callbackName, _.toArray(arguments));                                        // 114
    };                                                                                                // 115
  });                                                                                                 // 116
};                                                                                                    // 117
                                                                                                      // 118
_.extend(ObserveMultiplexer.prototype, {                                                              // 119
  addHandleAndSendInitialAdds: function (handle) {                                                    // 120
    var self = this;                                                                                  // 121
                                                                                                      // 122
    // Check this before calling runTask (even though runTask does the same                           // 123
    // check) so that we don't leak an ObserveMultiplexer on error by                                 // 124
    // incrementing _addHandleTasksScheduledButNotPerformed and never                                 // 125
    // decrementing it.                                                                               // 126
    if (!self._queue.safeToRunTask())                                                                 // 127
      throw new Error(                                                                                // 128
        "Can't call observeChanges from an observe callback on the same query");                      // 129
    ++self._addHandleTasksScheduledButNotPerformed;                                                   // 130
                                                                                                      // 131
    Package.facts && Package.facts.Facts.incrementServerFact(                                         // 132
      "redis-livedata", "observe-handles", 1);                                                        // 133
                                                                                                      // 134
    self._queue.runTask(function () {                                                                 // 135
      self._handles[handle._id] = handle;                                                             // 136
      // Send out whatever adds we have so far (whether or not we the                                 // 137
      // multiplexer is ready).                                                                       // 138
      self._sendAdds(handle);                                                                         // 139
      --self._addHandleTasksScheduledButNotPerformed;                                                 // 140
    });                                                                                               // 141
    // *outside* the task, since otherwise we'd deadlock                                              // 142
    self._readyFuture.wait();                                                                         // 143
  },                                                                                                  // 144
                                                                                                      // 145
  // Remove an observe handle. If it was the last observe handle, call the                            // 146
  // onStop callback; you cannot add any more observe handles after this.                             // 147
  //                                                                                                  // 148
  // This is not synchronized with polls and handle additions: this means that                        // 149
  // you can safely call it from within an observe callback, but it also means                        // 150
  // that we have to be careful when we iterate over _handles.                                        // 151
  removeHandle: function (id) {                                                                       // 152
    var self = this;                                                                                  // 153
                                                                                                      // 154
    // This should not be possible: you can only call removeHandle by having                          // 155
    // access to the ObserveHandle, which isn't returned to user code until the                       // 156
    // multiplex is ready.                                                                            // 157
    if (!self._ready())                                                                               // 158
      throw new Error("Can't remove handles until the multiplex is ready");                           // 159
                                                                                                      // 160
    delete self._handles[id];                                                                         // 161
                                                                                                      // 162
    Package.facts && Package.facts.Facts.incrementServerFact(                                         // 163
      "redis-livedata", "observe-handles", -1);                                                       // 164
                                                                                                      // 165
    if (_.isEmpty(self._handles) &&                                                                   // 166
        self._addHandleTasksScheduledButNotPerformed === 0) {                                         // 167
      self._stop();                                                                                   // 168
    }                                                                                                 // 169
  },                                                                                                  // 170
  _stop: function () {                                                                                // 171
    var self = this;                                                                                  // 172
    // It shouldn't be possible for us to stop when all our handles still                             // 173
    // haven't been returned from observeChanges!                                                     // 174
    if (!self._ready())                                                                               // 175
      throw Error("surprising _stop: not ready");                                                     // 176
                                                                                                      // 177
    // Call stop callback (which kills the underlying process which sends us                          // 178
    // callbacks and removes us from the connection's dictionary).                                    // 179
    self._onStop();                                                                                   // 180
    Package.facts && Package.facts.Facts.incrementServerFact(                                         // 181
      "redis-livedata", "observe-multiplexers", -1);                                                  // 182
                                                                                                      // 183
    // Cause future addHandleAndSendInitialAdds calls to throw (but the onStop                        // 184
    // callback should make our connection forget about us).                                          // 185
    self._handles = null;                                                                             // 186
  },                                                                                                  // 187
  // Allows all addHandleAndSendInitialAdds calls to return, once all preceding                       // 188
  // adds have been processed. Does not block.                                                        // 189
  ready: function () {                                                                                // 190
    var self = this;                                                                                  // 191
    self._queue.queueTask(function () {                                                               // 192
      if (self._ready())                                                                              // 193
        throw Error("can't make ObserveMultiplex ready twice!");                                      // 194
      self._readyFuture.return();                                                                     // 195
    });                                                                                               // 196
  },                                                                                                  // 197
  // Calls "cb" once the effects of all "ready", "addHandleAndSendInitialAdds"                        // 198
  // and observe callbacks which came before this call have been propagated to                        // 199
  // all handles. "ready" must have already been called on this multiplexer.                          // 200
  onFlush: function (cb) {                                                                            // 201
    var self = this;                                                                                  // 202
    self._queue.queueTask(function () {                                                               // 203
      if (!self._ready())                                                                             // 204
        throw Error("only call onFlush on a multiplexer that will be ready");                         // 205
      cb();                                                                                           // 206
    });                                                                                               // 207
  },                                                                                                  // 208
  callbackNames: function () {                                                                        // 209
    var self = this;                                                                                  // 210
    if (self._ordered)                                                                                // 211
      return ["addedBefore", "changed", "movedBefore", "removed"];                                    // 212
    else                                                                                              // 213
      return ["added", "changed", "removed"];                                                         // 214
  },                                                                                                  // 215
  _ready: function () {                                                                               // 216
    return this._readyFuture.isResolved();                                                            // 217
  },                                                                                                  // 218
  _applyCallback: function (callbackName, args) {                                                     // 219
    var self = this;                                                                                  // 220
    self._queue.queueTask(function () {                                                               // 221
      // If we stopped in the meantime, do nothing.                                                   // 222
      if (!self._handles)                                                                             // 223
        return;                                                                                       // 224
                                                                                                      // 225
      // First, apply the change to the cache.                                                        // 226
      // XXX We could make applyChange callbacks promise not to hang on to any                        // 227
      // state from their arguments (assuming that their supplied callbacks                           // 228
      // don't) and skip this clone. Currently 'changed' hangs on to state                            // 229
      // though.                                                                                      // 230
      self._cache.applyChange[callbackName].apply(null, EJSON.clone(args));                           // 231
                                                                                                      // 232
      // If we haven't finished the initial adds, then we should only be getting                      // 233
      // adds.                                                                                        // 234
      if (!self._ready() &&                                                                           // 235
          (callbackName !== 'added' && callbackName !== 'addedBefore')) {                             // 236
        throw new Error("Got " + callbackName + " during initial adds");                              // 237
      }                                                                                               // 238
                                                                                                      // 239
      // Now multiplex the callbacks out to all observe handles. It's OK if                           // 240
      // these calls yield; since we're inside a task, no other use of our queue                      // 241
      // can continue until these are done. (But we do have to be careful to not                      // 242
      // use a handle that got removed, because removeHandle does not use the                         // 243
      // queue; thus, we iterate over an array of keys that we control.)                              // 244
      _.each(_.keys(self._handles), function (handleId) {                                             // 245
        var handle = self._handles && self._handles[handleId];                                        // 246
        if (!handle)                                                                                  // 247
          return;                                                                                     // 248
        var callback = handle['_' + callbackName];                                                    // 249
        // clone arguments so that callbacks can mutate their arguments                               // 250
        callback && callback.apply(null, EJSON.clone(args));                                          // 251
      });                                                                                             // 252
    });                                                                                               // 253
  },                                                                                                  // 254
                                                                                                      // 255
  // Sends initial adds to a handle. It should only be called from within a task                      // 256
  // (the task that is processing the addHandleAndSendInitialAdds call). It                           // 257
  // synchronously invokes the handle's added or addedBefore; there's no need to                      // 258
  // flush the queue afterwards to ensure that the callbacks get out.                                 // 259
  _sendAdds: function (handle) {                                                                      // 260
    var self = this;                                                                                  // 261
    if (self._queue.safeToRunTask())                                                                  // 262
      throw Error("_sendAdds may only be called from within a task!");                                // 263
    var add = self._ordered ? handle._addedBefore : handle._added;                                    // 264
    if (!add)                                                                                         // 265
      return;                                                                                         // 266
    // note: docs may be an _IdMap or an OrderedDict                                                  // 267
    self._cache.docs.forEach(function (doc, id) {                                                     // 268
      if (!_.has(self._handles, handle._id))                                                          // 269
        throw Error("handle got removed before sending initial adds!");                               // 270
      var fields = EJSON.clone(doc);                                                                  // 271
      delete fields._id;                                                                              // 272
      if (self._ordered)                                                                              // 273
        add(id, fields, null); // we're going in order, so add at end                                 // 274
      else                                                                                            // 275
        add(id, fields);                                                                              // 276
    });                                                                                               // 277
  }                                                                                                   // 278
});                                                                                                   // 279
                                                                                                      // 280
                                                                                                      // 281
var nextObserveHandleId = 1;                                                                          // 282
ObserveHandle = function (multiplexer, callbacks) {                                                   // 283
  var self = this;                                                                                    // 284
  // The end user is only supposed to call stop().  The other fields are                              // 285
  // accessible to the multiplexer, though.                                                           // 286
  self._multiplexer = multiplexer;                                                                    // 287
  _.each(multiplexer.callbackNames(), function (name) {                                               // 288
    if (callbacks[name]) {                                                                            // 289
      self['_' + name] = callbacks[name];                                                             // 290
    } else if (name === "addedBefore" && callbacks.added) {                                           // 291
      // Special case: if you specify "added" and "movedBefore", you get an                           // 292
      // ordered observe where for some reason you don't get ordering data on                         // 293
      // the adds.  I dunno, we wrote tests for it, there must have been a                            // 294
      // reason.                                                                                      // 295
      self._addedBefore = function (id, fields, before) {                                             // 296
        callbacks.added(id, fields);                                                                  // 297
      };                                                                                              // 298
    }                                                                                                 // 299
  });                                                                                                 // 300
  self._stopped = false;                                                                              // 301
  self._id = nextObserveHandleId++;                                                                   // 302
};                                                                                                    // 303
ObserveHandle.prototype.stop = function () {                                                          // 304
  var self = this;                                                                                    // 305
  if (self._stopped)                                                                                  // 306
    return;                                                                                           // 307
  self._stopped = true;                                                                               // 308
  self._multiplexer.removeHandle(self._id);                                                           // 309
};                                                                                                    // 310
                                                                                                      // 311
////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// packages/slava:redis-livedata/doc_fetcher.js                                                       //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
var Fiber = Npm.require('fibers');                                                                    // 1
var Future = Npm.require('fibers/future');                                                            // 2
                                                                                                      // 3
DocFetcher = function (mongoConnection) {                                                             // 4
  var self = this;                                                                                    // 5
  self._mongoConnection = mongoConnection;                                                            // 6
  // Map from cache key -> [callback]                                                                 // 7
  self._callbacksForCacheKey = {};                                                                    // 8
};                                                                                                    // 9
                                                                                                      // 10
_.extend(DocFetcher.prototype, {                                                                      // 11
  // Fetches document "id" from collectionName, returning it or null if not                           // 12
  // found.                                                                                           // 13
  //                                                                                                  // 14
  // If you make multiple calls to fetch() with the same cacheKey (a string),                         // 15
  // DocFetcher may assume that they all return the same document. (It does                           // 16
  // not check to see if collectionName/id match.)                                                    // 17
  //                                                                                                  // 18
  // You may assume that callback is never called synchronously (and in fact                          // 19
  // OplogObserveDriver does so).                                                                     // 20
  fetch: function (collectionName, id, method, cacheKey, callback) {                                  // 21
    var self = this;                                                                                  // 22
                                                                                                      // 23
    check(collectionName, String);                                                                    // 24
    // id is some sort of scalar                                                                      // 25
    check(cacheKey, String);                                                                          // 26
                                                                                                      // 27
    // If there's already an in-progress fetch for this cache key, yield until                        // 28
    // it's done and return whatever it returns.                                                      // 29
    if (cacheKey && _.has(self._callbacksForCacheKey, cacheKey)) {                                    // 30
      self._callbacksForCacheKey[cacheKey].push(callback);                                            // 31
      return;                                                                                         // 32
    }                                                                                                 // 33
                                                                                                      // 34
    var callbacks = [callback];                                                                       // 35
    if (cacheKey) {                                                                                   // 36
      self._callbacksForCacheKey[cacheKey] = callbacks;                                               // 37
    }                                                                                                 // 38
                                                                                                      // 39
    Fiber(function () {                                                                               // 40
      try {                                                                                           // 41
//        var doc = self._mongoConnection.findOne(                                                    // 42
//          collectionName, {_id: id}) || null;                                                       // 43
        // XXX Rename get to _sync_get                                                                // 44
        var value = self._mongoConnection[method].apply(self._mongoConnection, [id]) || null;         // 45
                                                                                                      // 46
        var doc;                                                                                      // 47
        if (value) {                                                                                  // 48
          // XXX a hack to always box the value into Miniredis.Hash                                   // 49
          if (method === 'hgetall') {                                                                 // 50
            value = new Miniredis.Hash(value);                                                        // 51
          }                                                                                           // 52
          doc = { _id: id, value: value};                                                             // 53
        }                                                                                             // 54
        // Return doc to all relevant callbacks. Note that this array can                             // 55
        // continue to grow during callback excecution.                                               // 56
        while (!_.isEmpty(callbacks)) {                                                               // 57
          // Clone the document so that the various calls to fetch don't return                       // 58
          // objects that are intertwingled with each other. Clone before                             // 59
          // popping the future, so that if clone throws, the error gets passed                       // 60
          // to the next callback.                                                                    // 61
          var clonedDoc = EJSON.clone(doc);                                                           // 62
          callbacks.pop()(null, clonedDoc);                                                           // 63
        }                                                                                             // 64
      } catch (e) {                                                                                   // 65
        Meteor._debug("Error in doc_fetcher::fetch", e.stack);                                        // 66
        while (!_.isEmpty(callbacks)) {                                                               // 67
          callbacks.pop()(e);                                                                         // 68
        }                                                                                             // 69
      } finally {                                                                                     // 70
        // XXX consider keeping the doc around for a period of time before                            // 71
        // removing from the cache                                                                    // 72
        if (cacheKey) {                                                                               // 73
          delete self._callbacksForCacheKey[cacheKey];                                                // 74
        }                                                                                             // 75
      }                                                                                               // 76
    }).run();                                                                                         // 77
  }                                                                                                   // 78
});                                                                                                   // 79
                                                                                                      // 80
RedisTest.DocFetcher = DocFetcher;                                                                    // 81
                                                                                                      // 82
////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// packages/slava:redis-livedata/keyspace_notification_observe_driver.js                              //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
var Fiber = Npm.require('fibers');                                                                    // 1
var Future = Npm.require('fibers/future');                                                            // 2
                                                                                                      // 3
var PHASE = {                                                                                         // 4
  QUERYING: "QUERYING",                                                                               // 5
  FETCHING: "FETCHING",                                                                               // 6
  STEADY: "STEADY"                                                                                    // 7
};                                                                                                    // 8
                                                                                                      // 9
// Exception thrown by _needToPollQuery which unrolls the stack up to the                             // 10
// enclosing call to finishIfNeedToPollQuery.                                                         // 11
var SwitchedToQuery = function () {};                                                                 // 12
var finishIfNeedToPollQuery = function (f) {                                                          // 13
  return function () {                                                                                // 14
    try {                                                                                             // 15
      f.apply(this, arguments);                                                                       // 16
    } catch (e) {                                                                                     // 17
      if (!(e instanceof SwitchedToQuery))                                                            // 18
        throw e;                                                                                      // 19
    }                                                                                                 // 20
  };                                                                                                  // 21
};                                                                                                    // 22
                                                                                                      // 23
// KeyspaceNotificationObserveDriver uses Redis keyspace notifications                                // 24
// to detect DB changes, cf the mongo_livedata Oplog Observe Driver.                                  // 25
// It obeys the same interface: constructing it starts sending observeChanges                         // 26
// callbacks (and a ready() invocation) to the ObserveMultiplexer, and you stop                       // 27
// it by calling the stop() method.                                                                   // 28
KeyspaceNotificationObserveDriver = function (options) {                                              // 29
  var self = this;                                                                                    // 30
  self._usesOplog = true;  // tests look at this                                                      // 31
                                                                                                      // 32
  self._cursorDescription = options.cursorDescription;                                                // 33
  self._mongoHandle = options.mongoHandle;                                                            // 34
  self._multiplexer = options.multiplexer;                                                            // 35
                                                                                                      // 36
  if (options.ordered) {                                                                              // 37
    throw Error("KeyspaceNotificationObserveDriver only supports unordered observeChanges");          // 38
  }                                                                                                   // 39
                                                                                                      // 40
  var sorter = options.sorter;                                                                        // 41
  // We don't support $near and other geo-queries so it's OK to initialize the                        // 42
  // comparator only once in the constructor.                                                         // 43
  var comparator = sorter && sorter.getComparator();                                                  // 44
                                                                                                      // 45
  if (options.cursorDescription.options.limit) {                                                      // 46
    // There are several properties ordered driver implements:                                        // 47
    // - _limit is a positive number                                                                  // 48
    // - _comparator is a function-comparator by which the query is ordered                           // 49
    // - _unpublishedBuffer is non-null Min/Max Heap,                                                 // 50
    //                      the empty buffer in STEADY phase implies that the                         // 51
    //                      everything that matches the queries selector fits                         // 52
    //                      into published set.                                                       // 53
    // - _published - Min Heap (also implements IdMap methods)                                        // 54
                                                                                                      // 55
    var heapOptions = {}; //{ IdMap: LocalCollection._IdMap };                                        // 56
    self._limit = self._cursorDescription.options.limit;                                              // 57
    self._comparator = comparator;                                                                    // 58
    self._sorter = sorter;                                                                            // 59
    self._unpublishedBuffer = new MinMaxHeap(comparator, heapOptions);                                // 60
    // We need something that can find Max value in addition to IdMap interface                       // 61
    self._published = new MaxHeap(comparator, heapOptions);                                           // 62
  } else {                                                                                            // 63
    self._limit = 0;                                                                                  // 64
    self._comparator = null;                                                                          // 65
    self._sorter = null;                                                                              // 66
    self._unpublishedBuffer = null;                                                                   // 67
//    self._published = new LocalCollection._IdMap;                                                   // 68
    self._published = new IdMap();                                                                    // 69
  }                                                                                                   // 70
                                                                                                      // 71
  // Indicates if it is safe to insert a new document at the end of the buffer                        // 72
  // for this query. i.e. it is known that there are no documents matching the                        // 73
  // selector those are not in published or buffer.                                                   // 74
  self._safeAppendToBuffer = false;                                                                   // 75
                                                                                                      // 76
  self._stopped = false;                                                                              // 77
  self._stopHandles = [];                                                                             // 78
                                                                                                      // 79
  Package.facts && Package.facts.Facts.incrementServerFact(                                           // 80
    "redis-livedata", "observe-drivers-oplog", 1);                                                    // 81
                                                                                                      // 82
  self._registerPhaseChange(PHASE.QUERYING);                                                          // 83
                                                                                                      // 84
//  var selector = self._cursorDescription.selector;                                                  // 85
//  self._matcher = options.matcher;                                                                  // 86
  //var projection = self._cursorDescription.options.fields || {};                                    // 87
  //self._projectionFn = LocalCollection._compileProjection(projection);                              // 88
  // Projection function, result of combining important fields for selector and                       // 89
  // existing fields projection                                                                       // 90
//  self._sharedProjection = self._matcher.combineIntoProjection(projection);                         // 91
//  if (sorter)                                                                                       // 92
//    self._sharedProjection = sorter.combineIntoProjection(self._sharedProjection);                  // 93
//  self._sharedProjectionFn = LocalCollection._compileProjection(                                    // 94
//    self._sharedProjection);                                                                        // 95
                                                                                                      // 96
//  self._needToFetch = new LocalCollection._IdMap;                                                   // 97
  self._needToFetch = new IdMap();                                                                    // 98
  self._currentlyFetching = null;                                                                     // 99
  self._fetchGeneration = 0;                                                                          // 100
                                                                                                      // 101
  self._requeryWhenDoneThisQuery = false;                                                             // 102
  self._writesToCommitWhenWeReachSteady = [];                                                         // 103
                                                                                                      // 104
  forEachTrigger(self._cursorDescription, function (trigger) {                                        // 105
    self._stopHandles.push(self._mongoHandle._oplogHandle.onOplogEntry(                               // 106
      trigger, function (notification) {                                                              // 107
        Meteor._noYieldsAllowed(finishIfNeedToPollQuery(function () {                                 // 108
//          var op = notification.op;                                                                 // 109
//          if (notification.dropCollection) {                                                        // 110
//            // Note: this call is not allowed to block on anything (especially                      // 111
//            // on waiting for oplog entries to catch up) because that will block                    // 112
//            // onOplogEntry!                                                                        // 113
//            self._needToPollQuery();                                                                // 114
//          } else {                                                                                  // 115
//            // All other operators should be handled depending on phase                             // 116
//            if (self._phase === PHASE.QUERYING)                                                     // 117
//              self._handleOplogEntryQuerying(op);                                                   // 118
//            else                                                                                    // 119
//              self._handleOplogEntrySteadyOrFetching(op);                                           // 120
//          }                                                                                         // 121
        // All other operators should be handled depending on phase                                   // 122
        if (self._phase === PHASE.QUERYING) {                                                         // 123
          self._handleOplogEntryQuerying(notification);                                               // 124
        } else {                                                                                      // 125
          self._handleOplogEntrySteadyOrFetching(notification);                                       // 126
        }                                                                                             // 127
        }));                                                                                          // 128
      }                                                                                               // 129
    ));                                                                                               // 130
  });                                                                                                 // 131
                                                                                                      // 132
  // XXX ordering w.r.t. everything else?                                                             // 133
  self._stopHandles.push(listenAll(                                                                   // 134
    self._cursorDescription, function (notification) {                                                // 135
      // If we're not in a write fence, we don't have to do anything.                                 // 136
      var fence = DDPServer._CurrentWriteFence.get();                                                 // 137
      if (!fence)                                                                                     // 138
        return;                                                                                       // 139
      var write = fence.beginWrite();                                                                 // 140
      // This write cannot complete until we've caught up to "this point" in the                      // 141
      // oplog, and then made it back to the steady state.                                            // 142
      Meteor.defer(function () {                                                                      // 143
        self._mongoHandle._oplogHandle.waitUntilCaughtUp();                                           // 144
        if (self._stopped) {                                                                          // 145
          // We're stopped, so just immediately commit.                                               // 146
          write.committed();                                                                          // 147
        } else if (self._phase === PHASE.STEADY) {                                                    // 148
          // Make sure that all of the callbacks have made it through the                             // 149
          // multiplexer and been delivered to ObserveHandles before committing                       // 150
          // writes.                                                                                  // 151
          self._multiplexer.onFlush(function () {                                                     // 152
            write.committed();                                                                        // 153
          });                                                                                         // 154
        } else {                                                                                      // 155
          self._writesToCommitWhenWeReachSteady.push(write);                                          // 156
        }                                                                                             // 157
      });                                                                                             // 158
    }                                                                                                 // 159
  ));                                                                                                 // 160
                                                                                                      // 161
  // When Mongo fails over, we need to repoll the query, in case we processed an                      // 162
  // oplog entry that got rolled back.                                                                // 163
  self._stopHandles.push(self._mongoHandle._onFailover(finishIfNeedToPollQuery(                       // 164
    function () {                                                                                     // 165
      self._needToPollQuery();                                                                        // 166
    })));                                                                                             // 167
                                                                                                      // 168
  // Give _observeChanges a chance to add the new ObserveHandle to our                                // 169
  // multiplexer, so that the added calls get streamed.                                               // 170
  Meteor.defer(finishIfNeedToPollQuery(function () {                                                  // 171
    self._runInitialQuery();                                                                          // 172
  }));                                                                                                // 173
};                                                                                                    // 174
                                                                                                      // 175
_.extend(KeyspaceNotificationObserveDriver.prototype, {                                               // 176
  _addPublished: function (id, doc) {                                                                 // 177
    var self = this;                                                                                  // 178
    var fields = _.clone(doc);                                                                        // 179
    delete fields._id;                                                                                // 180
    self._published.set(id, doc); //self._sharedProjectionFn(doc));                                   // 181
    self._multiplexer.added(id, fields); //self._projectionFn(fields));                               // 182
                                                                                                      // 183
    // After adding this document, the published set might be overflowed                              // 184
    // (exceeding capacity specified by limit). If so, push the maximum element                       // 185
    // to the buffer, we might want to save it in memory to reduce the amount of                      // 186
    // Mongo lookups in the future.                                                                   // 187
    if (self._limit && self._published.size() > self._limit) {                                        // 188
      // XXX in theory the size of published is no more than limit+1                                  // 189
      if (self._published.size() !== self._limit + 1) {                                               // 190
        throw new Error("After adding to published, " +                                               // 191
                        (self._published.size() - self._limit) +                                      // 192
                        " documents are overflowing the set");                                        // 193
      }                                                                                               // 194
                                                                                                      // 195
      var overflowingDocId = self._published.maxElementId();                                          // 196
      var overflowingDoc = self._published.get(overflowingDocId);                                     // 197
                                                                                                      // 198
      if (EJSON.equals(overflowingDocId, id)) {                                                       // 199
        throw new Error("The document just added is overflowing the published set");                  // 200
      }                                                                                               // 201
                                                                                                      // 202
      self._published.remove(overflowingDocId);                                                       // 203
      self._multiplexer.removed(overflowingDocId);                                                    // 204
      self._addBuffered(overflowingDocId, overflowingDoc);                                            // 205
    }                                                                                                 // 206
  },                                                                                                  // 207
  _removePublished: function (id) {                                                                   // 208
    var self = this;                                                                                  // 209
    self._published.remove(id);                                                                       // 210
    self._multiplexer.removed(id);                                                                    // 211
    if (! self._limit || self._published.size() === self._limit)                                      // 212
      return;                                                                                         // 213
                                                                                                      // 214
    if (self._published.size() > self._limit)                                                         // 215
      throw Error("self._published got too big");                                                     // 216
                                                                                                      // 217
    // OK, we are publishing less than the limit. Maybe we should look in the                         // 218
    // buffer to find the next element past what we were publishing before.                           // 219
                                                                                                      // 220
    if (!self._unpublishedBuffer.empty()) {                                                           // 221
      // There's something in the buffer; move the first thing in it to                               // 222
      // _published.                                                                                  // 223
      var newDocId = self._unpublishedBuffer.minElementId();                                          // 224
      var newDoc = self._unpublishedBuffer.get(newDocId);                                             // 225
      self._removeBuffered(newDocId);                                                                 // 226
      self._addPublished(newDocId, newDoc);                                                           // 227
      return;                                                                                         // 228
    }                                                                                                 // 229
                                                                                                      // 230
    // There's nothing in the buffer.  This could mean one of a few things.                           // 231
                                                                                                      // 232
    // (a) We could be in the middle of re-running the query (specifically, we                        // 233
    // could be in _publishNewResults). In that case, _unpublishedBuffer is                           // 234
    // empty because we clear it at the beginning of _publishNewResults. In this                      // 235
    // case, our caller already knows the entire answer to the query and we                           // 236
    // don't need to do anything fancy here.  Just return.                                            // 237
    if (self._phase === PHASE.QUERYING)                                                               // 238
      return;                                                                                         // 239
                                                                                                      // 240
    // (b) We're pretty confident that the union of _published and                                    // 241
    // _unpublishedBuffer contain all documents that match selector. Because                          // 242
    // _unpublishedBuffer is empty, that means we're confident that _published                        // 243
    // contains all documents that match selector. So we have nothing to do.                          // 244
    if (self._safeAppendToBuffer)                                                                     // 245
      return;                                                                                         // 246
                                                                                                      // 247
    // (c) Maybe there are other documents out there that should be in our                            // 248
    // buffer. But in that case, when we emptied _unpublishedBuffer in                                // 249
    // _removeBuffered, we should have called _needToPollQuery, which will                            // 250
    // either put something in _unpublishedBuffer or set _safeAppendToBuffer (or                      // 251
    // both), and it will put us in QUERYING for that whole time. So in fact, we                      // 252
    // shouldn't be able to get here.                                                                 // 253
                                                                                                      // 254
    throw new Error("Buffer inexplicably empty");                                                     // 255
  },                                                                                                  // 256
  _changePublished: function (id, oldDoc, newDoc) {                                                   // 257
    var self = this;                                                                                  // 258
    self._published.set(id, newDoc); //self._sharedProjectionFn(newDoc));                             // 259
    var changed =                                                                                     // 260
      EJSON.equals(oldDoc.value, newDoc.value) ? {} : { value: newDoc.value };                        // 261
    if (!_.isEmpty(changed))                                                                          // 262
      self._multiplexer.changed(id, changed);                                                         // 263
  },                                                                                                  // 264
  _addBuffered: function (id, doc) {                                                                  // 265
    var self = this;                                                                                  // 266
    self._unpublishedBuffer.set(id, doc); //self._sharedProjectionFn(doc));                           // 267
                                                                                                      // 268
    // If something is overflowing the buffer, we just remove it from cache                           // 269
    if (self._unpublishedBuffer.size() > self._limit) {                                               // 270
      var maxBufferedId = self._unpublishedBuffer.maxElementId();                                     // 271
                                                                                                      // 272
      self._unpublishedBuffer.remove(maxBufferedId);                                                  // 273
                                                                                                      // 274
      // Since something matching is removed from cache (both published set and                       // 275
      // buffer), set flag to false                                                                   // 276
      self._safeAppendToBuffer = false;                                                               // 277
    }                                                                                                 // 278
  },                                                                                                  // 279
  // Is called either to remove the doc completely from matching set or to move                       // 280
  // it to the published set later.                                                                   // 281
  _removeBuffered: function (id) {                                                                    // 282
    var self = this;                                                                                  // 283
    self._unpublishedBuffer.remove(id);                                                               // 284
    // To keep the contract "buffer is never empty in STEADY phase unless the                         // 285
    // everything matching fits into published" true, we poll everything as soon                      // 286
    // as we see the buffer becoming empty.                                                           // 287
    if (! self._unpublishedBuffer.size() && ! self._safeAppendToBuffer)                               // 288
      self._needToPollQuery();                                                                        // 289
  },                                                                                                  // 290
  // Called when a document has joined the "Matching" results set.                                    // 291
  // Takes responsibility of keeping _unpublishedBuffer in sync with _published                       // 292
  // and the effect of limit enforced.                                                                // 293
  _addMatching: function (doc) {                                                                      // 294
    var self = this;                                                                                  // 295
    var id = doc._id;                                                                                 // 296
    if (self._published.has(id))                                                                      // 297
      throw Error("tried to add something already published " + id);                                  // 298
    if (self._limit && self._unpublishedBuffer.has(id))                                               // 299
      throw Error("tried to add something already existed in buffer " + id);                          // 300
                                                                                                      // 301
    var limit = self._limit;                                                                          // 302
    var comparator = self._comparator;                                                                // 303
    var maxPublished = (limit && self._published.size() > 0) ?                                        // 304
      self._published.get(self._published.maxElementId()) : null;                                     // 305
    var maxBuffered = (limit && self._unpublishedBuffer.size() > 0) ?                                 // 306
      self._unpublishedBuffer.get(self._unpublishedBuffer.maxElementId()) : null;                     // 307
    // The query is unlimited or didn't publish enough documents yet or the new                       // 308
    // document would fit into published set pushing the maximum element out,                         // 309
    // then we need to publish the doc.                                                               // 310
    var toPublish = ! limit || self._published.size() < limit ||                                      // 311
                    comparator(doc, maxPublished) < 0;                                                // 312
                                                                                                      // 313
    // Otherwise we might need to buffer it (only in case of limited query).                          // 314
    // Buffering is allowed if the buffer is not filled up yet and all matching                       // 315
    // docs are either in the published set or in the buffer.                                         // 316
    var canAppendToBuffer = !toPublish && self._safeAppendToBuffer &&                                 // 317
                            self._unpublishedBuffer.size() < limit;                                   // 318
                                                                                                      // 319
    // Or if it is small enough to be safely inserted to the middle or the                            // 320
    // beginning of the buffer.                                                                       // 321
    var canInsertIntoBuffer = !toPublish && maxBuffered &&                                            // 322
                              comparator(doc, maxBuffered) <= 0;                                      // 323
                                                                                                      // 324
    var toBuffer = canAppendToBuffer || canInsertIntoBuffer;                                          // 325
                                                                                                      // 326
    if (toPublish) {                                                                                  // 327
      self._addPublished(id, doc);                                                                    // 328
    } else if (toBuffer) {                                                                            // 329
      self._addBuffered(id, doc);                                                                     // 330
    } else {                                                                                          // 331
      // dropping it and not saving to the cache                                                      // 332
      self._safeAppendToBuffer = false;                                                               // 333
    }                                                                                                 // 334
  },                                                                                                  // 335
  // Called when a document leaves the "Matching" results set.                                        // 336
  // Takes responsibility of keeping _unpublishedBuffer in sync with _published                       // 337
  // and the effect of limit enforced.                                                                // 338
  _removeMatching: function (id) {                                                                    // 339
    var self = this;                                                                                  // 340
    if (! self._published.has(id) && ! self._limit)                                                   // 341
      throw Error("tried to remove something matching but not cached " + id);                         // 342
                                                                                                      // 343
    if (self._published.has(id)) {                                                                    // 344
      self._removePublished(id);                                                                      // 345
    } else if (self._unpublishedBuffer.has(id)) {                                                     // 346
      self._removeBuffered(id);                                                                       // 347
    }                                                                                                 // 348
  },                                                                                                  // 349
  _handleDoc: function (id, newDoc) {                                                                 // 350
    var self = this;                                                                                  // 351
    var matchesNow = newDoc && Miniredis.patternToRegexp(self._cursorDescription.pattern).test(id); //self._matcher.documentMatches(newDoc).result;
                                                                                                      // 353
    var publishedBefore = self._published.has(id);                                                    // 354
    var bufferedBefore = self._limit && self._unpublishedBuffer.has(id);                              // 355
    var cachedBefore = publishedBefore || bufferedBefore;                                             // 356
                                                                                                      // 357
    if (matchesNow && !cachedBefore) {                                                                // 358
      self._addMatching(newDoc);                                                                      // 359
    } else if (cachedBefore && !matchesNow) {                                                         // 360
      self._removeMatching(id);                                                                       // 361
    } else if (cachedBefore && matchesNow) {                                                          // 362
      var oldDoc = self._published.get(id);                                                           // 363
      var comparator = self._comparator;                                                              // 364
      var minBuffered = self._limit && self._unpublishedBuffer.size() &&                              // 365
        self._unpublishedBuffer.get(self._unpublishedBuffer.minElementId());                          // 366
                                                                                                      // 367
      if (publishedBefore) {                                                                          // 368
        // Unlimited case where the document stays in published once it matches                       // 369
        // or the case when we don't have enough matching docs to publish or the                      // 370
        // changed but matching doc will stay in published anyways.                                   // 371
        // XXX: We rely on the emptiness of buffer. Be sure to maintain the fact                      // 372
        // that buffer can't be empty if there are matching documents not                             // 373
        // published. Notably, we don't want to schedule repoll and continue                          // 374
        // relying on this property.                                                                  // 375
        var staysInPublished = ! self._limit ||                                                       // 376
                               self._unpublishedBuffer.size() === 0 ||                                // 377
                               comparator(newDoc, minBuffered) <= 0;                                  // 378
                                                                                                      // 379
        if (staysInPublished) {                                                                       // 380
          self._changePublished(id, oldDoc, newDoc);                                                  // 381
        } else {                                                                                      // 382
          // after the change doc doesn't stay in the published, remove it                            // 383
          self._removePublished(id);                                                                  // 384
          // but it can move into buffered now, check it                                              // 385
          var maxBuffered = self._unpublishedBuffer.get(self._unpublishedBuffer.maxElementId());      // 386
                                                                                                      // 387
          var toBuffer = self._safeAppendToBuffer ||                                                  // 388
                         (maxBuffered && comparator(newDoc, maxBuffered) <= 0);                       // 389
                                                                                                      // 390
          if (toBuffer) {                                                                             // 391
            self._addBuffered(id, newDoc);                                                            // 392
          } else {                                                                                    // 393
            // Throw away from both published set and buffer                                          // 394
            self._safeAppendToBuffer = false;                                                         // 395
          }                                                                                           // 396
        }                                                                                             // 397
      } else if (bufferedBefore) {                                                                    // 398
        oldDoc = self._unpublishedBuffer.get(id);                                                     // 399
        // remove the old version manually so we don't trigger the querying                           // 400
        // immediately                                                                                // 401
        self._unpublishedBuffer.remove(id);                                                           // 402
                                                                                                      // 403
        var maxPublished = self._published.get(self._published.maxElementId());                       // 404
        var maxBuffered = self._unpublishedBuffer.size() && self._unpublishedBuffer.get(self._unpublishedBuffer.maxElementId());
                                                                                                      // 406
        // the buffered doc was updated, it could move to published                                   // 407
        var toPublish = comparator(newDoc, maxPublished) < 0;                                         // 408
                                                                                                      // 409
        // or stays in buffer even after the change                                                   // 410
        var staysInBuffer = (! toPublish && self._safeAppendToBuffer) ||                              // 411
          (!toPublish && maxBuffered && comparator(newDoc, maxBuffered) <= 0);                        // 412
                                                                                                      // 413
        if (toPublish) {                                                                              // 414
          self._addPublished(id, newDoc);                                                             // 415
        } else if (staysInBuffer) {                                                                   // 416
          // stays in buffer but changes                                                              // 417
          self._unpublishedBuffer.set(id, newDoc);                                                    // 418
        } else {                                                                                      // 419
          // Throw away from both published set and buffer                                            // 420
          self._safeAppendToBuffer = false;                                                           // 421
        }                                                                                             // 422
      } else {                                                                                        // 423
        throw new Error("cachedBefore implies either of publishedBefore or bufferedBefore is true."); // 424
      }                                                                                               // 425
    }                                                                                                 // 426
  },                                                                                                  // 427
  _fetchModifiedDocuments: function () {                                                              // 428
    var self = this;                                                                                  // 429
                                                                                                      // 430
    self._registerPhaseChange(PHASE.FETCHING);                                                        // 431
    // Defer, because nothing called from the oplog entry handler may yield, but                      // 432
    // fetch() yields.                                                                                // 433
    Meteor.defer(finishIfNeedToPollQuery(function () {                                                // 434
      while (!self._stopped && !self._needToFetch.empty()) {                                          // 435
        if (self._phase !== PHASE.FETCHING)                                                           // 436
          throw new Error("phase in fetchModifiedDocuments: " + self._phase);                         // 437
                                                                                                      // 438
        self._currentlyFetching = self._needToFetch;                                                  // 439
        var thisGeneration = ++self._fetchGeneration;                                                 // 440
        self._needToFetch = new IdMap; //LocalCollection._IdMap;                                      // 441
        var waiting = 0;                                                                              // 442
        var fut = new Future;                                                                         // 443
        // This loop is safe, because _currentlyFetching will not be updated                          // 444
        // during this loop (in fact, it is never mutated).                                           // 445
        self._currentlyFetching.forEach(function (op, id) {                                           // 446
          waiting++;                                                                                  // 447
//          var collectionName = self._cursorDescription.collectionName;                              // 448
          var collectionName = "redis";                                                               // 449
          var cacheKey = '';                                                                          // 450
                                                                                                      // 451
          var opType = op.message;                                                                    // 452
                                                                                                      // 453
          var getMethodName;                                                                          // 454
          if (_.contains(REDIS_COMMANDS_HASH, opType)) {                                              // 455
            getMethodName = 'hgetall';                                                                // 456
          } else {                                                                                    // 457
            getMethodName = 'get';                                                                    // 458
          }                                                                                           // 459
                                                                                                      // 460
          self._mongoHandle._docFetcher.fetch(                                                        // 461
            collectionName, id, getMethodName, cacheKey,                                              // 462
            finishIfNeedToPollQuery(function (err, doc) {                                             // 463
                                                                                                      // 464
              try {                                                                                   // 465
                if (err) {                                                                            // 466
                  // If we get an error from the fetcher (eg, trouble connecting                      // 467
                  // to Mongo), let's just abandon the fetch phase altogether                         // 468
                  // and fall back to polling. It's not like we're getting live                       // 469
                  // updates anyway.                                                                  // 470
                  if (self._phase !== PHASE.QUERYING) {                                               // 471
                    self._needToPollQuery();                                                          // 472
                  }                                                                                   // 473
                } else if (!self._stopped && self._phase === PHASE.FETCHING                           // 474
                           && self._fetchGeneration === thisGeneration) {                             // 475
                  // We re-check the generation in case we've had an explicit                         // 476
                  // _pollQuery call (eg, in another fiber) which should                              // 477
                  // effectively cancel this round of fetches.  (_pollQuery                           // 478
                  // increments the generation.)                                                      // 479
                  self._handleDoc(id, doc);                                                           // 480
                }                                                                                     // 481
              } finally {                                                                             // 482
                waiting--;                                                                            // 483
                // Because fetch() never calls its callback synchronously, this                       // 484
                // is safe (ie, we won't call fut.return() before the forEach is                      // 485
                // done).                                                                             // 486
                if (waiting === 0)                                                                    // 487
                  fut.return();                                                                       // 488
              }                                                                                       // 489
            }));                                                                                      // 490
        });                                                                                           // 491
        fut.wait();                                                                                   // 492
        // Exit now if we've had a _pollQuery call (here or in another fiber).                        // 493
        if (self._phase === PHASE.QUERYING)                                                           // 494
          return;                                                                                     // 495
        self._currentlyFetching = null;                                                               // 496
      }                                                                                               // 497
      // We're done fetching, so we can be steady, unless we've had a _pollQuery                      // 498
      // call (here or in another fiber).                                                             // 499
      if (self._phase !== PHASE.QUERYING)                                                             // 500
        self._beSteady();                                                                             // 501
    }));                                                                                              // 502
  },                                                                                                  // 503
  _beSteady: function () {                                                                            // 504
    var self = this;                                                                                  // 505
    self._registerPhaseChange(PHASE.STEADY);                                                          // 506
    var writes = self._writesToCommitWhenWeReachSteady;                                               // 507
    self._writesToCommitWhenWeReachSteady = [];                                                       // 508
    self._multiplexer.onFlush(function () {                                                           // 509
      _.each(writes, function (w) {                                                                   // 510
        w.committed();                                                                                // 511
      });                                                                                             // 512
    });                                                                                               // 513
  },                                                                                                  // 514
  _handleOplogEntryQuerying: function (op) {                                                          // 515
    var self = this;                                                                                  // 516
//    self._needToFetch.set(idForOp(op), op.ts.toString());                                           // 517
    // XXX cacheKey                                                                                   // 518
    self._needToFetch.set(op.id, op);                                                                 // 519
  },                                                                                                  // 520
  _handleOplogEntrySteadyOrFetching: function (op) {                                                  // 521
    var self = this;                                                                                  // 522
    //var id = idForOp(op);                                                                           // 523
    var id = op.id;                                                                                   // 524
    // If we're already fetching this one, or about to, we can't optimize; make                       // 525
    // sure that we fetch it again if necessary.                                                      // 526
    if (self._phase === PHASE.FETCHING &&                                                             // 527
        ((self._currentlyFetching && self._currentlyFetching.has(id)) ||                              // 528
         self._needToFetch.has(id))) {                                                                // 529
   // XXX cacheKey                                                                                    // 530
      self._needToFetch.set(id, op);                                                                  // 531
      return;                                                                                         // 532
    }                                                                                                 // 533
                                                                                                      // 534
    var opType = op.message;                                                                          // 535
    if (_.contains(['del', 'expired'], opType)) {                                                     // 536
      if (self._published.has(id)) // || (self._limit && self._unpublishedBuffer.has(id)))            // 537
        self._removeMatching(id);                                                                     // 538
    } else if (_.contains(REDIS_COMMANDS_HASH, opType)                                                // 539
        || opType == 'set' || opType == 'append'                                                      // 540
        || opType == 'incr' || opType == 'incrby' || opType == 'incrbyfloat'                          // 541
        || opType == 'decr' || opType == 'decrby') {                                                  // 542
      self._needToFetch.set(id, op); //op.ts.toString());                                             // 543
      if (self._phase === PHASE.STEADY)                                                               // 544
        self._fetchModifiedDocuments();                                                               // 545
    } else {                                                                                          // 546
      throw Error("XXX UNHANDLED NOTIFICATION TYPE: " + opType);                                      // 547
    }                                                                                                 // 548
//    if (op.op === 'd') {                                                                            // 549
//      if (self._published.has(id) || (self._limit && self._unpublishedBuffer.has(id)))              // 550
//        self._removeMatching(id);                                                                   // 551
//    } else if (op.op === 'i') {                                                                     // 552
//      if (self._published.has(id))                                                                  // 553
//        throw new Error("insert found for already-existing ID in published");                       // 554
//      if (self._unpublishedBuffer && self._unpublishedBuffer.has(id))                               // 555
//        throw new Error("insert found for already-existing ID in buffer");                          // 556
//                                                                                                    // 557
//      // XXX what if selector yields?  for now it can't but later it could have                     // 558
//      // $where                                                                                     // 559
//      if (self._matcher.documentMatches(op.o).result)                                               // 560
//        self._addMatching(op.o);                                                                    // 561
//    } else if (op.op === 'u') {                                                                     // 562
//      // Is this a modifier ($set/$unset, which may require us to poll the                          // 563
//      // database to figure out if the whole document matches the selector) or a                    // 564
//      // replacement (in which case we can just directly re-evaluate the                            // 565
//      // selector)?                                                                                 // 566
//      var isReplace = !_.has(op.o, '$set') && !_.has(op.o, '$unset');                               // 567
//      // If this modifier modifies something inside an EJSON custom type (ie,                       // 568
//      // anything with EJSON$), then we can't try to use                                            // 569
//      // LocalCollection._modify, since that just mutates the EJSON encoding,                       // 570
//      // not the actual object.                                                                     // 571
//      var canDirectlyModifyDoc =                                                                    // 572
//            !isReplace && modifierCanBeDirectlyApplied(op.o);                                       // 573
//                                                                                                    // 574
//      var publishedBefore = self._published.has(id);                                                // 575
//      var bufferedBefore = self._limit && self._unpublishedBuffer.has(id);                          // 576
//                                                                                                    // 577
//      if (isReplace) {                                                                              // 578
//        self._handleDoc(id, _.extend({_id: id}, op.o));                                             // 579
//      } else if ((publishedBefore || bufferedBefore) && canDirectlyModifyDoc) {                     // 580
//        // Oh great, we actually know what the document is, so we can apply                         // 581
//        // this directly.                                                                           // 582
//        var newDoc = self._published.has(id) ?                                                      // 583
//          self._published.get(id) :                                                                 // 584
//          self._unpublishedBuffer.get(id);                                                          // 585
//        newDoc = EJSON.clone(newDoc);                                                               // 586
//                                                                                                    // 587
//        newDoc._id = id;                                                                            // 588
//        LocalCollection._modify(newDoc, op.o);                                                      // 589
//        self._handleDoc(id, newDoc); //self._sharedProjectionFn(newDoc));                           // 590
//      } else if (!canDirectlyModifyDoc ||                                                           // 591
//                 self._matcher.canBecomeTrueByModifier(op.o) ||                                     // 592
//                 (self._sorter && self._sorter.affectedByModifier(op.o))) {                         // 593
//     // XXX cacheKey                                                                                // 594
//        self._needToFetch.set(id, Random.id()); //op.ts.toString());                                // 595
//        if (self._phase === PHASE.STEADY)                                                           // 596
//          self._fetchModifiedDocuments();                                                           // 597
//      }                                                                                             // 598
//    } else {                                                                                        // 599
//      throw Error("XXX SURPRISING OPERATION: " + op);                                               // 600
//    }                                                                                               // 601
  },                                                                                                  // 602
  _runInitialQuery: function () {                                                                     // 603
    var self = this;                                                                                  // 604
    if (self._stopped)                                                                                // 605
      throw new Error("oplog stopped surprisingly early");                                            // 606
                                                                                                      // 607
    self._runQuery();                                                                                 // 608
                                                                                                      // 609
    if (self._stopped)                                                                                // 610
      throw new Error("oplog stopped quite early");                                                   // 611
    // Allow observeChanges calls to return. (After this, it's possible for                           // 612
    // stop() to be called.)                                                                          // 613
    self._multiplexer.ready();                                                                        // 614
                                                                                                      // 615
    try {                                                                                             // 616
    self._doneQuerying();                                                                             // 617
    } catch (e) {                                                                                     // 618
      throw e;                                                                                        // 619
    }                                                                                                 // 620
  },                                                                                                  // 621
                                                                                                      // 622
  // In various circumstances, we may just want to stop processing the oplog and                      // 623
  // re-run the initial query, just as if we were a PollingObserveDriver.                             // 624
  //                                                                                                  // 625
  // This function may not block, because it is called from an oplog entry                            // 626
  // handler.                                                                                         // 627
  //                                                                                                  // 628
  // XXX We should call this when we detect that we've been in FETCHING for "too                      // 629
  // long".                                                                                           // 630
  //                                                                                                  // 631
  // XXX We should call this when we detect Mongo failover (since that might                          // 632
  // mean that some of the oplog entries we have processed have been rolled                           // 633
  // back). The Node Mongo driver is in the middle of a bunch of huge                                 // 634
  // refactorings, including the way that it notifies you when primary                                // 635
  // changes. Will put off implementing this until driver 1.4 is out.                                 // 636
  _pollQuery: function () {                                                                           // 637
    var self = this;                                                                                  // 638
                                                                                                      // 639
                                                                                                      // 640
    if (self._stopped)                                                                                // 641
      return;                                                                                         // 642
                                                                                                      // 643
    // Yay, we get to forget about all the things we thought we had to fetch.                         // 644
    self._needToFetch = new IdMap; //LocalCollection._IdMap;                                          // 645
    self._currentlyFetching = null;                                                                   // 646
    ++self._fetchGeneration;  // ignore any in-flight fetches                                         // 647
    self._registerPhaseChange(PHASE.QUERYING);                                                        // 648
                                                                                                      // 649
    // Defer so that we don't block.  We don't need finishIfNeedToPollQuery here                      // 650
    // because SwitchedToQuery is not called in QUERYING mode.                                        // 651
    Meteor.defer(function () {                                                                        // 652
      self._runQuery();                                                                               // 653
      self._doneQuerying();                                                                           // 654
    });                                                                                               // 655
  },                                                                                                  // 656
                                                                                                      // 657
  _runQuery: function () {                                                                            // 658
    var self = this;                                                                                  // 659
    var newResults, newBuffer;                                                                        // 660
                                                                                                      // 661
    // This while loop is just to retry failures.                                                     // 662
    while (true) {                                                                                    // 663
      // If we've been stopped, we don't have to run anything any more.                               // 664
      if (self._stopped)                                                                              // 665
        return;                                                                                       // 666
                                                                                                      // 667
      newResults = new IdMap; //LocalCollection._IdMap;                                               // 668
      newBuffer = new IdMap; //LocalCollection._IdMap;                                                // 669
                                                                                                      // 670
      // Query 2x documents as the half excluded from the original query will go                      // 671
      // into unpublished buffer to reduce additional Mongo lookups in cases                          // 672
      // when documents are removed from the published set and need a                                 // 673
      // replacement.                                                                                 // 674
      // XXX needs more thought on non-zero skip                                                      // 675
      // XXX 2 is a "magic number" meaning there is an extra chunk of docs for                        // 676
      // buffer if such is needed.                                                                    // 677
                                                                                                      // 678
      var pattern = self._cursorDescription.pattern;                                                  // 679
                                                                                                      // 680
      var client = self._mongoHandle._client;                                                         // 681
                                                                                                      // 682
      try {                                                                                           // 683
        var keysFuture = new Future();                                                                // 684
        client.keys(pattern, keysFuture.resolver());                                                  // 685
        var keys = keysFuture.wait();                                                                 // 686
        var valuesFuture = new Future();                                                              // 687
        client.mget(keys, valuesFuture.resolver());                                                   // 688
        var values = valuesFuture.wait();                                                             // 689
                                                                                                      // 690
        for (var i = 0; i < keys.length; i++) {                                                       // 691
          newResults.set(keys[i], values[i]);                                                         // 692
        }                                                                                             // 693
//      var cursor = self._cursorForQuery({ limit: self._limit * 2 });                                // 694
//      Meteor._debug("Got initial query");                                                           // 695
//      try {                                                                                         // 696
//        cursor.forEach(function (doc, i) {                                                          // 697
//          Meteor._debug("Initial result: " + JSON.stringify(doc) + " @" + i);                       // 698
//          if (!self._limit || i < self._limit)                                                      // 699
//            newResults.set(doc._id, doc);                                                           // 700
//          else                                                                                      // 701
//            newBuffer.set(doc._id, doc);                                                            // 702
//        });                                                                                         // 703
        break;                                                                                        // 704
      } catch (e) {                                                                                   // 705
        // During failover (eg) if we get an exception we should log and retry                        // 706
        // instead of crashing.                                                                       // 707
        Meteor._sleepForMs(100);                                                                      // 708
      }                                                                                               // 709
    }                                                                                                 // 710
                                                                                                      // 711
    self._publishNewResults(newResults, newBuffer);                                                   // 712
  },                                                                                                  // 713
                                                                                                      // 714
  // Transitions to QUERYING and runs another query, or (if already in QUERYING)                      // 715
  // ensures that we will query again later.                                                          // 716
  //                                                                                                  // 717
  // This function may not block, because it is called from an oplog entry                            // 718
  // handler. However, if we were not already in the QUERYING phase, it throws                        // 719
  // an exception that is caught by the closest surrounding                                           // 720
  // finishIfNeedToPollQuery call; this ensures that we don't continue running                        // 721
  // close that was designed for another phase inside PHASE.QUERYING.                                 // 722
  //                                                                                                  // 723
  // (It's also necessary whenever logic in this file yields to check that other                      // 724
  // phases haven't put us into QUERYING mode, though; eg,                                            // 725
  // _fetchModifiedDocuments does this.)                                                              // 726
  _needToPollQuery: function () {                                                                     // 727
    var self = this;                                                                                  // 728
    if (self._stopped)                                                                                // 729
      return;                                                                                         // 730
                                                                                                      // 731
    // If we're not already in the middle of a query, we can query now (possibly                      // 732
    // pausing FETCHING).                                                                             // 733
    if (self._phase !== PHASE.QUERYING) {                                                             // 734
      self._pollQuery();                                                                              // 735
      throw new SwitchedToQuery;                                                                      // 736
    }                                                                                                 // 737
                                                                                                      // 738
    // We're currently in QUERYING. Set a flag to ensure that we run another                          // 739
    // query when we're done.                                                                         // 740
    self._requeryWhenDoneThisQuery = true;                                                            // 741
  },                                                                                                  // 742
                                                                                                      // 743
  _doneQuerying: function () {                                                                        // 744
    var self = this;                                                                                  // 745
                                                                                                      // 746
    if (self._stopped) {                                                                              // 747
      return;                                                                                         // 748
    }                                                                                                 // 749
    self._mongoHandle._oplogHandle.waitUntilCaughtUp();                                               // 750
                                                                                                      // 751
    if (self._stopped) {                                                                              // 752
      return;                                                                                         // 753
    }                                                                                                 // 754
    if (self._phase !== PHASE.QUERYING) {                                                             // 755
      throw Error("Phase unexpectedly " + self._phase);                                               // 756
    }                                                                                                 // 757
                                                                                                      // 758
    if (self._requeryWhenDoneThisQuery) {                                                             // 759
      self._requeryWhenDoneThisQuery = false;                                                         // 760
      self._pollQuery();                                                                              // 761
    } else if (self._needToFetch.empty()) {                                                           // 762
      self._beSteady();                                                                               // 763
    } else {                                                                                          // 764
      self._fetchModifiedDocuments();                                                                 // 765
    }                                                                                                 // 766
  },                                                                                                  // 767
                                                                                                      // 768
  _cursorForQuery: function (optionsOverwrite) {                                                      // 769
    // XXX Remove this ... we don't change the query                                                  // 770
    var self = this;                                                                                  // 771
                                                                                                      // 772
//    // The query we run is almost the same as the cursor we are observing, with                     // 773
//    // a few changes. We need to read all the fields that are relevant to the                       // 774
//    // selector, not just the fields we are going to publish (that's the                            // 775
//    // "shared" projection). And we don't want to apply any transform in the                        // 776
//    // cursor, because observeChanges shouldn't use the transform.                                  // 777
//    var options = _.clone(self._cursorDescription.options);                                         // 778
//                                                                                                    // 779
//    // Allow the caller to modify the options. Useful to specify different skip                     // 780
//    // and limit values.                                                                            // 781
//    _.extend(options, optionsOverwrite);                                                            // 782
//                                                                                                    // 783
//    options.fields = self._sharedProjection;                                                        // 784
//    delete options.transform;                                                                       // 785
    // We are NOT deep cloning fields or selector here, which should be OK.                           // 786
    var description = new CursorDescription(self._cursorDescription.pattern);                         // 787
    return new Cursor(self._mongoHandle, description);                                                // 788
  },                                                                                                  // 789
                                                                                                      // 790
                                                                                                      // 791
  // Replace self._published with newResults (both are IdMaps), invoking observe                      // 792
  // callbacks on the multiplexer.                                                                    // 793
  // Replace self._unpublishedBuffer with newBuffer.                                                  // 794
  //                                                                                                  // 795
  // XXX This is very similar to LocalCollection._diffQueryUnorderedChanges. We                       // 796
  // should really: (a) Unify IdMap and OrderedDict into Unordered/OrderedDict (b)                    // 797
  // Rewrite diff.js to use these classes instead of arrays and objects.                              // 798
  _publishNewResults: function (newResults, newBuffer) {                                              // 799
    var self = this;                                                                                  // 800
                                                                                                      // 801
    // If the query is limited and there is a buffer, shut down so it doesn't                         // 802
    // stay in a way.                                                                                 // 803
    if (self._limit) {                                                                                // 804
      self._unpublishedBuffer.clear();                                                                // 805
    }                                                                                                 // 806
                                                                                                      // 807
    // First remove anything that's gone. Be careful not to modify                                    // 808
    // self._published while iterating over it.                                                       // 809
    var idsToRemove = [];                                                                             // 810
    self._published.forEach(function (doc, id) {                                                      // 811
      if (!newResults.has(id))                                                                        // 812
        idsToRemove.push(id);                                                                         // 813
    });                                                                                               // 814
    _.each(idsToRemove, function (id) {                                                               // 815
      self._removePublished(id);                                                                      // 816
    });                                                                                               // 817
                                                                                                      // 818
    // Now do adds and changes.                                                                       // 819
    // If self has a buffer and limit, the new fetched result will be                                 // 820
    // limited correctly as the query has sort specifier.                                             // 821
    newResults.forEach(function (value, key) {                                                        // 822
      var doc = { _id: key, value: value };                                                           // 823
      self._handleDoc(key, doc);                                                                      // 824
    });                                                                                               // 825
                                                                                                      // 826
    // Sanity-check that everything we tried to put into _published ended up                          // 827
    // there.                                                                                         // 828
    // XXX if this is slow, remove it later                                                           // 829
    if (self._published.size() !== newResults.size()) {                                               // 830
      throw Error("failed to copy newResults into _published!");                                      // 831
    }                                                                                                 // 832
    self._published.forEach(function (doc, id) {                                                      // 833
      if (!newResults.has(id))                                                                        // 834
        throw Error("_published has a doc that newResults doesn't; " + id);                           // 835
    });                                                                                               // 836
                                                                                                      // 837
    // Finally, replace the buffer                                                                    // 838
    newBuffer.forEach(function (doc, id) {                                                            // 839
      self._addBuffered(id, doc);                                                                     // 840
    });                                                                                               // 841
                                                                                                      // 842
    self._safeAppendToBuffer = newBuffer.size() < self._limit;                                        // 843
  },                                                                                                  // 844
                                                                                                      // 845
  // This stop function is invoked from the onStop of the ObserveMultiplexer, so                      // 846
  // it shouldn't actually be possible to call it until the multiplexer is                            // 847
  // ready.                                                                                           // 848
  stop: function () {                                                                                 // 849
    var self = this;                                                                                  // 850
    if (self._stopped)                                                                                // 851
      return;                                                                                         // 852
    self._stopped = true;                                                                             // 853
    _.each(self._stopHandles, function (handle) {                                                     // 854
      handle.stop();                                                                                  // 855
    });                                                                                               // 856
                                                                                                      // 857
    // Note: we *don't* use multiplexer.onFlush here because this stop                                // 858
    // callback is actually invoked by the multiplexer itself when it has                             // 859
    // determined that there are no handles left. So nothing is actually going                        // 860
    // to get flushed (and it's probably not valid to call methods on the                             // 861
    // dying multiplexer).                                                                            // 862
    _.each(self._writesToCommitWhenWeReachSteady, function (w) {                                      // 863
      w.committed();                                                                                  // 864
    });                                                                                               // 865
    self._writesToCommitWhenWeReachSteady = null;                                                     // 866
                                                                                                      // 867
    // Proactively drop references to potentially big things.                                         // 868
    self._published = null;                                                                           // 869
    self._unpublishedBuffer = null;                                                                   // 870
    self._needToFetch = null;                                                                         // 871
    self._currentlyFetching = null;                                                                   // 872
    self._oplogEntryHandle = null;                                                                    // 873
    self._listenersHandle = null;                                                                     // 874
                                                                                                      // 875
    Package.facts && Package.facts.Facts.incrementServerFact(                                         // 876
      "redis-livedata", "observe-drivers-oplog", -1);                                                 // 877
  },                                                                                                  // 878
                                                                                                      // 879
  _registerPhaseChange: function (phase) {                                                            // 880
    var self = this;                                                                                  // 881
    var now = new Date;                                                                               // 882
                                                                                                      // 883
    if (self._phase) {                                                                                // 884
      var timeDiff = now - self._phaseStartTime;                                                      // 885
      Package.facts && Package.facts.Facts.incrementServerFact(                                       // 886
        "redis-livedata", "time-spent-in-" + self._phase + "-phase", timeDiff);                       // 887
    }                                                                                                 // 888
                                                                                                      // 889
    self._phase = phase;                                                                              // 890
    self._phaseStartTime = now;                                                                       // 891
  }                                                                                                   // 892
});                                                                                                   // 893
                                                                                                      // 894
// Does our oplog tailing code support this cursor? For now, we are being very                        // 895
// conservative and allowing only simple queries with simple options.                                 // 896
// (This is a "static method".)                                                                       // 897
KeyspaceNotificationObserveDriver.cursorSupported = function (cursorDescription, matcher) {           // 898
  // XXX everything is supported?                                                                     // 899
  return true;                                                                                        // 900
  // First, check the options.                                                                        // 901
  var options = cursorDescription.options;                                                            // 902
                                                                                                      // 903
  // Did the user say no explicitly?                                                                  // 904
  if (options._disableOplog)                                                                          // 905
    return false;                                                                                     // 906
                                                                                                      // 907
  // skip is not supported: to support it we would need to keep track of all                          // 908
  // "skipped" documents or at least their ids.                                                       // 909
  // limit w/o a sort specifier is not supported: current implementation needs a                      // 910
  // deterministic way to order documents.                                                            // 911
  if (options.skip || (options.limit && !options.sort)) return false;                                 // 912
                                                                                                      // 913
  // If a fields projection option is given check if it is supported by                               // 914
  // minimongo (some operators are not supported).                                                    // 915
  if (options.fields) {                                                                               // 916
    try {                                                                                             // 917
      LocalCollection._checkSupportedProjection(options.fields);                                      // 918
    } catch (e) {                                                                                     // 919
      if (e.name === "MinimongoError")                                                                // 920
        return false;                                                                                 // 921
      else                                                                                            // 922
        throw e;                                                                                      // 923
    }                                                                                                 // 924
  }                                                                                                   // 925
                                                                                                      // 926
  // We don't allow the following selectors:                                                          // 927
  //   - $where (not confident that we provide the same JS environment                                // 928
  //             as Mongo, and can yield!)                                                            // 929
  //   - $near (has "interesting" properties in MongoDB, like the possibility                         // 930
  //            of returning an ID multiple times, though even polling maybe                          // 931
  //            have a bug there)                                                                     // 932
  //           XXX: once we support it, we would need to think more on how we                         // 933
  //           initialize the comparators when we create the driver.                                  // 934
  return !matcher.hasWhere() && !matcher.hasGeoQuery();                                               // 935
};                                                                                                    // 936
                                                                                                      // 937
var modifierCanBeDirectlyApplied = function (modifier) {                                              // 938
  return _.all(modifier, function (fields, operation) {                                               // 939
    return _.all(fields, function (value, field) {                                                    // 940
      return !/EJSON\$/.test(field);                                                                  // 941
    });                                                                                               // 942
  });                                                                                                 // 943
};                                                                                                    // 944
                                                                                                      // 945
RedisInternals.KeyspaceNotificationObserveDriver = KeyspaceNotificationObserveDriver;                 // 946
                                                                                                      // 947
////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// packages/slava:redis-livedata/redis_client.js                                                      //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
/**                                                                                                   // 1
 * Simple wrapper/helpers for the Redis NPM client.  Server only.                                     // 2
 */                                                                                                   // 3
                                                                                                      // 4
var RedisNpm = Npm.require('redis');                                                                  // 5
var UrlNpm = Npm.require('url');                                                                      // 6
                                                                                                      // 7
RedisInternals.NpmModule = RedisNpm;                                                                  // 8
                                                                                                      // 9
RedisClient = function (url, options) {                                                               // 10
  var self = this;                                                                                    // 11
  options = options || {};                                                                            // 12
                                                                                                      // 13
  var parsedUrl = UrlNpm.parse(url);                                                                  // 14
  var host = parsedUrl.hostname || '127.0.0.1';                                                       // 15
  var port = parseInt(parsedUrl.port || '6379');                                                      // 16
                                                                                                      // 17
  if (parsedUrl.auth) {                                                                               // 18
    var auth = parsedUrl.auth;                                                                        // 19
    var colon = auth.indexOf(':');                                                                    // 20
    // Note that redis doesn't use the username!                                                      // 21
    options.auth_pass = auth.substring(colon + 1);                                                    // 22
  }                                                                                                   // 23
                                                                                                      // 24
  self._connection = RedisNpm.createClient(port, host, options);                                      // 25
};                                                                                                    // 26
                                                                                                      // 27
RedisClient.prototype.subscribeKeyspaceEvents = function (callback, listener) {                       // 28
  var self = this;                                                                                    // 29
                                                                                                      // 30
  self._connection.on("pmessage", function (pattern, channel, message) {                              // 31
    var colonIndex = channel.indexOf(":");                                                            // 32
    if (channel.indexOf("__keyspace@") != 0 || colonIndex == 0) {                                     // 33
      Meteor._debug("Unrecognized channel: " + channel);                                              // 34
      return;                                                                                         // 35
    }                                                                                                 // 36
    var key = channel.substr(colonIndex+1);                                                           // 37
    listener(key, message);                                                                           // 38
  });                                                                                                 // 39
  self._connection.psubscribe("__keyspace@*", callback);                                              // 40
};                                                                                                    // 41
                                                                                                      // 42
                                                                                                      // 43
RedisClient.prototype.publish = function (channel, message, callback) {                               // 44
  var self = this;                                                                                    // 45
                                                                                                      // 46
  self._connection.publish(channel, message, Meteor.bindEnvironment(callback));                       // 47
};                                                                                                    // 48
                                                                                                      // 49
RedisClient.prototype.findCandidateKeys = function (collectionName, matcher, callback) {              // 50
  var self = this;                                                                                    // 51
                                                                                                      // 52
  // Special case the single-document matcher                                                         // 53
  // {"_paths":{"_id":true},"_hasGeoQuery":false,"_hasWhere":false,"_isSimple":true,"_selector":{"_id":"XhjyfgEbYyoYTiABX"}}
  var simpleKeys = null;                                                                              // 55
  if (!matcher._hasGeoQuery && !matcher._hasWhere && matcher._isSimple) {                             // 56
    var keys = _.keys(matcher._selector);                                                             // 57
    if (keys.length == 1 && keys[0] === "_id") {                                                      // 58
      var selectorId = matcher._selector._id;                                                         // 59
      if (typeof selectorId === 'string') {                                                           // 60
        simpleKeys = [collectionName + "//" + selectorId];                                            // 61
      }                                                                                               // 62
    }                                                                                                 // 63
  }                                                                                                   // 64
                                                                                                      // 65
  if (simpleKeys === null) {                                                                          // 66
    self._connection.keys(collectionName + "//*", Meteor.bindEnvironment(callback));                  // 67
  } else {                                                                                            // 68
    callback(null, simpleKeys);                                                                       // 69
  }                                                                                                   // 70
};                                                                                                    // 71
                                                                                                      // 72
RedisClient.prototype.keys = function (pattern, callback) {                                           // 73
  var self = this;                                                                                    // 74
                                                                                                      // 75
  self._connection.keys(pattern, Meteor.bindEnvironment(callback));                                   // 76
};                                                                                                    // 77
                                                                                                      // 78
RedisClient.prototype.flushall = function (callback) {                                                // 79
  var self = this;                                                                                    // 80
                                                                                                      // 81
  self._connection.flushall(Meteor.bindEnvironment(callback));                                        // 82
};                                                                                                    // 83
                                                                                                      // 84
RedisClient.prototype.setex = function (key, expiration, value, callback) {                           // 85
  var self = this;                                                                                    // 86
  self._connection.setex(key, expiration, value, Meteor.bindEnvironment(callback));                   // 87
};                                                                                                    // 88
                                                                                                      // 89
RedisClient.prototype.mget = function (keys, callback) {                                              // 90
  var self = this;                                                                                    // 91
                                                                                                      // 92
  if (!keys.length) {                                                                                 // 93
    // mget is fussy about empty keys array                                                           // 94
    callback(null, []);                                                                               // 95
    return;                                                                                           // 96
  }                                                                                                   // 97
                                                                                                      // 98
  // XXX Strip any null values from results?                                                          // 99
  self._connection.mget(keys, Meteor.bindEnvironment(callback));                                      // 100
};                                                                                                    // 101
                                                                                                      // 102
RedisClient.prototype.matching = function (pattern, callback) {                                       // 103
  var self = this;                                                                                    // 104
                                                                                                      // 105
  self._connection.keys(pattern, Meteor.bindEnvironment(function (err, result) {                      // 106
    if (err) {                                                                                        // 107
      Meteor._debug("Error listing keys: " + err);                                                    // 108
      callback(err, null);                                                                            // 109
    } else {                                                                                          // 110
      self.mget(result, callback);                                                                    // 111
    }                                                                                                 // 112
  }));                                                                                                // 113
};                                                                                                    // 114
                                                                                                      // 115
_.each(REDIS_COMMANDS_HASH, function (method) {                                                       // 116
  RedisClient.prototype[method] = function (/* arguments */) {                                        // 117
    var self = this;                                                                                  // 118
    var args = _.toArray(arguments);                                                                  // 119
    var cb = args.pop();                                                                              // 120
                                                                                                      // 121
    if (_.isFunction(cb)) {                                                                           // 122
      args.push(Meteor.bindEnvironment(function (err, result) {                                       // 123
        // Mongo returns undefined here, our Redis binding returns null                               // 124
        // XXX remove this when we change our mind back to null.                                      // 125
        if (result === null) {                                                                        // 126
          result = undefined;                                                                         // 127
        }                                                                                             // 128
        // sometimes the result is a vector of values (like multiple hmget)                           // 129
        if (_.isArray(result)) {                                                                      // 130
          result = _.map(result, function (value) {                                                   // 131
            return value === null ? undefined : value;                                                // 132
          });                                                                                         // 133
        }                                                                                             // 134
        cb(err, result);                                                                              // 135
      }));                                                                                            // 136
    } else {                                                                                          // 137
      args.push(cb);                                                                                  // 138
    }                                                                                                 // 139
                                                                                                      // 140
    var ret = self._connection[method].apply(self._connection, args);                                 // 141
    // Replace null with undefined as redis npm client likes to return null                           // 142
    // when the value is absent. To be consistent with other behavior we                              // 143
    // prefer undefined as absence of value.                                                          // 144
    // XXX remove this when we change our mind back to null.                                          // 145
    return ret === null ? undefined : ret;                                                            // 146
  };                                                                                                  // 147
});                                                                                                   // 148
                                                                                                      // 149
// XXX: Remove (in favor of default implementation?)                                                  // 150
RedisClient.prototype.hgetall = function (key, callback) {                                            // 151
  var self = this;                                                                                    // 152
                                                                                                      // 153
  self._connection.hgetall(key, Meteor.bindEnvironment(function (err, result) {                       // 154
    // Mongo returns undefined here, our Redis binding returns null                                   // 155
    if (result === null) {                                                                            // 156
      result = undefined;                                                                             // 157
    }                                                                                                 // 158
    callback(err, result);                                                                            // 159
  }));                                                                                                // 160
};                                                                                                    // 161
                                                                                                      // 162
RedisClient.prototype.del = function (keys, callback) {                                               // 163
  var self = this;                                                                                    // 164
                                                                                                      // 165
  self._connection.del(keys, Meteor.bindEnvironment(callback));                                       // 166
};                                                                                                    // 167
                                                                                                      // 168
RedisClient.prototype.get = function (key, callback) {                                                // 169
  var self = this;                                                                                    // 170
                                                                                                      // 171
  self._connection.get(key, Meteor.bindEnvironment(function (err, res) {                              // 172
    // Mongo returns undefined here, our Redis binding returns null                                   // 173
    if (res === null)                                                                                 // 174
      res = undefined;                                                                                // 175
    callback(err, res);                                                                               // 176
  }));                                                                                                // 177
};                                                                                                    // 178
                                                                                                      // 179
RedisClient.prototype.set = function (key, value, callback) {                                         // 180
  var self = this;                                                                                    // 181
                                                                                                      // 182
  self._connection.set(key, value, Meteor.bindEnvironment(callback));                                 // 183
};                                                                                                    // 184
                                                                                                      // 185
RedisClient.prototype.getConfig = function (key, callback) {                                          // 186
  var self = this;                                                                                    // 187
                                                                                                      // 188
  self._connection.config('get', key, Meteor.bindEnvironment(callback));                              // 189
};                                                                                                    // 190
                                                                                                      // 191
RedisClient.prototype.setConfig = function (key, value, callback) {                                   // 192
  var self = this;                                                                                    // 193
                                                                                                      // 194
  self._connection.config('set', key, value, Meteor.bindEnvironment(callback));                       // 195
};                                                                                                    // 196
                                                                                                      // 197
RedisClient.prototype.incr = function (key, callback) {                                               // 198
  var self = this;                                                                                    // 199
                                                                                                      // 200
  self._connection.incr(key, Meteor.bindEnvironment(callback));                                       // 201
};                                                                                                    // 202
                                                                                                      // 203
RedisClient.prototype.incrby = function (key, delta, callback) {                                      // 204
  var self = this;                                                                                    // 205
                                                                                                      // 206
  self._connection.incrby(key, delta, Meteor.bindEnvironment(callback));                              // 207
};                                                                                                    // 208
                                                                                                      // 209
RedisClient.prototype.incrbyfloat = function (key, delta, callback) {                                 // 210
  var self = this;                                                                                    // 211
                                                                                                      // 212
  self._connection.incrbyfloat(key, delta, Meteor.bindEnvironment(callback));                         // 213
};                                                                                                    // 214
                                                                                                      // 215
RedisClient.prototype.decr = function (key, callback) {                                               // 216
  var self = this;                                                                                    // 217
                                                                                                      // 218
  self._connection.decr(key, Meteor.bindEnvironment(callback));                                       // 219
};                                                                                                    // 220
                                                                                                      // 221
RedisClient.prototype.decrby = function (key, delta, callback) {                                      // 222
  var self = this;                                                                                    // 223
                                                                                                      // 224
  self._connection.decrby(key, delta, Meteor.bindEnvironment(callback));                              // 225
};                                                                                                    // 226
                                                                                                      // 227
RedisClient.prototype.append = function (key, suffix, callback) {                                     // 228
  var self = this;                                                                                    // 229
                                                                                                      // 230
  self._connection.append(key, suffix, Meteor.bindEnvironment(callback));                             // 231
};                                                                                                    // 232
                                                                                                      // 233
RedisClient.prototype.getAll = function (keys, callback) {                                            // 234
  var self = this;                                                                                    // 235
                                                                                                      // 236
  var connection = self._connection;                                                                  // 237
                                                                                                      // 238
  var errors = [];                                                                                    // 239
  var values = [];                                                                                    // 240
  var replyCount = 0;                                                                                 // 241
                                                                                                      // 242
  var n = keys.length;                                                                                // 243
                                                                                                      // 244
  if (n == 0) {                                                                                       // 245
    callback(errors, values);                                                                         // 246
    return;                                                                                           // 247
  }                                                                                                   // 248
                                                                                                      // 249
  _.each(_.range(n), function(i) {                                                                    // 250
    var key = keys[i];                                                                                // 251
    connection.get(key, Meteor.bindEnvironment(function(err, value) {                                 // 252
      if (err) {                                                                                      // 253
        Meteor._debug("Error getting key from redis: " + err);                                        // 254
      }                                                                                               // 255
      errors[i] = err;                                                                                // 256
      values[i] = value;                                                                              // 257
                                                                                                      // 258
      replyCount++;                                                                                   // 259
      if (replyCount == n) {                                                                          // 260
        callback(errors, values);                                                                     // 261
      }                                                                                               // 262
    }));                                                                                              // 263
  });                                                                                                 // 264
};                                                                                                    // 265
                                                                                                      // 266
RedisClient.prototype.setAll = function (keys, values, callback) {                                    // 267
  var self = this;                                                                                    // 268
                                                                                                      // 269
  var connection = self._connection;                                                                  // 270
                                                                                                      // 271
  var errors = [];                                                                                    // 272
  var results = [];                                                                                   // 273
                                                                                                      // 274
  var n = keys.length;                                                                                // 275
  if (n == 0) {                                                                                       // 276
    callback(errors, results);                                                                        // 277
    return;                                                                                           // 278
  }                                                                                                   // 279
                                                                                                      // 280
  var replyCount = 0;                                                                                 // 281
  _.each(_.range(n), function(i) {                                                                    // 282
    var key = keys[i];                                                                                // 283
    var value = values[i];                                                                            // 284
                                                                                                      // 285
    connection.set(key, value, Meteor.bindEnvironment(function(err, result) {                         // 286
      if (err) {                                                                                      // 287
        Meteor._debug("Error setting value in redis: " + err);                                        // 288
      }                                                                                               // 289
      errors[i] = err;                                                                                // 290
      results[i] = result;                                                                            // 291
                                                                                                      // 292
      replyCount++;                                                                                   // 293
      if (replyCount == n) {                                                                          // 294
        callback(errors, results);                                                                    // 295
      }                                                                                               // 296
    }));                                                                                              // 297
  });                                                                                                 // 298
};                                                                                                    // 299
                                                                                                      // 300
                                                                                                      // 301
RedisClient.prototype.removeAll = function (keys, callback) {                                         // 302
  var self = this;                                                                                    // 303
                                                                                                      // 304
  var connection = self._connection;                                                                  // 305
                                                                                                      // 306
  var errors = [];                                                                                    // 307
  var results = [];                                                                                   // 308
                                                                                                      // 309
  var n = keys.length;                                                                                // 310
  if (n == 0) {                                                                                       // 311
    callback(errors, results);                                                                        // 312
    return;                                                                                           // 313
  }                                                                                                   // 314
                                                                                                      // 315
  var replyCount = 0;                                                                                 // 316
  _.each(_.range(n), function(i) {                                                                    // 317
    var key = keys[i];                                                                                // 318
    connection.del(key, Meteor.bindEnvironment(function(err, result) {                                // 319
      if (err) {                                                                                      // 320
        Meteor._debug("Error deleting key in redis: " + err);                                         // 321
      }                                                                                               // 322
      errors[i] = err;                                                                                // 323
      results[i] = result;                                                                            // 324
                                                                                                      // 325
      replyCount++;                                                                                   // 326
      if (replyCount == n) {                                                                          // 327
        callback(errors, results);                                                                    // 328
      }                                                                                               // 329
    }));                                                                                              // 330
  });                                                                                                 // 331
};                                                                                                    // 332
                                                                                                      // 333
                                                                                                      // 334
                                                                                                      // 335
////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// packages/slava:redis-livedata/redis_watcher.js                                                     //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
var path = Npm.require('path');                                                                       // 1
var Future = Npm.require(path.join('fibers', 'future'));                                              // 2
                                                                                                      // 3
RedisWatcher = function (url) {                                                                       // 4
  var self = this;                                                                                    // 5
  self._url = url;                                                                                    // 6
                                                                                                      // 7
  self._watchConnection = null;                                                                       // 8
  self._stopped = false;                                                                              // 9
  self._readyFuture = new Future();                                                                   // 10
  self._listeners = [];                                                                               // 11
  self._start();                                                                                      // 12
};                                                                                                    // 13
                                                                                                      // 14
_.extend(RedisWatcher.prototype, {                                                                    // 15
  stop: function () {                                                                                 // 16
    var self = this;                                                                                  // 17
    if (self._stopped)                                                                                // 18
      return;                                                                                         // 19
    self._stopped = true;                                                                             // 20
    // XXX should close connections too                                                               // 21
  },                                                                                                  // 22
  addListener: function (listener) {                                                                  // 23
    var self = this;                                                                                  // 24
    self._listeners.push(listener);                                                                   // 25
  },                                                                                                  // 26
  removeListener: function (listener) {                                                               // 27
    var self = this;                                                                                  // 28
    self._listeners = _.without(self._listeners, listener);                                           // 29
  },                                                                                                  // 30
  _start: function () {                                                                               // 31
    var self = this;                                                                                  // 32
    self._watchConnection = new RedisClient(self._url);                                               // 33
                                                                                                      // 34
    var listener = function (key, message) {                                                          // 35
      _.each(self._listeners, function (listener) {                                                   // 36
        listener(key, message);                                                                       // 37
      });                                                                                             // 38
    };                                                                                                // 39
                                                                                                      // 40
    self._watchConnection.subscribeKeyspaceEvents(function (err, results) {                           // 41
      if (err != null) {                                                                              // 42
        Meteor._debug("Error subscribing to redis changes: " + JSON.stringify(err));                  // 43
        self._readyFuture.throw(new Error("Error subscribing to redis changes"));                     // 44
      } else {                                                                                        // 45
        self._readyFuture.return();                                                                   // 46
      }                                                                                               // 47
    }, listener);                                                                                     // 48
  }                                                                                                   // 49
});                                                                                                   // 50
////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// packages/slava:redis-livedata/local_collection_driver.js                                           //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
LocalCollectionDriver = function () {                                                                 // 1
  var self = this;                                                                                    // 2
  self.noConnCollections = {};                                                                        // 3
  self.noConnStore = null;                                                                            // 4
};                                                                                                    // 5
                                                                                                      // 6
var ensureCollection = function (store, name, collections) {                                          // 7
  if (!(name in collections))                                                                         // 8
    collections[name] = new Miniredis.RedisStore(name);                                               // 9
  return collections[name];                                                                           // 10
};                                                                                                    // 11
                                                                                                      // 12
_.extend(LocalCollectionDriver.prototype, {                                                           // 13
  open: function (name, conn) {                                                                       // 14
    var self = this;                                                                                  // 15
                                                                                                      // 16
    var store;                                                                                        // 17
    if (conn) {                                                                                       // 18
      store = conn._redis_store;                                                                      // 19
      if (!store) {                                                                                   // 20
        store = conn._redis_store = new Miniredis.RedisStore(name);                                   // 21
      }                                                                                               // 22
    } else {                                                                                          // 23
      store = self.noConnStore;                                                                       // 24
      if (!store) {                                                                                   // 25
        store = self.noConnStore = new Miniredis.RedisStore(name);                                    // 26
      }                                                                                               // 27
    }                                                                                                 // 28
    if (! conn) {                                                                                     // 29
      return ensureCollection(store, name, self.noConnCollections);                                   // 30
    }                                                                                                 // 31
    // XXX Redis doesn't have the concept of collections so for now the only                          // 32
    // possible collection name is "redis"                                                            // 33
    if (name !== "redis" && name !== null) {                                                          // 34
      throw new Error("The only valid RedisCollection name is 'redis'");                              // 35
    }                                                                                                 // 36
    if (! conn._redis_livedata_collections)                                                           // 37
      conn._redis_livedata_collections = {};                                                          // 38
    // XXX is there a way to keep track of a connection's collections without                         // 39
    // dangling it off the connection object?                                                         // 40
    return ensureCollection(store, name, conn._redis_livedata_collections);                           // 41
  }                                                                                                   // 42
});                                                                                                   // 43
                                                                                                      // 44
// singleton                                                                                          // 45
LocalCollectionDriver = new LocalCollectionDriver;                                                    // 46
                                                                                                      // 47
////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// packages/slava:redis-livedata/remote_collection_driver.js                                          //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
var path = Npm.require('path');                                                                       // 1
var Future = Npm.require(path.join('fibers', 'future'));                                              // 2
                                                                                                      // 3
RedisInternals.RemoteCollectionDriver = function (                                                    // 4
  url, options) {                                                                                     // 5
  var self = this;                                                                                    // 6
  self.connection = new RedisConnection(url, options);                                                // 7
};                                                                                                    // 8
                                                                                                      // 9
_.extend(RedisInternals.RemoteCollectionDriver.prototype, {                                           // 10
  open: function (name) {                                                                             // 11
    var self = this;                                                                                  // 12
    var ret = {};                                                                                     // 13
    _.each(                                                                                           // 14
      ['find', 'findOne', 'insert', 'update', , 'upsert',                                             // 15
       'remove', '_ensureIndex', '_dropIndex', '_createCappedCollection',                             // 16
       'dropCollection'],                                                                             // 17
      function (m) {                                                                                  // 18
        ret[m] = function () {                                                                        // 19
          throw new Error(m + ' is not available on REDIS! XXX');                                     // 20
        };                                                                                            // 21
      });                                                                                             // 22
      _.each(['keys', 'matching', 'get',                                                              // 23
              'set', 'setex', 'append', 'del',                                                        // 24
              'incr', 'incrby', 'incrbyfloat', 'decr', 'decrby',                                      // 25
              '_observe', 'flushall'].concat(REDIS_COMMANDS_HASH),                                    // 26
        function (m) {                                                                                // 27
          ret[m] = function (/* args */) {                                                            // 28
            var args = _.toArray(arguments);                                                          // 29
            var cb = args.pop();                                                                      // 30
                                                                                                      // 31
            if (_.isFunction(cb)) {                                                                   // 32
              args.push(function (err, res) {                                                         // 33
                // In Meteor the first argument (error) passed to the                                 // 34
                // callback is undefined if no error occurred.                                        // 35
                if (err === null) err = undefined;                                                    // 36
                cb(err, res);                                                                         // 37
              });                                                                                     // 38
            } else {                                                                                  // 39
              args.push(cb);                                                                          // 40
            }                                                                                         // 41
                                                                                                      // 42
            // XXX 'matching' method is a special case, because it returns a                          // 43
            // cursor and cursors need to know what collection they belong to.                        // 44
            if (m === 'matching') {                                                                   // 45
              args = [name].concat(args);                                                             // 46
            }                                                                                         // 47
                                                                                                      // 48
            return self.connection[m].apply(self.connection, args);                                   // 49
          };                                                                                          // 50
        });                                                                                           // 51
    return ret;                                                                                       // 52
  }                                                                                                   // 53
});                                                                                                   // 54
                                                                                                      // 55
// A version of _.once that behaves sensibly under exceptions                                         // 56
// If the first call is an exception:                                                                 // 57
//  _.once will return undefined on subsequent calls                                                  // 58
//  meteorOnce will rethrow the exception every time                                                  // 59
meteorOnce = function(f) {                                                                            // 60
  var resultFuture = null;                                                                            // 61
  return function () {                                                                                // 62
    if (!resultFuture) {                                                                              // 63
      resultFuture = new Future;                                                                      // 64
      try {                                                                                           // 65
        var v = f.apply(this, arguments);                                                             // 66
        resultFuture.return(v);                                                                       // 67
      } catch (e) {                                                                                   // 68
        resultFuture.throw(e);                                                                        // 69
      }                                                                                               // 70
    }                                                                                                 // 71
    return resultFuture.wait();                                                                       // 72
  };                                                                                                  // 73
};                                                                                                    // 74
                                                                                                      // 75
// Create the singleton RemoteCollectionDriver only on demand, so we                                  // 76
// only require Mongo configuration if it's actually used (eg, not if                                 // 77
// you're only trying to receive data from a remote DDP server.)                                      // 78
RedisInternals.defaultRemoteCollectionDriver = meteorOnce(function () {                               // 79
  var redisUrl = process.env.REDIS_URL;                                                               // 80
  if (!redisUrl) {                                                                                    // 81
    redisUrl = Meteor.settings.redisUrl;                                                              // 82
  }                                                                                                   // 83
  if (!redisUrl) {                                                                                    // 84
    redisUrl = 'redis://127.0.0.1:6379';                                                              // 85
    Meteor._debug("Defaulting REDIS_URL to " + redisUrl);                                             // 86
  }                                                                                                   // 87
                                                                                                      // 88
  var connectionOptions = {};                                                                         // 89
  var configureKeyspaceNotifications = process.env.REDIS_CONFIGURE_KEYSPACE_NOTIFICATIONS;            // 90
  if (!configureKeyspaceNotifications) {                                                              // 91
    configureKeyspaceNotifications = Meteor.settings.redisConfigureKeyspaceNotifications;             // 92
  }                                                                                                   // 93
  if (configureKeyspaceNotifications) {                                                               // 94
    connectionOptions.configureKeyspaceNotifications = configureKeyspaceNotifications;                // 95
  }                                                                                                   // 96
                                                                                                      // 97
  return new RedisInternals.RemoteCollectionDriver(redisUrl, connectionOptions);                      // 98
});                                                                                                   // 99
                                                                                                      // 100
////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// packages/slava:redis-livedata/redis_collection.js                                                  //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
RedisSingletons = new SynchronousMap();                                                               // 1
                                                                                                      // 2
// options.connection, if given, is a LivedataClient or LivedataServer                                // 3
// XXX presently there is no way to destroy/clean up a Collection                                     // 4
Meteor.RedisCollection = function (name, options) {                                                   // 5
  var self = this;                                                                                    // 6
  if (! (self instanceof Meteor.RedisCollection))                                                     // 7
    throw new Error('use "new" to construct a Meteor.RedisCollection');                               // 8
                                                                                                      // 9
  if (!name && (name !== null)) {                                                                     // 10
    Meteor._debug("Warning: creating anonymous collection. It will not be " +                         // 11
                  "saved or synchronized over the network. (Pass null for " +                         // 12
                  "the collection name to turn off this warning.)");                                  // 13
    name = null;                                                                                      // 14
  }                                                                                                   // 15
                                                                                                      // 16
  if (name !== null && typeof name !== "string") {                                                    // 17
    throw new Error(                                                                                  // 18
      "First argument to new Meteor.RedisCollection must be a string or null");                       // 19
  }                                                                                                   // 20
                                                                                                      // 21
  if (name !== null) {                                                                                // 22
    return RedisSingletons.get([name], function () {                                                  // 23
      self._factory(name, options);                                                                   // 24
      return self;                                                                                    // 25
    });                                                                                               // 26
  } else {                                                                                            // 27
    self._factory();                                                                                  // 28
    return self;                                                                                      // 29
  }                                                                                                   // 30
};                                                                                                    // 31
                                                                                                      // 32
Meteor.RedisCollection.prototype._factory = function (name, options) {                                // 33
  var self = this;                                                                                    // 34
                                                                                                      // 35
  options = _.extend({                                                                                // 36
    connection: undefined,                                                                            // 37
//    idGeneration: 'STRING',                                                                         // 38
//    transform: null,                                                                                // 39
    _driver: undefined,                                                                               // 40
    _preventAutopublish: false                                                                        // 41
  }, options);                                                                                        // 42
                                                                                                      // 43
//  switch (options.idGeneration) {                                                                   // 44
//  case 'MONGO':                                                                                     // 45
//    self._makeNewID = function () {                                                                 // 46
//      var src = name ? DDP.randomStream('/collection/' + name) : Random;                            // 47
//      return new Meteor.RedisCollection.ObjectID(src.hexString(24));                                // 48
//    };                                                                                              // 49
//    break;                                                                                          // 50
//  case 'STRING':                                                                                    // 51
//  default:                                                                                          // 52
    self._makeNewID = function () {                                                                   // 53
      var src = name ? DDP.randomStream('/collection/' + name) : Random;                              // 54
      return src.id();                                                                                // 55
    };                                                                                                // 56
//    break;                                                                                          // 57
//  }                                                                                                 // 58
                                                                                                      // 59
//  if (options.transform) {                                                                          // 60
//    throw Exception("transform not supported for redis");                                           // 61
//    //self._transform = LocalCollection.wrapTransform(options.transform);                           // 62
//  } else {                                                                                          // 63
//    self._transform = null;                                                                         // 64
//  }                                                                                                 // 65
                                                                                                      // 66
  if (! name || options.connection === null)                                                          // 67
    // note: nameless collections never have a connection                                             // 68
    self._connection = null;                                                                          // 69
  else if (options.connection)                                                                        // 70
    self._connection = options.connection;                                                            // 71
  else if (Meteor.isClient)                                                                           // 72
    self._connection = Meteor.connection;                                                             // 73
  else                                                                                                // 74
    self._connection = Meteor.server;                                                                 // 75
                                                                                                      // 76
  if (!options._driver) {                                                                             // 77
    if (name && self._connection === Meteor.server &&                                                 // 78
        typeof RedisInternals !== "undefined" &&                                                      // 79
        RedisInternals.defaultRemoteCollectionDriver) {                                               // 80
      options._driver = RedisInternals.defaultRemoteCollectionDriver();                               // 81
    } else {                                                                                          // 82
      options._driver = LocalCollectionDriver;                                                        // 83
    }                                                                                                 // 84
  }                                                                                                   // 85
                                                                                                      // 86
  self._collection = options._driver.open(name, self._connection);                                    // 87
  self._name = name || "";                                                                            // 88
                                                                                                      // 89
  if (self._connection && self._connection.registerStore) {                                           // 90
    // OK, we're going to be a slave, replicating some remote                                         // 91
    // database, except possibly with some temporary divergence while                                 // 92
    // we have unacknowledged RPC's.                                                                  // 93
    var ok = self._connection.registerStore(name, {                                                   // 94
      // Called at the beginning of a batch of updates. batchSize is the number                       // 95
      // of update calls to expect.                                                                   // 96
      beginUpdate: function (batchSize, reset) {                                                      // 97
        if (batchSize > 1 || reset) {                                                                 // 98
          self._collection.pauseObservers();                                                          // 99
        }                                                                                             // 100
                                                                                                      // 101
        if (reset)                                                                                    // 102
          self._collection._drop();                                                                   // 103
      },                                                                                              // 104
                                                                                                      // 105
      // Apply an update.                                                                             // 106
      // XXX better specify this interface (not in terms of a wire message)?                          // 107
      update: function (msg) {                                                                        // 108
        var key = msg.id;                                                                             // 109
        var doc = self._collection._get(key);                                                         // 110
                                                                                                      // 111
        // Is this a "replace the whole doc" message coming from the quiescence                       // 112
        // of method writes to an object? (Note that 'undefined' is a valid                           // 113
        // value meaning "remove it".)                                                                // 114
        if (msg.msg === 'replace') {                                                                  // 115
          var replace = msg.replace;                                                                  // 116
          if (!replace) {                                                                             // 117
            if (doc)                                                                                  // 118
              self._collection._remove(key);                                                          // 119
          } else {                                                                                    // 120
            self._collection._set(key, replace.value);                                                // 121
          }                                                                                           // 122
        } else if (msg.msg === 'added') {                                                             // 123
          if (doc) {                                                                                  // 124
            throw new Error("Expected not to find a document already present for an add");            // 125
          }                                                                                           // 126
          self._collection._set(key, msg.fields.value);                                               // 127
        } else if (msg.msg === 'removed') {                                                           // 128
          if (!doc)                                                                                   // 129
            throw new Error("Expected to find a document already present for removed");               // 130
          self._collection._remove(key);                                                              // 131
        } else if (msg.msg === 'changed') {                                                           // 132
          if (!doc)                                                                                   // 133
            throw new Error("Expected to find a document to change");                                 // 134
          if (!_.isEmpty(msg.fields)) {                                                               // 135
            self._collection._set(key, msg.fields.value);                                             // 136
          }                                                                                           // 137
        } else {                                                                                      // 138
          throw new Error("I don't know how to deal with this message");                              // 139
        }                                                                                             // 140
                                                                                                      // 141
      },                                                                                              // 142
                                                                                                      // 143
      // Called at the end of a batch of updates.                                                     // 144
      endUpdate: function () {                                                                        // 145
        self._collection.resumeObservers();                                                           // 146
      },                                                                                              // 147
                                                                                                      // 148
      // Called around method stub invocations to capture the original versions                       // 149
      // of modified documents.                                                                       // 150
      saveOriginals: function () {                                                                    // 151
        self._collection.saveOriginals();                                                             // 152
      },                                                                                              // 153
      retrieveOriginals: function () {                                                                // 154
        return self._collection.retrieveOriginals();                                                  // 155
      }                                                                                               // 156
    });                                                                                               // 157
                                                                                                      // 158
    if (!ok)                                                                                          // 159
      throw new Error("There is already a collection named '" + name + "'");                          // 160
  }                                                                                                   // 161
                                                                                                      // 162
  self._defineMutationMethods();                                                                      // 163
                                                                                                      // 164
  // autopublish                                                                                      // 165
  if (Package.autopublish && !options._preventAutopublish && self._connection                         // 166
      && self._connection.publish) {                                                                  // 167
    self._connection.publish(null, function () {                                                      // 168
      return self.matching('*');                                                                      // 169
    }, {is_auto: true});                                                                              // 170
  }                                                                                                   // 171
};                                                                                                    // 172
                                                                                                      // 173
///                                                                                                   // 174
/// Main collection API                                                                               // 175
///                                                                                                   // 176
                                                                                                      // 177
                                                                                                      // 178
_.extend(Meteor.RedisCollection.prototype, {                                                          // 179
                                                                                                      // 180
  _getFindSelector: function (args) {                                                                 // 181
    if (args.length == 0)                                                                             // 182
      return {};                                                                                      // 183
    else                                                                                              // 184
      return args[0];                                                                                 // 185
  },                                                                                                  // 186
                                                                                                      // 187
  _getFindOptions: function (args) {                                                                  // 188
    var self = this;                                                                                  // 189
    if (args.length < 2) {                                                                            // 190
      return { transform: self._transform };                                                          // 191
    } else {                                                                                          // 192
      check(args[1], Match.Optional(Match.ObjectIncluding({                                           // 193
        fields: Match.Optional(Match.OneOf(Object, undefined)),                                       // 194
        sort: Match.Optional(Match.OneOf(Object, Array, undefined)),                                  // 195
        limit: Match.Optional(Match.OneOf(Number, undefined)),                                        // 196
        skip: Match.Optional(Match.OneOf(Number, undefined))                                          // 197
     })));                                                                                            // 198
                                                                                                      // 199
      return _.extend({                                                                               // 200
        transform: self._transform                                                                    // 201
      }, args[1]);                                                                                    // 202
    }                                                                                                 // 203
  },                                                                                                  // 204
                                                                                                      // 205
  find: function (/* selector, options */) {                                                          // 206
    // Collection.find() (return all docs) behaves differently                                        // 207
    // from Collection.find(undefined) (return 0 docs).  so be                                        // 208
    // careful about the length of arguments.                                                         // 209
    var self = this;                                                                                  // 210
    var argArray = _.toArray(arguments);                                                              // 211
    return self._collection.find(self._getFindSelector(argArray),                                     // 212
                                 self._getFindOptions(argArray));                                     // 213
  },                                                                                                  // 214
                                                                                                      // 215
  findOne: function (/* selector, options */) {                                                       // 216
    var self = this;                                                                                  // 217
    var argArray = _.toArray(arguments);                                                              // 218
    return self._collection.findOne(self._getFindSelector(argArray),                                  // 219
                                    self._getFindOptions(argArray));                                  // 220
  },                                                                                                  // 221
                                                                                                      // 222
  observe: function (observer) {                                                                      // 223
    var self = this;                                                                                  // 224
    return self._collection.observe(observer);                                                        // 225
  }                                                                                                   // 226
                                                                                                      // 227
});                                                                                                   // 228
                                                                                                      // 229
Meteor.RedisCollection._publishCursor = function (cursor, sub, collection) {                          // 230
  var observeHandle = cursor.observeChanges({                                                         // 231
    added: function (id, fields) {                                                                    // 232
      sub.added(collection, id, fields);                                                              // 233
    },                                                                                                // 234
    changed: function (id, fields) {                                                                  // 235
      sub.changed(collection, id, fields);                                                            // 236
    },                                                                                                // 237
    removed: function (id) {                                                                          // 238
      sub.removed(collection, id);                                                                    // 239
    }                                                                                                 // 240
  });                                                                                                 // 241
                                                                                                      // 242
  // We don't call sub.ready() here: it gets called in livedata_server, after                         // 243
  // possibly calling _publishCursor on multiple returned cursors.                                    // 244
                                                                                                      // 245
  // register stop callback (expects lambda w/ no args).                                              // 246
  sub.onStop(function () {observeHandle.stop();});                                                    // 247
};                                                                                                    // 248
                                                                                                      // 249
// protect against dangerous selectors.  falsey and {_id: falsey} are both                            // 250
// likely programmer error, and not what you want, particularly for destructive                       // 251
// operations.  JS regexps don't serialize over DDP but can be trivially                              // 252
// replaced by $regex.                                                                                // 253
Meteor.RedisCollection._rewriteSelector = function (selector) {                                       // 254
  // shorthand -- scalars match _id                                                                   // 255
  if (LocalCollection._selectorIsId(selector))                                                        // 256
    selector = {_id: selector};                                                                       // 257
                                                                                                      // 258
  if (!selector || (('_id' in selector) && !selector._id))                                            // 259
    // can't match anything                                                                           // 260
    return {_id: Random.id()};                                                                        // 261
                                                                                                      // 262
  var ret = {};                                                                                       // 263
  _.each(selector, function (value, key) {                                                            // 264
    // Mongo supports both {field: /foo/} and {field: {$regex: /foo/}}                                // 265
    if (value instanceof RegExp) {                                                                    // 266
      ret[key] = convertRegexpToMongoSelector(value);                                                 // 267
    } else if (value && value.$regex instanceof RegExp) {                                             // 268
      ret[key] = convertRegexpToMongoSelector(value.$regex);                                          // 269
      // if value is {$regex: /foo/, $options: ...} then $options                                     // 270
      // override the ones set on $regex.                                                             // 271
      if (value.$options !== undefined)                                                               // 272
        ret[key].$options = value.$options;                                                           // 273
    }                                                                                                 // 274
    else if (_.contains(['$or','$and','$nor'], key)) {                                                // 275
      // Translate lower levels of $and/$or/$nor                                                      // 276
      ret[key] = _.map(value, function (v) {                                                          // 277
        return Meteor.RedisCollection._rewriteSelector(v);                                            // 278
      });                                                                                             // 279
    } else {                                                                                          // 280
      ret[key] = value;                                                                               // 281
    }                                                                                                 // 282
  });                                                                                                 // 283
  return ret;                                                                                         // 284
};                                                                                                    // 285
                                                                                                      // 286
// convert a JS RegExp object to a Mongo {$regex: ..., $options: ...}                                 // 287
// selector                                                                                           // 288
var convertRegexpToMongoSelector = function (regexp) {                                                // 289
  check(regexp, RegExp); // safety belt                                                               // 290
                                                                                                      // 291
  var selector = {$regex: regexp.source};                                                             // 292
  var regexOptions = '';                                                                              // 293
  // JS RegExp objects support 'i', 'm', and 'g'. Mongo regex $options                                // 294
  // support 'i', 'm', 'x', and 's'. So we support 'i' and 'm' here.                                  // 295
  if (regexp.ignoreCase)                                                                              // 296
    regexOptions += 'i';                                                                              // 297
  if (regexp.multiline)                                                                               // 298
    regexOptions += 'm';                                                                              // 299
  if (regexOptions)                                                                                   // 300
    selector.$options = regexOptions;                                                                 // 301
                                                                                                      // 302
  return selector;                                                                                    // 303
};                                                                                                    // 304
                                                                                                      // 305
var throwIfSelectorIsNotId = function (selector, methodName) {                                        // 306
  if (!LocalCollection._selectorIsIdPerhapsAsObject(selector)) {                                      // 307
    throw new Meteor.Error(                                                                           // 308
      403, "Not permitted. Untrusted code may only " + methodName +                                   // 309
        " documents by ID.");                                                                         // 310
  }                                                                                                   // 311
};                                                                                                    // 312
                                                                                                      // 313
// 'insert' immediately returns the inserted document's new _id.                                      // 314
// The others return values immediately if you are in a stub, an in-memory                            // 315
// unmanaged collection, or a mongo-backed collection and you don't pass a                            // 316
// callback. 'update' and 'remove' return the number of affected                                      // 317
// documents. 'upsert' returns an object with keys 'numberAffected' and, if an                        // 318
// insert happened, 'insertedId'.                                                                     // 319
//                                                                                                    // 320
// Otherwise, the semantics are exactly like other methods: they take                                 // 321
// a callback as an optional last argument; if no callback is                                         // 322
// provided, they block until the operation is complete, and throw an                                 // 323
// exception if it fails; if a callback is provided, then they don't                                  // 324
// necessarily block, and they call the callback when they finish with error and                      // 325
// result arguments.  (The insert method provides the document ID as its result;                      // 326
// update and remove provide the number of affected docs as the result; upsert                        // 327
// provides an object with numberAffected and maybe insertedId.)                                      // 328
//                                                                                                    // 329
// On the client, blocking is impossible, so if a callback                                            // 330
// isn't provided, they just return immediately and any error                                         // 331
// information is lost.                                                                               // 332
//                                                                                                    // 333
// There's one more tweak. On the client, if you don't provide a                                      // 334
// callback, then if there is an error, a message will be logged with                                 // 335
// Meteor._debug.                                                                                     // 336
//                                                                                                    // 337
// The intent (though this is actually determined by the underlying                                   // 338
// drivers) is that the operations should be done synchronously, not                                  // 339
// generating their result until the database has acknowledged                                        // 340
// them. In the future maybe we should provide a flag to turn this                                    // 341
// off.                                                                                               // 342
_.each(["insert", "update", "remove"], function (name) {                                              // 343
  Meteor.RedisCollection.prototype[name] = function (/* arguments */) {                               // 344
    var self = this;                                                                                  // 345
    var args = _.toArray(arguments);                                                                  // 346
    var callback;                                                                                     // 347
    var insertId;                                                                                     // 348
    var ret;                                                                                          // 349
                                                                                                      // 350
    if (args.length && args[args.length - 1] instanceof Function)                                     // 351
      callback = args.pop();                                                                          // 352
                                                                                                      // 353
    if (name === "insert") {                                                                          // 354
      if (!args.length)                                                                               // 355
        throw new Error("insert requires an argument");                                               // 356
      // shallow-copy the document and generate an ID                                                 // 357
      args[0] = _.extend({}, args[0]);                                                                // 358
      if ('_id' in args[0]) {                                                                         // 359
        insertId = args[0]._id;                                                                       // 360
        if (!insertId || !(typeof insertId === 'string'))                                             // 361
          throw new Error("Meteor requires document _id fields to be non-empty strings");             // 362
      } else {                                                                                        // 363
        var generateId = true;                                                                        // 364
        // Don't generate the id if we're the client and the 'outermost' call                         // 365
        // This optimization saves us passing both the randomSeed and the id                          // 366
        // Passing both is redundant.                                                                 // 367
        if (self._connection && self._connection !== Meteor.server) {                                 // 368
          var enclosing = DDP._CurrentInvocation.get();                                               // 369
          if (!enclosing) {                                                                           // 370
            generateId = false;                                                                       // 371
          }                                                                                           // 372
        }                                                                                             // 373
        if (generateId) {                                                                             // 374
          insertId = args[0]._id = self._makeNewID();                                                 // 375
        }                                                                                             // 376
      }                                                                                               // 377
    } else {                                                                                          // 378
      args[0] = Meteor.RedisCollection._rewriteSelector(args[0]);                                     // 379
                                                                                                      // 380
      if (name === "update") {                                                                        // 381
        // Mutate args but copy the original options object. We need to add                           // 382
        // insertedId to options, but don't want to mutate the caller's options                       // 383
        // object. We need to mutate `args` because we pass `args` into the                           // 384
        // driver below.                                                                              // 385
        var options = args[2] = _.clone(args[2]) || {};                                               // 386
        if (options && typeof options !== "function" && options.upsert) {                             // 387
          // set `insertedId` if absent.  `insertedId` is a Meteor extension.                         // 388
          if (options.insertedId) {                                                                   // 389
            if (!(typeof options.insertedId === 'string'))                                            // 390
              throw new Error("insertedId must be string");                                           // 391
          } else {                                                                                    // 392
            options.insertedId = self._makeNewID();                                                   // 393
          }                                                                                           // 394
        }                                                                                             // 395
      }                                                                                               // 396
    }                                                                                                 // 397
                                                                                                      // 398
    // On inserts, always return the id that we generated; on all other                               // 399
    // operations, just return the result from the collection.                                        // 400
    var chooseReturnValueFromCollectionResult = function (result) {                                   // 401
      if (name === "insert") {                                                                        // 402
        if (!insertId && result) {                                                                    // 403
          insertId = result;                                                                          // 404
        }                                                                                             // 405
        return insertId;                                                                              // 406
      } else {                                                                                        // 407
        return result;                                                                                // 408
      }                                                                                               // 409
    };                                                                                                // 410
                                                                                                      // 411
    var wrappedCallback;                                                                              // 412
    if (callback) {                                                                                   // 413
      wrappedCallback = function (error, result) {                                                    // 414
        callback(error, ! error && chooseReturnValueFromCollectionResult(result));                    // 415
      };                                                                                              // 416
    }                                                                                                 // 417
                                                                                                      // 418
    if (self._connection && self._connection !== Meteor.server) {                                     // 419
      // just remote to another endpoint, propagate return value or                                   // 420
      // exception.                                                                                   // 421
                                                                                                      // 422
      var enclosing = DDP._CurrentInvocation.get();                                                   // 423
      var alreadyInSimulation = enclosing && enclosing.isSimulation;                                  // 424
                                                                                                      // 425
      if (Meteor.isClient && !wrappedCallback && ! alreadyInSimulation) {                             // 426
        // Client can't block, so it can't report errors by exception,                                // 427
        // only by callback. If they forget the callback, give them a                                 // 428
        // default one that logs the error, so they aren't totally                                    // 429
        // baffled if their writes don't work because their database is                               // 430
        // down.                                                                                      // 431
        // Don't give a default callback in simulation, because inside stubs we                       // 432
        // want to return the results from the local collection immediately and                       // 433
        // not force a callback.                                                                      // 434
        wrappedCallback = function (err) {                                                            // 435
          if (err)                                                                                    // 436
            Meteor._debug(name + " failed: " + (err.reason || err.stack));                            // 437
        };                                                                                            // 438
      }                                                                                               // 439
                                                                                                      // 440
      if (!alreadyInSimulation && name !== "insert") {                                                // 441
        // If we're about to actually send an RPC, we should throw an error if                        // 442
        // this is a non-ID selector, because the mutation methods only allow                         // 443
        // single-ID selectors. (If we don't throw here, we'll see flicker.)                          // 444
        throwIfSelectorIsNotId(args[0], name);                                                        // 445
      }                                                                                               // 446
                                                                                                      // 447
      ret = chooseReturnValueFromCollectionResult(                                                    // 448
        self._connection.apply(self._prefix + name, args, {returnStubValue: true}, wrappedCallback)   // 449
      );                                                                                              // 450
                                                                                                      // 451
    } else {                                                                                          // 452
      // it's my collection.  descend into the collection object                                      // 453
      // and propagate any exception.                                                                 // 454
      args.push(wrappedCallback);                                                                     // 455
      try {                                                                                           // 456
        // If the user provided a callback and the collection implements this                         // 457
        // operation asynchronously, then queryRet will be undefined, and the                         // 458
        // result will be returned through the callback instead.                                      // 459
        var queryRet = self._collection[name].apply(self._collection, args);                          // 460
        ret = chooseReturnValueFromCollectionResult(queryRet);                                        // 461
      } catch (e) {                                                                                   // 462
        if (callback) {                                                                               // 463
          callback(e);                                                                                // 464
          return null;                                                                                // 465
        }                                                                                             // 466
        throw e;                                                                                      // 467
      }                                                                                               // 468
    }                                                                                                 // 469
                                                                                                      // 470
    // both sync and async, unless we threw an exception, return ret                                  // 471
    // (new document ID for insert, num affected for update/remove, object with                       // 472
    // numberAffected and maybe insertedId for upsert).                                               // 473
    return ret;                                                                                       // 474
  };                                                                                                  // 475
});                                                                                                   // 476
                                                                                                      // 477
// Returns a Cursor                                                                                   // 478
Meteor.RedisCollection.prototype.matching = function (pattern) {                                      // 479
  var self = this;                                                                                    // 480
  return self._collection.matching(pattern);                                                          // 481
};                                                                                                    // 482
                                                                                                      // 483
_.each(['set', 'setex', 'get', 'append', 'del',                                                       // 484
        'incr', 'incrby', 'incrbyfloat', 'decr', 'decrby',                                            // 485
        'flushall'].concat(REDIS_COMMANDS_HASH), function (name) {                                    // 486
  Meteor.RedisCollection.prototype[name] = function (/* arguments */) {                               // 487
    var self = this;                                                                                  // 488
    var args = _.toArray(arguments);                                                                  // 489
                                                                                                      // 490
    // if this is a read-only command, and we are on the client, run it                               // 491
    // synchronously against the local cache miniredis.                                               // 492
    if (_.contains(REDIS_COMMANDS_LOCAL, name)) {                                                     // 493
      if (! self._connection || self._connection !== Meteor.server)                                   // 494
        return self._collection[name].apply(self._collection, args);                                  // 495
    }                                                                                                 // 496
                                                                                                      // 497
    var callback;                                                                                     // 498
                                                                                                      // 499
    if (args.length && args[args.length - 1] instanceof Function)                                     // 500
      callback = args.pop();                                                                          // 501
    if (self._connection && self._connection !== Meteor.server) {                                     // 502
      // just remote to another endpoint, propagate return value or                                   // 503
      // exception.                                                                                   // 504
                                                                                                      // 505
      var enclosing = DDP._CurrentInvocation.get();                                                   // 506
      var alreadyInSimulation = enclosing && enclosing.isSimulation;                                  // 507
                                                                                                      // 508
      if (Meteor.isClient && !callback && ! alreadyInSimulation) {                                    // 509
        // Client can't block, so it can't report errors by exception,                                // 510
        // only by callback. If they forget the callback, give them a                                 // 511
        // default one that logs the error, so they aren't totally                                    // 512
        // baffled if their writes don't work because their database is                               // 513
        // down.                                                                                      // 514
        // Don't give a default callback in simulation, because inside stubs we                       // 515
        // want to return the results from the local collection immediately and                       // 516
        // not force a callback.                                                                      // 517
        callback = function (err) {                                                                   // 518
          if (err)                                                                                    // 519
            Meteor._debug("Exec of command " + name + " failed: " +                                   // 520
                          (err.reason || err.stack));                                                 // 521
        };                                                                                            // 522
      }                                                                                               // 523
                                                                                                      // 524
      ret = self._connection.apply(self._prefix + 'exec',                                             // 525
                                   [name].concat(args),                                               // 526
                                   {returnStubValue: true}, callback);                                // 527
                                                                                                      // 528
    } else {                                                                                          // 529
      // it's my collection.  descend into the collection object                                      // 530
      // and propagate any exception.                                                                 // 531
      if (callback) args.push(callback);                                                              // 532
      try {                                                                                           // 533
        // If the user provided a callback and the collection implements this                         // 534
        // operation asynchronously, then queryRet will be undefined, and the                         // 535
        // result will be returned through the callback instead.                                      // 536
        ret = self._collection[name].apply(self._collection, args);                                   // 537
      } catch (e) {                                                                                   // 538
        if (callback) {                                                                               // 539
          callback(e);                                                                                // 540
          return null;                                                                                // 541
        }                                                                                             // 542
        throw e;                                                                                      // 543
      }                                                                                               // 544
    }                                                                                                 // 545
                                                                                                      // 546
    // both sync and async, unless we threw an exception, return ret                                  // 547
    // (new document ID for insert, num affected for update/remove, object with                       // 548
    // numberAffected and maybe insertedId for upsert).                                               // 549
    return ret;                                                                                       // 550
  };                                                                                                  // 551
});                                                                                                   // 552
                                                                                                      // 553
Meteor.RedisCollection.prototype.upsert = function (selector, modifier,                               // 554
                                               options, callback) {                                   // 555
  var self = this;                                                                                    // 556
  if (! callback && typeof options === "function") {                                                  // 557
    callback = options;                                                                               // 558
    options = {};                                                                                     // 559
  }                                                                                                   // 560
  return self.update(selector, modifier,                                                              // 561
              _.extend({}, options, { _returnObject: true, upsert: true }),                           // 562
              callback);                                                                              // 563
};                                                                                                    // 564
                                                                                                      // 565
// We'll actually design an index API later. For now, we just pass through to                         // 566
// Mongo's, but make it synchronous.                                                                  // 567
Meteor.RedisCollection.prototype._ensureIndex = function (index, options) {                           // 568
  var self = this;                                                                                    // 569
  if (!self._collection._ensureIndex)                                                                 // 570
    throw new Error("Can only call _ensureIndex on server collections");                              // 571
  self._collection._ensureIndex(index, options);                                                      // 572
};                                                                                                    // 573
Meteor.RedisCollection.prototype._dropIndex = function (index) {                                      // 574
  var self = this;                                                                                    // 575
  if (!self._collection._dropIndex)                                                                   // 576
    throw new Error("Can only call _dropIndex on server collections");                                // 577
  self._collection._dropIndex(index);                                                                 // 578
};                                                                                                    // 579
Meteor.RedisCollection.prototype._dropCollection = function () {                                      // 580
  var self = this;                                                                                    // 581
  if (!self._collection.dropCollection)                                                               // 582
    throw new Error("Can only call _dropCollection on server collections");                           // 583
  self._collection.dropCollection();                                                                  // 584
};                                                                                                    // 585
Meteor.RedisCollection.prototype._createCappedCollection = function (byteSize) {                      // 586
  var self = this;                                                                                    // 587
  if (!self._collection._createCappedCollection)                                                      // 588
    throw new Error("Can only call _createCappedCollection on server collections");                   // 589
  self._collection._createCappedCollection(byteSize);                                                 // 590
};                                                                                                    // 591
                                                                                                      // 592
//Meteor.RedisCollection.ObjectID = LocalCollection._ObjectID;                                        // 593
                                                                                                      // 594
///                                                                                                   // 595
/// Remote methods and access control.                                                                // 596
///                                                                                                   // 597
                                                                                                      // 598
// Restrict default mutators on collection. allow() and deny() take the                               // 599
// same options:                                                                                      // 600
//                                                                                                    // 601
// options.insert {Function(userId, doc)}                                                             // 602
//   return true to allow/deny adding this document                                                   // 603
//                                                                                                    // 604
// options.update {Function(userId, docs, fields, modifier)}                                          // 605
//   return true to allow/deny updating these documents.                                              // 606
//   `fields` is passed as an array of fields that are to be modified                                 // 607
//                                                                                                    // 608
// options.remove {Function(userId, docs)}                                                            // 609
//   return true to allow/deny removing these documents                                               // 610
//                                                                                                    // 611
// options.fetch {Array}                                                                              // 612
//   Fields to fetch for these validators. If any call to allow or deny                               // 613
//   does not have this option then all fields are loaded.                                            // 614
//                                                                                                    // 615
// allow and deny can be called multiple times. The validators are                                    // 616
// evaluated as follows:                                                                              // 617
// - If neither deny() nor allow() has been called on the collection,                                 // 618
//   then the request is allowed if and only if the "insecure" smart                                  // 619
//   package is in use.                                                                               // 620
// - Otherwise, if any deny() function returns true, the request is denied.                           // 621
// - Otherwise, if any allow() function returns true, the request is allowed.                         // 622
// - Otherwise, the request is denied.                                                                // 623
//                                                                                                    // 624
// Meteor may call your deny() and allow() functions in any order, and may not                        // 625
// call all of them if it is able to make a decision without calling them all                         // 626
// (so don't include side effects).                                                                   // 627
                                                                                                      // 628
(function () {                                                                                        // 629
  var addValidator = function(allowOrDeny, options) {                                                 // 630
    // validate keys                                                                                  // 631
    var VALID_KEYS = ['exec'];                                                                        // 632
    _.each(_.keys(options), function (key) {                                                          // 633
      if (!_.contains(VALID_KEYS, key))                                                               // 634
        throw new Error(allowOrDeny + ": Invalid key: " + key);                                       // 635
    });                                                                                               // 636
                                                                                                      // 637
    var self = this;                                                                                  // 638
    self._restricted = true;                                                                          // 639
                                                                                                      // 640
    _.each(['exec'], function (name) {                                                                // 641
      if (options[name]) {                                                                            // 642
        if (!(options[name] instanceof Function)) {                                                   // 643
          throw new Error(allowOrDeny + ": Value for `" + name + "` must be a function");             // 644
        }                                                                                             // 645
        self._validators[name][allowOrDeny].push(options[name]);                                      // 646
      }                                                                                               // 647
    });                                                                                               // 648
  };                                                                                                  // 649
                                                                                                      // 650
  Meteor.RedisCollection.prototype.allow = function(options) {                                        // 651
    addValidator.call(this, 'allow', options);                                                        // 652
  };                                                                                                  // 653
  Meteor.RedisCollection.prototype.deny = function(options) {                                         // 654
    addValidator.call(this, 'deny', options);                                                         // 655
  };                                                                                                  // 656
})();                                                                                                 // 657
                                                                                                      // 658
                                                                                                      // 659
Meteor.RedisCollection.prototype._defineMutationMethods = function() {                                // 660
  var self = this;                                                                                    // 661
                                                                                                      // 662
  // set to true once we call any allow or deny methods. If true, use                                 // 663
  // allow/deny semantics. If false, use insecure mode semantics.                                     // 664
  self._restricted = false;                                                                           // 665
                                                                                                      // 666
  // Insecure mode (default to allowing writes). Defaults to 'undefined' which                        // 667
  // means insecure iff the insecure package is loaded. This property can be                          // 668
  // overriden by tests or packages wishing to change insecure mode behavior of                       // 669
  // their collections.                                                                               // 670
  self._insecure = undefined;                                                                         // 671
                                                                                                      // 672
  self._validators = {                                                                                // 673
    exec: {allow: [], deny: []}                                                                       // 674
  };                                                                                                  // 675
                                                                                                      // 676
  if (!self._name)                                                                                    // 677
    return; // anonymous collection                                                                   // 678
                                                                                                      // 679
  self._prefix = '/' + self._name + '/';                                                              // 680
                                                                                                      // 681
  // mutation methods                                                                                 // 682
  if (self._connection) {                                                                             // 683
    var m = {};                                                                                       // 684
                                                                                                      // 685
    m[self._prefix + 'exec'] = function (/* ... */) {                                                 // 686
      // All the methods do their own validation, instead of using check().                           // 687
      var args = _.toArray(arguments);                                                                // 688
      var method = args[0];                                                                           // 689
      args = _.rest(args);                                                                            // 690
      check(method, String); // name of the redis method to execute                                   // 691
                                                                                                      // 692
      // XXX How do we validate args?                                                                 // 693
      //check(args, [String]); // args to the redis method                                            // 694
                                                                                                      // 695
      try {                                                                                           // 696
        if (this.isSimulation) {                                                                      // 697
          // In a client simulation, you can do any mutation.                                         // 698
          return self._collection[method].apply(                                                      // 699
            self._collection, args);                                                                  // 700
        }                                                                                             // 701
                                                                                                      // 702
        // This is the server receiving a method call from the client.                                // 703
                                                                                                      // 704
        if (self._restricted) {                                                                       // 705
          // short circuit if there is no way it will pass.                                           // 706
          if (self._validators.exec.allow.length === 0) {                                             // 707
            throw new Meteor.Error(                                                                   // 708
              403, "Access denied. No allow validators set on restricted " +                          // 709
                "Redis store.");                                                                      // 710
          }                                                                                           // 711
                                                                                                      // 712
          var validatedMethodName = '_validatedExec';                                                 // 713
          return self[validatedMethodName].call(self, this.userId, method, args);                     // 714
        } else if (self._isInsecure()) {                                                              // 715
          // In insecure mode, allow any mutation.                                                    // 716
          return self._collection[method].apply(self._collection, args);                              // 717
        } else {                                                                                      // 718
          // In secure mode, if we haven't called allow or deny, then nothing                         // 719
          // is permitted.                                                                            // 720
          throw new Meteor.Error(403, "Access denied");                                               // 721
        }                                                                                             // 722
      } catch (e) {                                                                                   // 723
        if (e.name === 'RedisError' || e.name === 'MiniredisError') {                                 // 724
          throw new Meteor.Error(409, e.toString());                                                  // 725
        } else {                                                                                      // 726
          throw e;                                                                                    // 727
        }                                                                                             // 728
      }                                                                                               // 729
    };                                                                                                // 730
                                                                                                      // 731
    if (Meteor.isClient || self._connection === Meteor.server)                                        // 732
      self._connection.methods(m);                                                                    // 733
  }                                                                                                   // 734
};                                                                                                    // 735
                                                                                                      // 736
Meteor.RedisCollection.prototype._isInsecure = function () {                                          // 737
  var self = this;                                                                                    // 738
  if (self._insecure === undefined)                                                                   // 739
    return !!Package.insecure;                                                                        // 740
  return self._insecure;                                                                              // 741
};                                                                                                    // 742
                                                                                                      // 743
Meteor.RedisCollection.prototype._validatedExec =                                                     // 744
  function (userId, method, args) {                                                                   // 745
  var self = this;                                                                                    // 746
                                                                                                      // 747
  // call user validators.                                                                            // 748
  // Any deny returns true means denied.                                                              // 749
  if (_.any(self._validators.exec.deny, function(validator) {                                         // 750
    return validator(userId, method, args);                                                           // 751
  })) {                                                                                               // 752
    throw new Meteor.Error(403, "Access denied");                                                     // 753
  }                                                                                                   // 754
  // Any allow returns true means proceed. Throw error if they all fail.                              // 755
  if (_.all(self._validators.exec.allow, function(validator) {                                        // 756
    return !validator(userId, method, args);                                                          // 757
  })) {                                                                                               // 758
    throw new Meteor.Error(403, "Access denied");                                                     // 759
  }                                                                                                   // 760
                                                                                                      // 761
  var Future = Npm.require('fibers/future');                                                          // 762
                                                                                                      // 763
  var f = new Future;                                                                                 // 764
  args.push(f.resolver());                                                                            // 765
  self._collection[method].apply(self._collection, args);                                             // 766
  return f.wait();                                                                                    // 767
};                                                                                                    // 768
                                                                                                      // 769
                                                                                                      // 770
////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['slava:redis-livedata'] = {
  RedisInternals: RedisInternals,
  RedisTest: RedisTest
};

})();

//# sourceMappingURL=slava_redis-livedata.js.map
